<?php
session_start();
include('database_connection.php');
include('function.php');
include('header.php');


if(!isset($_SESSION['type'])) {
    header("location:login.php");
    exit();



}

// Initialize variables
$user_id = '';
$start_date = '';
$end_date = '';
$report_type = '';
$report_html = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'] ?? '';
    $start_date = $_POST['start_date'] ?? '';
    $end_date = $_POST['end_date'] ?? '';
    $report_type = $_POST['report_type'] ?? '';

    // Validate inputs (simple validation)
    if ($user_id && $start_date && $end_date && $report_type) {
        if ($report_type == 'order') {
            // Assuming you have a function to get user-wise order with date filter
            $report_html = get_user_wise_order_by_date($connect, $user_id, $start_date, $end_date);
        } else if ($report_type == 'collection') {
            // Assuming you have a function to get user-wise collection with date filter
            $report_html = get_user_wise_collection_by_date($connect, $user_id, $start_date, $end_date);
        } else {
            $report_html = "<div class='alert alert-warning'>Please select a valid report type.</div>";
        }
    } else {
        $report_html = "<div class='alert alert-danger'>Please fill all fields.</div>";
    }
}

// Get all users for the dropdown
$user_query = $connect->query("SELECT user_id, user_name FROM user_details ORDER BY user_name ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Customized Report</title>
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"> -->
</head>
<body>

<?php
?>

        <span id='alert_action'></span>
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
                    <div class="panel-heading">
                    	<div class="row">
                            <div class="col-lg-10 col-md-10 col-sm-8 col-xs-6">
                            	<h3 class="panel-title">Generate Customized Report</h3>
                            </div>                                           
                        </div>
                    </div>
                </div>
            </div>
        </div>

<div class="panel-body">
   <form method="POST" action="customized_report.php" class="row gy-3 gx-4 align-items-end" style = "border : 1px solid #dddddd">
        <div class="col-md-2">
            <label for="user_id" class="form-label">Select User</label>
            <select id="user_id" name="user_id" class="form-select" style = " height: 38px" required>
                <option value="">-- Select User --</option>
                <?php while ($user = $user_query->fetch(PDO::FETCH_ASSOC)) { ?>
                    <option value="<?php echo htmlspecialchars($user['user_id']); ?>" <?php if($user_id == $user['user_id']) echo 'selected'; ?>>
                        <?php echo htmlspecialchars($user['user_name']); ?>
                    </option>
                <?php } ?>
            </select>
        </div>

        <div class="col-md-2">
            <label for="report_type" class="form-label" >Report Type</label>
            <select id="report_type" name="report_type" class="form-select" style = " height: 38px" required>
                <option value="">-- Select Type --</option>
                <option value="order" <?php if($report_type=='order') echo 'selected'; ?>>Order</option>
                <option value="collection" <?php if($report_type=='collection') echo 'selected'; ?>>Collection</option>
            </select>
        </div>

        <div class="col-md-3">
            <label for="start_date" class="form-label">Start Date</label>
            <input type="date" id="start_date" name="start_date" class="form-control" value="<?php echo htmlspecialchars($start_date ?? ''); ?>" required>
        </div>

        <div class="col-md-3">
            <label for="end_date" class="form-label">End Date</label>
            <input type="date" id="end_date" name="end_date" class="form-control" value="<?php echo htmlspecialchars($end_date ?? ''); ?>" required>
        </div>

        <div class="col-md-2" style="height: 65px; display: flex; align-items: center; justify-content: center;">
            <button type="submit" class="btn btn-primary">Generate Report</button>
        </div>


    </form>

    
    <hr>

    <div class="mt-4">
        <?php echo $report_html; ?>
    </div>
</div>

</body>
</html>