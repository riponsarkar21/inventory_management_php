


<?php
//database_connection.php


// Only start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database connection
$connect = new PDO("mysql:host=localhost;dbname=inventory", "root", "");
$connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>
