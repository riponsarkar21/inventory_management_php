<?php
//function.php

function fill_category_list($connect)
{
	$query = "
	SELECT * FROM category 
	WHERE category_status = 'active' 
	ORDER BY category_name ASC
	";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$output = '';
	foreach($result as $row)
	{
		$output .= '<option value="'.$row["category_id"].'">'.$row["category_name"].'</option>';
	}
	return $output;
}

function fill_brand_list($connect, $category_id)
{
	$query = "SELECT * FROM brand 
	WHERE brand_status = 'active' 
	AND category_id = '".$category_id."'
	ORDER BY brand_name ASC";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$output = '<option value="">Select Brand</option>';
	foreach($result as $row)
	{
		$output .= '<option value="'.$row["brand_id"].'">'.$row["brand_name"].'</option>';
	}
	return $output;
}

function get_user_name($connect, $user_id)
{
	$query = "
	SELECT user_name FROM user_details WHERE user_id = '".$user_id."'
	";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return $row['user_name'];
	}
}

function fill_product_list($connect)
{
	$query = "
	SELECT * FROM product 
	WHERE product_status = 'active' 
	ORDER BY product_name ASC
	";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$output = '';
	foreach($result as $row)
	{
		$output .= '<option value="'.$row["product_id"].'">'.$row["product_name"].'</option>';
	}
	return $output;
}

function fetch_product_details($product_id, $connect)
{
	$query = "
	SELECT * FROM product 
	WHERE product_id = '".$product_id."'";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		$output['product_name'] = $row["product_name"];
		$output['quantity'] = $row["product_quantity"];
		$output['price'] = $row['product_base_price'];
		$output['tax'] = $row['product_tax'];
	}
	return $output;
}

function available_product_quantity($connect, $product_id)
{
	$product_data = fetch_product_details($product_id, $connect);
	$query = "
	SELECT 	inventory_order_product.quantity FROM inventory_order_product 
	INNER JOIN inventory_order ON inventory_order.inventory_order_id = inventory_order_product.inventory_order_id
	WHERE inventory_order_product.product_id = '".$product_id."' AND
	inventory_order.inventory_order_status = 'active'
	";
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$total = 0;
	foreach($result as $row)
	{
		$total = $total + $row['quantity'];
	}
	$available_quantity = intval($product_data['quantity']) - intval($total);
	if($available_quantity == 0)
	{
		$update_query = "
		UPDATE product SET 
		product_status = 'inactive' 
		WHERE product_id = '".$product_id."'
		";
		$statement = $connect->prepare($update_query);
		$statement->execute();
	}
	return $available_quantity;
}


// Total User
function count_total_user($connect)
{
	$query = "
	SELECT * FROM user_details WHERE user_status='active'";
	$statement = $connect->prepare($query);
	$statement->execute();
	return $statement->rowCount();
}

// Total Category
function count_total_category($connect)
{
	$query = "
	SELECT * FROM category WHERE category_status='active'
	";
	$statement = $connect->prepare($query);
	$statement->execute();
	return $statement->rowCount();
}


// Total Brand
function count_total_brand($connect)
{
	$query = "
	SELECT * FROM brand WHERE brand_status='active'
	";
	$statement = $connect->prepare($query);
	$statement->execute();
	return $statement->rowCount();
}


// Total Item in Stock
function count_total_product($connect)
{
	$query = "
	SELECT * FROM product WHERE product_status='active'
	";
	$statement = $connect->prepare($query);
	$statement->execute();
	return $statement->rowCount();
}


// Total Order Value
function count_total_order_value($connect)
{
	$query = "
	SELECT sum(inventory_order_total) as total_order_value FROM inventory_order 
	WHERE inventory_order_status='active'
	";
	if($_SESSION['type'] == 'user')
	{
		$query .= ' AND user_id = "'.$_SESSION["user_id"].'"';
	}
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_order_value'], 2);
	}
}



// Total Cash Order Value
function count_total_cash_order_value($connect)
{
	$query = "
	SELECT sum(inventory_order_total) as total_order_value FROM inventory_order 
	WHERE payment_status = 'cash' 
	AND inventory_order_status='active'
	";
	if($_SESSION['type'] == 'user')
	{
		$query .= ' AND user_id = "'.$_SESSION["user_id"].'"';
	}
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_order_value'], 2);
	}
}


// Total Credit Order Value
function count_total_credit_order_value($connect)
{
	$query = "
	SELECT sum(inventory_order_total) as total_order_value FROM inventory_order WHERE payment_status = 'credit' AND inventory_order_status='active'
	";
	if($_SESSION['type'] == 'user')
	{
		$query .= ' AND user_id = "'.$_SESSION["user_id"].'"';
	}
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_order_value'], 2);
	}
}

// Total Order Value User wise
function get_user_wise_total_order($connect)
{
	$query = '
	SELECT 
		inventory_order.user_id,
		SUM(inventory_order.inventory_order_total) AS order_total, 
		SUM(CASE WHEN inventory_order.payment_status = "cash" THEN inventory_order.inventory_order_total ELSE 0 END) AS cash_order_total, 
		SUM(CASE WHEN inventory_order.payment_status = "credit" THEN inventory_order.inventory_order_total ELSE 0 END) AS credit_order_total, 
		user_details.user_name 
	FROM inventory_order 
	INNER JOIN user_details ON user_details.user_id = inventory_order.user_id 
	WHERE inventory_order.inventory_order_status = "active" 
	GROUP BY inventory_order.user_id
	';

	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();

	$output = '
	<div class="table-responsive">
		<table class="table table-bordered table-striped user-summary-table">

			<tr>
				<th>User Name</th>
				<th>Total Order Value</th>
				<th>Total Cash Order</th>
				<th>Total Credit Order</th>
			</tr>
	';

	$total_order = 0;
	$total_cash_order = 0;
	$total_credit_order = 0;

	foreach($result as $row)
	{
		$output .= '
		<tr>
			<td>
				<a href="user_orders.php?user_id='.$row['user_id'].'">
					'.$row['user_name'].'
				</a>
			</td>
			<td align="right">$ '.number_format($row["order_total"], 2).'</td>
			<td align="right">$ '.number_format($row["cash_order_total"], 2).'</td>
			<td align="right">$ '.number_format($row["credit_order_total"], 2).'</td>
		</tr>
		';

		$total_order += $row["order_total"];
		$total_cash_order += $row["cash_order_total"];
		$total_credit_order += $row["credit_order_total"];
	}

	$output .= '
	<tr>
		<td align="right"><b>Total</b></td>
		<td align="right"><b>$ '.number_format($total_order, 2).'</b></td>
		<td align="right"><b>$ '.number_format($total_cash_order, 2).'</b></td>
		<td align="right"><b>$ '.number_format($total_credit_order, 2).'</b></td>
	</tr>
	</table></div>
	';

	return $output;
}

// Collection


// function insert_collection($connect, $inventory_order_id, $user_id, $collection_date, $collected_amount, $payment_method = '', $remarks = '') {
//     $query = "
//         INSERT INTO collection 
//         (inventory_order_id, user_id, collection_date, collected_amount, payment_method, remarks) 
//         VALUES 
//         (:inventory_order_id, :user_id, :collection_date, :collected_amount, :payment_method, :remarks)
//     ";

//     $statement = $connect->prepare($query);
//     $statement->bindParam(':inventory_order_id', $inventory_order_id);
//     $statement->bindParam(':user_id', $user_id);
//     $statement->bindParam(':collection_date', $collection_date);
//     $statement->bindParam(':collected_amount', $collected_amount);
//     $statement->bindParam(':payment_method', $payment_method);
//     $statement->bindParam(':remarks', $remarks);

//     if ($statement->execute()) {
//         return true;
//     } else {
//         return false;
//     }
// }


// -----------------------


// Total collection Value User wise
function get_user_wise_total_collection($connect)
{
	$query = '
	SELECT 
		collection.user_id,
		SUM(collection.collected_amount) AS collection_total, 
		SUM(CASE WHEN collection.payment_method = "cash" THEN collection.collected_amount ELSE 0 END) AS cash_order_total, 
		SUM(CASE WHEN collection.payment_method = "credit" THEN collection.collected_amount ELSE 0 END) AS credit_order_total, 
		user_details.user_name 
	FROM collection 
	INNER JOIN user_details ON user_details.user_id = collection.user_id 
	GROUP BY collection.user_id
	';

	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();

	$output = '
	<div class="table-responsive">
		<table class="table table-bordered table-striped user-summary-table">

			<tr>
				<th>User Name</th>
				<th>Total Collection</th>
				<th>Total Cash Collection</th>
				<th>Total Credit Collection</th>
			</tr>
	';

	$total_collection = 0;
	$total_cash_collection = 0;
	$total_credit_collection = 0;

	foreach($result as $row)
	{
		$output .= '
		<tr>
			<td>
				<a href="user_collections.php?user_id=' . $row['user_id'] . '">
					' . htmlspecialchars($row['user_name']) . '
				</a>
			</td>
			<td align="right">$ ' . number_format($row["collection_total"], 2) . '</td>
			<td align="right">$ ' . number_format($row["cash_order_total"], 2) . '</td>
			<td align="right">$ ' . number_format($row["credit_order_total"], 2) . '</td>
		</tr>
		';

		$total_collection += $row["collection_total"];
		$total_cash_collection += $row["cash_order_total"];
		$total_credit_collection += $row["credit_order_total"];
	}

	$output .= '
	<tr>
		<td align="right"><b>Total</b></td>
		<td align="right"><b>$ ' . number_format($total_collection, 2) . '</b></td>
		<td align="right"><b>$ ' . number_format($total_cash_collection, 2) . '</b></td>
		<td align="right"><b>$ ' . number_format($total_credit_collection, 2) . '</b></td>
	</tr>
	</table></div>
	';

	return $output;
}


// Customized Report

function get_user_wise_order_by_date($connect, $user_id, $start_date, $end_date) {
    // Prepare and fetch order data for the user between start and end date
    $query = "
        SELECT order_id, order_date, order_status, order_total_price 
        FROM orders 
        WHERE user_id = :user_id 
          AND order_date BETWEEN :start_date AND :end_date
        ORDER BY order_date ASC
    ";
    $stmt = $connect->prepare($query);
    $stmt->execute([
        ':user_id' => $user_id,
        ':start_date' => $start_date,
        ':end_date' => $end_date
    ]);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if(!$orders) {
        return "<div class='alert alert-info'>No orders found for selected criteria.</div>";
    }

    $output = "<table class='table table-bordered'>";
    $output .= "<thead><tr><th>Order ID</th><th>Date</th><th>Status</th><th>Total Price</th></tr></thead><tbody>";

    foreach($orders as $order) {
        $output .= "<tr>
            <td>".htmlspecialchars($order['order_id'])."</td>
            <td>".htmlspecialchars($order['order_date'])."</td>
            <td>".htmlspecialchars($order['order_status'])."</td>
            <td>$ ".number_format($order['order_total_price'], 2)."</td>
        </tr>";
    }

    $output .= "</tbody></table>";
    return $output;
}

function get_user_wise_collection_by_date($connect, $user_id, $start_date, $end_date) {
    // Prepare and fetch collection data for the user between start and end date
    $query = "
        SELECT collection_id, collection_date, collected_amount 
        FROM collection 
        WHERE user_id = :user_id 
          AND collection_date BETWEEN :start_date AND :end_date
        ORDER BY collection_date ASC
    ";
    $stmt = $connect->prepare($query);
    $stmt->execute([
        ':user_id' => $user_id,
        ':start_date' => $start_date,
        ':end_date' => $end_date
    ]);
    $collections = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if(!$collections) {
        return "<div class='alert alert-info'>No collections found for selected criteria.</div>";
    }

    $output = "<table class='table table-bordered'>";
    $output .= "<thead><tr><th>Collection ID</th><th>Date</th><th>Amount</th></tr></thead><tbody>";

    foreach($collections as $collection) {
        $output .= "<tr>
            <td>".htmlspecialchars($collection['collection_id'])."</td>
            <td>".htmlspecialchars($collection['collection_date'])."</td>
            <td>$ ".number_format($collection['collected_amount'], 2)."</td>
        </tr>";
    }

    $output .= "</tbody></table>";
    return $output;
}




?>