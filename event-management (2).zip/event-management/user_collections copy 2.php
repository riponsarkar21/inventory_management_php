<?php
// user_collections.php


include('database_connection.php');
include('function.php');
include('header.php');

if (!isset($_SESSION["type"])) {
    header("location:login.php");
    exit();
}

if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Fetch user name
    $user_query = $connect->prepare("SELECT user_name FROM user_details WHERE user_id = ?");
    $user_query->execute([$user_id]);
    $user = $user_query->fetch();
?>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Collections made by: <strong><?php echo htmlspecialchars($user['user_name']); ?></strong></h3>
            </div>

            <div class="panel-body">
                <?php
                if ($user) {
                    $query = "
                        SELECT 
                            collected_amount, 
                            payment_method, 
                            collection_date 
                        FROM collection 
                        WHERE user_id = ? 
                        ORDER BY collection_date DESC
                    ";
                    $statement = $connect->prepare($query);
                    $statement->execute([$user_id]);
                    $collections = $statement->fetchAll();

                    if ($collections) {
                        echo '<table id="collectionTable" class="table table-bordered table-striped">';
                        echo '<thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Payment Method</th>
                                    <th>Collected Amount</th>
                                </tr>
                              </thead><tbody>';
                        foreach ($collections as $collection) {
                            echo '<tr>
                                    <td>' . htmlspecialchars($collection['collection_date']) . '</td>
                                    <td>' . ucfirst(htmlspecialchars($collection['payment_method'])) . '</td>
                                    <td>$' . number_format($collection['collected_amount'], 2) . '</td>
                                  </tr>';
                        }
                        echo '</tbody></table>';
                    } else {
                        echo "<p>No collections found for this user.</p>";
                    }
                } else {
                    echo "<p>User not found.</p>";
                }
            ?>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#collectionTable').DataTable({
        "lengthMenu": [[5, 10, 25, 50, 100], [5, 10, 25, 50, 100]],
        "pageLength": 10,
        "dom":
            "<'row'<'col-sm-6'l><'col-sm-6'f>>" +
            "<'row'<'col-sm-12'tr>>" +
            "<'row'<'col-sm-5'i><'col-sm-7'p>>" +
            "<'row'<'col-sm-12 text-center mt-2'B>>",
        "buttons": ['copy', 'csv', 'excel', 'pdf', 'print']
    });
});
</script>

<?php
} else {
    echo "<p>No user selected.</p>";
}

include('footer.php');
?>
