<?php
// brand_fetch.php

// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Return JSON response
header('Content-Type: application/json');

// Include database connection
include('database_connection.php');

$output = [];
$query = "
SELECT * FROM brand 
INNER JOIN category ON category.category_id = brand.category_id 
";

// Search filter
if (!empty($_POST["search"]["value"])) {
    $search = $_POST["search"]["value"];
    $query .= "WHERE brand.brand_name LIKE :search 
               OR category.category_name LIKE :search 
               OR brand.brand_status LIKE :search ";
}

// Order
$order_column = $_POST['order'][0]['column'] ?? null;
$order_dir = $_POST['order'][0]['dir'] ?? 'DESC';
if ($order_column !== null) {
    $columns = ['brand_id', 'category_name', 'brand_name', 'brand_status'];
    $order_by = $columns[$order_column] ?? 'brand.brand_id';
    $query .= "ORDER BY $order_by $order_dir ";
} else {
    $query .= "ORDER BY brand.brand_id DESC ";
}

// Limit
$limit = $_POST["length"] ?? -1;
$start = $_POST["start"] ?? 0;
if ($limit != -1) {
    $query .= "LIMIT :start, :length";
}

$statement = $connect->prepare($query);

// Bind values
if (!empty($_POST["search"]["value"])) {
    $statement->bindValue(':search', '%' . $search . '%', PDO::PARAM_STR);
}
if ($limit != -1) {
    $statement->bindValue(':start', (int)$start, PDO::PARAM_INT);
    $statement->bindValue(':length', (int)$limit, PDO::PARAM_INT);
}

$statement->execute();
$result = $statement->fetchAll();
$filtered_rows = $statement->rowCount();

$data = [];
foreach ($result as $row) {
    $status_label = $row['brand_status'] === 'active'
        ? '<span class="label label-success">Active</span>'
        : '<span class="label label-danger">Inactive</span>';

    $data[] = [
        $row['brand_id'],
        $row['category_name'],
        $row['brand_name'],
        $status_label,
        '<button type="button" name="update" id="' . $row["brand_id"] . '" class="btn btn-warning btn-xs update">Update</button>',
        '<button type="button" name="status" id="' . $row["brand_id"] . '" class="btn btn-primary btn-xs status" data-status="' . $row["brand_status"] . '">Change status</button>',
        '<button type="button" name="delete" id="' . $row["brand_id"] . '" class="btn btn-danger btn-xs delete" data-status="' . $row["brand_name"] . '">Delete</button>',
    ];
}

// Count total records
function get_total_all_records($connect)
{
    $stmt = $connect->prepare("SELECT COUNT(*) FROM brand");
    $stmt->execute();
    return $stmt->fetchColumn();
}

// Output
echo json_encode([
    "draw" => intval($_POST["draw"] ?? 0),
    "recordsTotal" => $filtered_rows,
    "recordsFiltered" => get_total_all_records($connect),
    "data" => $data
]);
