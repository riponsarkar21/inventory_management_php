<?php

// collection_action.php

include('database_connection.php');
include('function.php');

if (isset($_POST['btn_action'])) {

	if ($_POST['btn_action'] == 'Add') {
		$query = "
		INSERT INTO collection (user_id, collection_amount, collection_date, customer_name, payment_method, collection_status, created_at)
		VALUES (:user_id, :collection_amount, :collection_date, :customer_name, :payment_method, :collection_status, :created_at)
		";
		$statement = $connect->prepare($query);
		$statement->execute(array(
			':user_id'            => $_SESSION["user_id"],
			':collection_amount'  => $_POST['collection_amount'],
			':collection_date'    => $_POST['collection_date'],
			':customer_name'      => $_POST['customer_name'],
			':payment_method'     => $_POST['payment_method'],
			':collection_status'  => 'active',
			':created_at'         => date("Y-m-d")
		));
		if ($statement->rowCount() > 0) {
			echo 'Collection Recorded';
		}
	}

	if ($_POST['btn_action'] == 'fetch_single') {
		$query = "
		SELECT * FROM collection WHERE collection_id = :collection_id
		";
		$statement = $connect->prepare($query);
		$statement->execute(array(':collection_id' => $_POST["collection_id"]));
		$result = $statement->fetchAll();
		$output = array();
		foreach ($result as $row) {
			$output['collection_amount'] = $row['collection_amount'];
			$output['collection_date']   = $row['collection_date'];
			$output['customer_name']     = $row['customer_name'];
			$output['payment_method']    = $row['payment_method'];
		}
		echo json_encode($output);
	}

	if ($_POST['btn_action'] == 'Edit') {
		$query = "
		UPDATE collection 
		SET collection_amount = :collection_amount,
			collection_date = :collection_date,
			customer_name = :customer_name,
			payment_method = :payment_method
		WHERE collection_id = :collection_id
		";
		$statement = $connect->prepare($query);
		$statement->execute(array(
			':collection_amount'  => $_POST['collection_amount'],
			':collection_date'    => $_POST['collection_date'],
			':customer_name'      => $_POST['customer_name'],
			':payment_method'     => $_POST['payment_method'],
			':collection_id'      => $_POST['collection_id']
		));
		if ($statement->rowCount() > 0) {
			echo 'Collection Updated';
		}
	}

	if ($_POST['btn_action'] == 'status') {
		$status = ($_POST['status'] == 'active') ? 'inactive' : 'active';
		$query = "
		UPDATE collection 
		SET collection_status = :collection_status 
		WHERE collection_id = :collection_id
		";
		$statement = $connect->prepare($query);
		$statement->execute(array(
			':collection_status' => $status,
			':collection_id'     => $_POST["collection_id"]
		));
		if ($statement->rowCount() > 0) {
			echo 'Collection status changed to ' . $status;
		} else {
			echo 'Failed to change status';
		}
	}

	if ($_POST['btn_action'] == 'delete') {
		$query = "
		DELETE FROM collection 
		WHERE collection_id = :collection_id
		";
		$statement = $connect->prepare($query);
		$statement->execute(array(':collection_id' => $_POST["collection_id"]));
		if ($statement->rowCount() > 0) {
			echo 'Collection deleted successfully';
		} else {
			echo 'Failed to delete collection';
		}
	}
}

?>
