<?php
// collection_fetch.php

include('database_connection.php');
include('function.php');

$query = '';
$output = array();

// Base SELECT query
$query .= "SELECT * FROM collection WHERE ";

// Filter by user if not master
if ($_SESSION['type'] == 'user') {
    $query .= 'user_id = "' . $_SESSION["user_id"] . '" AND ';
}

// Search filter
if (isset($_POST["search"]["value"])) {
    $query .= '(voucher_no LIKE "%' . $_POST["search"]["value"] . '%" ';
    $query .= 'OR customer_name LIKE "%' . $_POST["search"]["value"] . '%" ';
    $query .= 'OR amount LIKE "%' . $_POST["search"]["value"] . '%" ';
    $query .= 'OR collection_status LIKE "%' . $_POST["search"]["value"] . '%" ';
    $query .= 'OR collection_date LIKE "%' . $_POST["search"]["value"] . '%") ';
}

// Define columns mapping
$columns = array(
    0 => 'collection_id',
    1 => 'voucher_no',
    2 => 'customer_name',
    3 => 'amount',
    4 => 'collection_status',
    5 => 'collection_date',
    6 => 'user_id'
);

// Sorting
if (isset($_POST["order"])) {
    $column_index = $_POST['order']['0']['column'];
    $sort_column = isset($columns[$column_index]) ? $columns[$column_index] : 'collection_id';
    $query .= 'ORDER BY ' . $sort_column . ' ' . $_POST['order']['0']['dir'] . ' ';
} else {
    $query .= 'ORDER BY collection_id DESC ';
}

// Pagination
if ($_POST["length"] != -1) {
    $query .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}

// Fetch data
$statement = $connect->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
$data = array();
$filtered_rows = $statement->rowCount();

foreach ($result as $row) {
    // Format collection status
    $status = ($row['collection_status'] == 'Received') 
        ? '<span class="label label-success">Received</span>' 
        : '<span class="label label-warning">Pending</span>';

    $sub_array = array();
    $sub_array[] = $row['voucher_no'];
    $sub_array[] = $row['customer_name'];
    $sub_array[] = $row['amount'];
    $sub_array[] = $status;
    $sub_array[] = $row['collection_date'];

    // If master user, show username
    if ($_SESSION['type'] == 'master') {
        $sub_array[] = get_user_name($connect, $row['user_id']);
    }

    // Action buttons
    $sub_array[] = '<button type="button" name="update" id="' . $row["collection_id"] . '" class="btn btn-warning btn-xs update">Update</button>';
    $sub_array[] = '<button type="button" name="delete" id="' . $row["collection_id"] . '" class="btn btn-danger btn-xs delete" data-status="' . $row["voucher_no"] . '">Delete</button>';

    $data[] = $sub_array;
}

// Helper: Total Records
function get_total_all_records($connect) {
    $statement = $connect->prepare("SELECT * FROM collection");
    $statement->execute();
    return $statement->rowCount();
}

// Return output
$output = array(
    "draw"            => intval($_POST["draw"]),
    "recordsTotal"    => $filtered_rows,
    "recordsFiltered" => get_total_all_records($connect),
    "data"            => $data
);

echo json_encode($output);
?>
