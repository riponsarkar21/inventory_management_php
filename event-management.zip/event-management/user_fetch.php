<?php
// user_fetch.php
include('database_connection.php');

$columns = ['user_id', 'user_email', 'user_name', 'user_status'];

$baseQuery = "SELECT * FROM user_details WHERE user_type = 'user'";
$search = '';

if (!empty($_POST['search']['value'])) {
    $searchVal = '%' . $_POST['search']['value'] . '%';
    $search = " AND (user_email LIKE :search OR user_name LIKE :search OR user_status LIKE :search)";
}

$order = ' ORDER BY user_id DESC';
if (isset($_POST['order'])) {
    $columnIndex = $_POST['order']['0']['column'];
    $orderDir = $_POST['order']['0']['dir'];
    if (isset($columns[$columnIndex])) {
        $order = " ORDER BY {$columns[$columnIndex]} {$orderDir}";
    }
}

$limit = '';
if ($_POST["length"] != -1) {
    $limit = ' LIMIT :start, :length';
}

$query = $baseQuery . $search . $order . $limit;

$statement = $connect->prepare($query);

if ($search) {
    $statement->bindValue(':search', $searchVal, PDO::PARAM_STR);
}
if ($limit) {
    $statement->bindValue(':start', (int) $_POST['start'], PDO::PARAM_INT);
    $statement->bindValue(':length', (int) $_POST['length'], PDO::PARAM_INT);
}

$statement->execute();
$data = [];
foreach ($statement->fetchAll() as $row) {
    $statusLabel = ($row["user_status"] === 'Active') 
        ? '<span class="label label-success">Active</span>' 
        : '<span class="label label-danger">Inactive</span>';

    $data[] = [
        $row['user_id'],
        $row['user_email'],
        $row['user_name'],
        $statusLabel,
        '<button type="button" name="update" id="'.$row["user_id"].'" class="btn btn-warning btn-xs update">Update</button>',
        '<button type="button" name="status" id="'.$row["user_id"].'" class="btn btn-primary btn-xs status" data-status="'.$row["user_status"].'">Change Status</button>',
        '<button type="button" name="delete" id="'.$row["user_id"].'" class="btn btn-danger btn-xs delete" data-delete="'.$row["user_name"].'">Delete</button>'
    ];
}

function get_total_all_records($connect) {
    $stmt = $connect->prepare("SELECT COUNT(*) FROM user_details WHERE user_type = 'user'");
    $stmt->execute();
    return $stmt->fetchColumn();
}

echo json_encode([
    "draw" => intval($_POST["draw"]),
    "recordsTotal" => count($data),
    "recordsFiltered" => get_total_all_records($connect),
    "data" => $data
]);
?>
