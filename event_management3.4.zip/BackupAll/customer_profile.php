<?php
include('database_connection.php');
include('header.php');

$customer_id = $_GET['id'];

$query = "SELECT * FROM customers WHERE customer_id = ?";
$stmt = $connect->prepare($query);
$stmt->execute([$customer_id]);
$customer = $stmt->fetch();

// Get orders
$order_query = "SELECT * FROM orders WHERE customer_id = ? ORDER BY order_id DESC";
$order_stmt = $connect->prepare($order_query);
$order_stmt->execute([$customer_id]);
$orders = $order_stmt->fetchAll();
?>

<div class="panel panel-default">
    <div class="panel-heading">Customer Profile</div>
    <div class="panel-body">
        <h4><?= $customer['customer_name'] ?></h4>
        <p><strong>Phone:</strong> <?= $customer['phone'] ?></p>
        <p><strong>Email:</strong> <?= $customer['email'] ?></p>
        <p><strong>Address:</strong> <?= $customer['address'] ?></p>

        <hr>
        <h4>Transaction History</h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Date</th>
                    <th>Total</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($orders as $order): ?>
                    <tr>
                        <td><?= $order["order_id"] ?></td>
                        <td><?= $order["order_date"] ?></td>
                        <td><?= $order["order_total"] ?></td>
                        <td><a href="view_order.php?id=<?= $order["order_id"] ?>" class="btn btn-sm btn-info">View</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include('footer.php'); ?>
