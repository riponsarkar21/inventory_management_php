<?php

// user_action.php

include('database_connection.php');

function upload_image() {
    if (!empty($_FILES["user_image"]["name"])) {
        $ext = pathinfo($_FILES["user_image"]["name"], PATHINFO_EXTENSION);
        $new_name = uniqid() . '.' . $ext;
        $destination = 'uploads/' . $new_name;
        move_uploaded_file($_FILES["user_image"]["tmp_name"], $destination);
        return $destination;
    }
    return '';
}

if(isset($_POST['btn_action']))
{
    if($_POST['btn_action'] == 'Add') {
        $image_path = upload_image();
        $query = "
        INSERT INTO user_details (user_email, user_password, user_name, user_type, user_image, user_status) 
        VALUES (:user_email, :user_password, :user_name, :user_type, :user_image, :user_status)";
        $statement = $connect->prepare($query);
        $statement->execute([
            ':user_email'    => $_POST["user_email"],
            ':user_password' => password_hash($_POST["user_password"], PASSWORD_DEFAULT),
            ':user_name'     => $_POST["user_name"],
            ':user_type'     => $_POST["user_type"],
            ':user_image'    => $image_path,
            ':user_status'   => 'Active'
        ]);
        echo 'New User Added';
    }

    if($_POST['btn_action'] == 'fetch_single') {
        $query = "SELECT * FROM user_details WHERE user_id = :user_id";
        $statement = $connect->prepare($query);
        $statement->execute([':user_id' => $_POST["user_id"]]);
        $result = $statement->fetch(PDO::FETCH_ASSOC);
        $result['user_image'] = $result['user_image'] ?? '';
        echo json_encode($result);
    }

    if($_POST['btn_action'] == 'Edit') {
        $image_path = upload_image();
        $update_fields = "
            user_name = :user_name, 
            user_email = :user_email, 
            user_type = :user_type";
        $params = [
            ':user_name' => $_POST["user_name"],
            ':user_email' => $_POST["user_email"],
            ':user_type' => $_POST["user_type"],
            ':user_id' => $_POST["user_id"]
        ];

        if (!empty($image_path)) {
            $update_fields .= ", user_image = :user_image";
            $params[':user_image'] = $image_path;
        }

        if (!empty($_POST["user_password"])) {
            $update_fields .= ", user_password = :user_password";
            $params[':user_password'] = password_hash($_POST["user_password"], PASSWORD_DEFAULT);
        }

        $query = "UPDATE user_details SET $update_fields WHERE user_id = :user_id";
        $statement = $connect->prepare($query);
        $statement->execute($params);
        echo 'User Details Edited';
    }

    if($_POST['btn_action'] == 'status') {
        $status = ($_POST['status'] == 'Active') ? 'Inactive' : 'Active';
        $query = "UPDATE user_details SET user_status = :user_status WHERE user_id = :user_id";
        $statement = $connect->prepare($query);
        $statement->execute([
            ':user_status' => $status,
            ':user_id' => $_POST["user_id"]
        ]);
        echo 'User Status changed to ' . $status;
    }

    if($_POST['btn_action'] == 'delete') {
        $query = "DELETE FROM user_details WHERE user_id = :user_id";
        $statement = $connect->prepare($query);
        $statement->execute([':user_id' => $_POST["user_id"]]);
        echo 'User deleted';
    }
}
?>