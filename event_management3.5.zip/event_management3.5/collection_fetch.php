<?php
// collection_fetch.php

// Enable error reporting to catch issues outputting before JSON
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

include('database_connection.php');
include('function.php');

// Set default draw value
$draw = isset($_POST['draw']) ? intval($_POST['draw']) : 0;

// Base query
$where = '';
$params = [];

// Filter by user type
if ($_SESSION['type'] === 'user') {
    $where .= 'WHERE c.user_id = :user_id ';
    $params[':user_id'] = $_SESSION['user_id'];
}

// Handle search filtering
if (isset($_POST['search']['value']) && $_POST['search']['value'] !== '') {
    $search = '%' . $_POST['search']['value'] . '%';
    $where .= $where ? 'AND (' : 'WHERE (';
    $searchCsv = '
        c.collection_id LIKE :search OR
        u.user_name LIKE :search OR
        io.inventory_order_name LIKE :search OR
        c.collected_amount LIKE :search OR
        c.collection_date LIKE :search
    ';
    $where .= $searchCsv . ') ';
    $params[':search'] = $search;
}

// Get total records filtered
$totalFilteredStmt = $connect->prepare("
    SELECT COUNT(*) 
    FROM collection c
    JOIN user_details u ON c.user_id = u.user_id
    JOIN inventory_order io ON c.inventory_order_id = io.inventory_order_id
    $where
");
$totalFilteredStmt->execute($params);
$recordsFiltered = $totalFilteredStmt->fetchColumn();

// Ordering
$orderBy = 'c.collection_id';
$orderDir = 'DESC';
if (!empty($_POST['order'])) {
    $columnMap = [
        0 => 'c.collection_id',
        1 => 'u.user_name',
        2 => 'io.inventory_order_name',
        3 => 'c.collected_amount',
        4 => 'c.payment_method',
        5 => 'c.collection_date'
    ];
    $orderCol = intval($_POST['order'][0]['column']);
    $orderBy = $columnMap[$orderCol] ?? $orderBy;
    $orderDir = $_POST['order'][0]['dir'] === 'asc' ? 'ASC' : 'DESC';
}

// Pagination
$start = intval($_POST['start'] ?? 0);
$length = intval($_POST['length'] ?? 10);

// Final query
$sql = "
    SELECT c.collection_id, u.user_name, io.inventory_order_name, c.inventory_order_id,
           c.collected_amount, c.payment_method, c.collection_date
    FROM collection c
    JOIN user_details u ON c.user_id = u.user_id
    JOIN inventory_order io ON c.inventory_order_id = io.inventory_order_id
    $where
    ORDER BY $orderBy $orderDir
    LIMIT :start, :length
";

$params[':start'] = $start;
$params[':length'] = $length;

$stmt = $connect->prepare($sql);
foreach ($params as $key => $val) {
    if (in_array($key, [':start', ':length'])) {
        $stmt->bindValue($key, $val, PDO::PARAM_INT);
    } else {
        $stmt->bindValue($key, $val);
    }
}
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get total records count
$totalStmt = $connect->prepare("SELECT COUNT(*) FROM collection");
$totalStmt->execute();
$recordsTotal = $totalStmt->fetchColumn();

// Prepare DataTables response
$response = [
    "draw" => $draw,
    "recordsTotal" => intval($recordsTotal),
    "recordsFiltered" => intval($recordsFiltered),
    "data" => []
];

foreach ($rows as $row) {
    // Prepare action buttons
    $actions = '
        <button type="button" name="update" id="' . $row['collection_id'] . '" class="btn btn-warning btn-xs update">Update</button> 
        <button type="button" name="delete" id="' . $row['collection_id'] . '" class="btn btn-danger btn-xs delete">Delete</button>
    ';
    $response['data'][] = [
        $row['collection_id'],
        htmlspecialchars($row['inventory_order_name']),
        htmlspecialchars($row['inventory_order_id']),
        htmlspecialchars($row['collected_amount']),
        htmlspecialchars($row['payment_method']),
        $row['collection_date'],
        $actions
    ];
}

echo json_encode($response);
