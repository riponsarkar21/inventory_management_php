// --- user_visitingcard_pdf.php ---
<?php
require_once 'pdf.php';
include('database_connection.php');

if (!isset($_GET['id'])) die('Invalid ID');

$stmt = $connect->prepare("SELECT * FROM user_details WHERE user_id = ?");
$stmt->execute([$_GET['id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) die('User not found');

$html = '<style>
.card { border: 1px solid #333; padding: 15px; width: 350px; font-family: Arial; }
h2 { margin: 0; }
</style>';
$html .= '<div class="card">
<h2>' . $user['user_name'] . '</h2>
<p><b>' . $user['user_type'] . '</b></p>
<p>Email: ' . $user['user_email'] . '</p>
<p>Phone: ' . $user['user_phone'] . '</p>
<p>Address: ' . $user['user_address'] . '</p>
</div>';

generate_pdf($html, $user['user_name'] . '_visitingcard');
?>