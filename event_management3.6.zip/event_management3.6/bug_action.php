<?php
// bug_action.php
include('database_connection.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'delete') {
        $stmt = $connect->prepare("DELETE FROM bug WHERE bug_id = ?");
        $stmt->execute([$_POST['id']]);
        echo "Bug deleted.";
        exit;
    }

    if ($action === 'change_status') {
        $stmt = $connect->prepare("UPDATE bug SET status = IF(status='Open','Solved','Open'), solved_by = IF(status='Solved', '', 'QC_User'), solved_at = IF(status='Solved', NULL, NOW()) WHERE bug_id = ?");
        $stmt->execute([$_POST['id']]);
        echo "Status changed.";
        exit;
    }

    if ($action === 'cancel') {
        $stmt = $connect->prepare("UPDATE bug SET status = 'Cancelled' WHERE bug_id = ?");
        $stmt->execute([$_POST['id']]);
        echo "Bug marked as cancelled.";
        exit;
    }

    if ($action === 'fetch_single') {
        $stmt = $connect->prepare("SELECT * FROM bug WHERE bug_id = ?");
        $stmt->execute([$_POST['id']]);
        echo json_encode($stmt->fetch(PDO::FETCH_ASSOC));
        exit;
    }

    $image_path = '';
    if (!empty($_FILES['screenshot_image']['name'])) {
        $upload_dir = 'uploads/bug/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $title_word = preg_replace('/[^A-Za-z0-9]/', '', strtolower(explode(' ', $_POST['bug_title'])[0] ?? 'bug'));
        $timestamp = time();
        $extension = pathinfo($_FILES['screenshot_image']['name'], PATHINFO_EXTENSION);
        $image_name = "{$title_word}-{$timestamp}.{$extension}";
        $image_path = $upload_dir . $image_name;

        move_uploaded_file($_FILES['screenshot_image']['tmp_name'], $image_path);
    }

    if (!empty($_POST['bug_id'])) {
        $stmt = $connect->prepare("UPDATE bug SET bug_title=?, bug_description=?, screenshot_image=? WHERE bug_id=?");
        $stmt->execute([
            $_POST['bug_title'],
            $_POST['bug_description'],
            $image_path,
            $_POST['bug_id']
        ]);
        echo "Bug updated successfully.";
    } else {
        $stmt = $connect->prepare("INSERT INTO bug (bug_title, bug_description, screenshot_image, created_by, created_at, status) VALUES (?, ?, ?, ?, NOW(), 'Open')");
        $stmt->execute([
            $_POST['bug_title'],
            $_POST['bug_description'],
            $image_path,
            $_POST['created_by']
        ]);
        echo "Bug added successfully.";
    }
}
?>
