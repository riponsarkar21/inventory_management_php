<?php
// bug_fetch.php
include('database_connection.php');

$stmt = $connect->prepare("SELECT * FROM bug ORDER BY bug_id DESC");
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($rows as &$row) {
    if (!empty($row['screenshot_image'])) {
        $row['screenshot_image'] = $row['screenshot_image'];
    }
}

echo json_encode(['data' => $rows]);
?>
