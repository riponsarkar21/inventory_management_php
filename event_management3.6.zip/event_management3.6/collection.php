<?php
// collection.php

include('database_connection.php');
include('function.php');

if (!isset($_SESSION['type'])) {
    header('location:login.php');
}

include('header.php');
?>

<!-- Additional CSS/JS for DataTables Buttons -->
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
<link rel="stylesheet" href="css/datepicker.css">

<script src="js/bootstrap-datepicker1.js"></script>

<span id="alert_action"></span>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-lg-10">
                        <h3 class="panel-title">Collection List</h3>
                    </div>
                    <div class="col-lg-2 text-right">
                        <button type="button" name="add" id="add_button" class="btn btn-success btn-xs">Add Collection</button>
                    </div>
                </div>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table id="collection_data" class="table table-bordered table-striped w-100">
                        <thead>
                            <tr>
                                <th>Collection ID</th>
                                <th>Customer Name</th>
                                <th>Order ID</th>
                                <th>Amount</th>
                                <th>Method</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Collection Modal -->
<div id="collectionModal" class="modal fade">
    <div class="modal-dialog">
        <form method="post" id="collection_form">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add Collection</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Customer Name</label>
                        <input type="text" name="customer_name" id="customer_name" class="form-control" required />
                    </div>
                    <div class="form-group">
                        <label>Order ID</label>
                        <input type="text" name="order_id" id="order_id" class="form-control" required />
                    </div>
                    <div class="form-group">
                        <label>Amount</label>
                        <input type="number" name="amount" id="amount" class="form-control" required />
                    </div>
                    <div class="form-group">
                        <label>Payment Method</label>
                        <select name="payment_method" id="payment_method" class="form-control" required>
                            <option value="Cash">Cash</option>
                            <option value="Bank">Bank</option>
                            <option value="Mobile">Mobile</option>
                            <option value="Others">Others</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Collection Date</label>
                        <input type="text" name="collection_date" id="collection_date" class="form-control" required />
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="collection_id" id="collection_id" />
                    <input type="hidden" name="btn_action" id="btn_action" />
                    <input type="submit" name="action" id="action" class="btn btn-info" value="Add" />
                </div>
            </div>
        </form>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#collection_date').datepicker({
        format: "yyyy-mm-dd",
        autoclose: true
    });

    const collectionDataTable = $('#collection_data').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: "collection_fetch.php",
            type: "POST"
        },
        columnDefs: [
            { targets: [6], orderable: false }
        ],
        lengthMenu: [[5, 10, 25, 50], [5, 10, 25, 50]],
        pageLength: 10,
        dom:
            "<'row'<'col-sm-6'l><'col-sm-6'f>>" +
            "<'row'<'col-sm-12'tr>>" +
            "<'row'<'col-sm-5'i><'col-sm-7'p>>" +
            "<'row'<'col-sm-12 text-center mt-3'B>>",
        buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
    });

    $('#add_button').click(function() {
        $('#collection_form')[0].reset();
        $('#collectionModal').modal('show');
        $('.modal-title').text("Add Collection");
        $('#action').val("Add");
        $('#btn_action').val("Add");
    });

    $('#collection_form').submit(function(event) {
        event.preventDefault();
        $('#action').prop('disabled', true);
        $.post("collection_action.php", $(this).serialize(), function(data) {
            $('#collection_form')[0].reset();
            $('#collectionModal').modal('hide');
            $('#alert_action').html('<div class="alert alert-success">' + data + '</div>');
            $('#action').prop('disabled', false);
            collectionDataTable.ajax.reload();
        });
    });

    $(document).on('click', '.update', function() {
        const id = $(this).attr("id");
        $.post("collection_action.php", { collection_id: id, btn_action: "fetch_single" }, function(data) {
            $('#collectionModal').modal('show');
            $('#customer_name').val(data.customer_name);
            $('#order_id').val(data.order_id);
            $('#amount').val(data.amount);
            $('#payment_method').val(data.payment_method);
            $('#collection_date').val(data.collection_date);
            $('.modal-title').text("Edit Collection");
            $('#collection_id').val(id);
            $('#action').val("Edit");
            $('#btn_action').val("Edit");
        }, 'json');
    });

    $(document).on('click', '.delete', function() {
        if (!confirm("Are you sure you want to delete this collection?")) return;
        const id = $(this).attr("id");
        $.post("collection_action.php", { collection_id: id, btn_action: "delete" }, function(data) {
            $('#alert_action').html('<div class="alert alert-danger">' + data + '</div>');
            collectionDataTable.ajax.reload();
        });
    });
});
</script>

<?php include('footer.php'); ?>
