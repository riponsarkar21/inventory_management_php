<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$host = "mysql1001.site4now.net";
$dbname = "db_abad89_invento";
$username = "abad89_invento";      // ✔️ confirmed
$password = "@Abc12345";           // ✔️ just reset

try {
    $connect = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>