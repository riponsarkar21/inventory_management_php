<?php
// gift_fetch.php
// final

include('database_connection.php');

$stmt = $connect->prepare("SELECT * FROM gift ORDER BY gift_id DESC");
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($rows as &$row) {
    if (!empty($row['gift_image'])) {
        $row['gift_image'] = $row['gift_image'];
    }
}

echo json_encode(['data' => $rows]);
?>