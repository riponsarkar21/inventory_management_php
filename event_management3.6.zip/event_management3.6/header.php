<?php
// header.php
if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
    $redirect = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header('Location: ' . $redirect);
    exit();
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$version = time();
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <title>Inventory Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="css/bootstrap.min.css?v=<?= $version ?>">
    <link rel="stylesheet" href="css/styles.css?v=<?= $version ?>">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/bootstrap.min.js?v=<?= $version ?>"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.flash.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>

    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
        }

        html[data-theme="dark"] {
            background: #121212;
            color: #e0e0e0;
        }

        html[data-theme="dark"] .sidebar,
        html[data-theme="dark"] .sidebar a {
            background-color: #222;
            color: #ccc;
        }

        .sidebar {
            height: 100vh;
            width: 220px;
            position: fixed;
            background-color: #343a40;
            padding-top: 10px;
            transition: width 0.3s ease;
            overflow-x: hidden;
            overflow-y: auto;
        }

        .sidebar.collapsed {
            width: 60px;
        }

        .sidebar a {
            color: white;
            display: block;
            padding: 10px 20px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            line-height: 1.5;
        }

        .sidebar.collapsed a {
            padding: 10px;
            text-align: center;
        }

        .sidebar.collapsed .label {
            display: none;
        }

        .content {
            margin-left: 240px;
            transition: margin-left 0.3s ease;
            padding: 20px;
        }

        .sidebar.collapsed + .content {
            margin-left: 80px;
        }

        #sidebar-toggle {
            color: white;
            padding: 10px 20px;
            cursor: pointer;
            font-size: 18px;
        }
    </style>

    <script>
        function toggleTheme() {
            const html = document.documentElement;
            html.dataset.theme = html.dataset.theme === 'dark' ? 'light' : 'dark';
            localStorage.setItem('theme', html.dataset.theme);
        }

        function toggleSidebar() {
            $('.sidebar').toggleClass('collapsed');
            localStorage.setItem('sidebarCollapsed', $('.sidebar').hasClass('collapsed') ? 'yes' : 'no');
        }

        $(document).ready(function () {
            const savedTheme = localStorage.getItem('theme') || 'light';
            document.documentElement.dataset.theme = savedTheme;

            if (localStorage.getItem('sidebarCollapsed') === 'yes') {
                $('.sidebar').addClass('collapsed');
            }
        });
    </script>
</head>

<body>
<div class="sidebar">
    <div id="sidebar-toggle" onclick="toggleSidebar()">☰</div>
    <a href="index.php" class="<?= $current_page == 'index.php' ? 'active' : '' ?>">🏠 <span class="label">Home</span></a>
    <?php if ($_SESSION['type'] == 'master') { ?>
        <a href="user.php" class="<?= $current_page == 'user.php' ? 'active' : '' ?>">👤 <span class="label">User</span></a>
        <a href="category.php" class="<?= $current_page == 'category.php' ? 'active' : '' ?>">📂 <span class="label">Category</span></a>
        <a href="brand.php" class="<?= $current_page == 'brand.php' ? 'active' : '' ?>">🏷 <span class="label">Brand</span></a>
        <a href="product.php" class="<?= $current_page == 'product.php' ? 'active' : '' ?>">📦 <span class="label">Product</span></a>
        <a href="customer.php" class="<?= $current_page == 'customer.php' ? 'active' : '' ?>">🧑 <span class="label">Customer</span></a>
    <?php } ?>
    <a href="order.php" class="<?= $current_page == 'order.php' ? 'active' : '' ?>">📝 <span class="label">Order</span></a>
    <a href="collection.php" class="<?= $current_page == 'collection.php' ? 'active' : '' ?>">💰 <span class="label">Collection</span></a>
    <a href="report.php" class="<?= $current_page == 'report.php' ? 'active' : '' ?>">📊 <span class="label">Report</span></a>
    <a href="customized_report.php" class="<?= $current_page == 'customized_report.php' ? 'active' : '' ?>">📋 <span class="label">Custom Report</span></a>
    <a href="gift.php" class="<?= $current_page == 'gift.php' ? 'active' : '' ?>">🎁 <span class="label">Gift</span></a>
    <a href="#" onclick="toggleTheme()">🌓 <span class="label">Toggle Theme</span></a>
    <hr style="border-color: #555;">
    <a href="profile.php" class="<?= $current_page == 'profile.php' ? 'active' : '' ?>">👤 <span class="label"><?= $_SESSION['user_name'] ?></span></a>
    <a href="#" data-toggle="modal" data-target="#logoutModal">🚪 <span class="label">Logout</span></a>
</div>
<div class="content">
