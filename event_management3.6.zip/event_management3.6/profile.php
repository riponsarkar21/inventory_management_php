<?php

// profile.php

include('database_connection.php');

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['type'])) {
    header("location:login.php");
    exit();
}

$query = "SELECT * FROM user_details WHERE user_id = :user_id";
$statement = $connect->prepare($query);
$statement->execute([':user_id' => $_SESSION["user_id"]]);
$row = $statement->fetch();

$name = $row['user_name'];
$email = $row['user_email'];
$phone = $row['user_phone'];
$address = $row['user_address'];
$reference = $row['user_reference'];
$education = $row['user_education'];
$experience = $row['user_experience'];
$training = $row['user_training'];
$image = $row['user_image'];

include('header.php');
?>

<div class="panel panel-default">
    <div class="panel-heading">Edit Profile</div>
    <div class="panel-body">
        <form method="post" id="edit_profile_form" enctype="multipart/form-data">
            <span id="message"></span>

            <div class="form-group">
                <label>Name</label>
                <input type="text" name="user_name" id="user_name" class="form-control" value="<?= $name ?>" required />
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="email" name="user_email" id="user_email" class="form-control" required value="<?= $email ?>" />
            </div>

            <div class="form-group">
                <label>Phone</label>
                <input type="text" name="user_phone" id="user_phone" class="form-control" value="<?= $phone ?>" />
            </div>

            <div class="form-group">
                <label>Address</label>
                <textarea name="user_address" id="user_address" class="form-control"><?= $address ?></textarea>
            </div>

            <div class="form-group">
                <label>Reference</label>
                <textarea name="user_reference" id="user_reference" class="form-control"><?= $reference ?></textarea>
            </div>

            <div class="form-group">
                <label>Education</label>
                <textarea name="user_education" id="user_education" class="form-control"><?= $education ?></textarea>
            </div>

            <div class="form-group">
                <label>Experience</label>
                <textarea name="user_experience" id="user_experience" class="form-control"><?= $experience ?></textarea>
            </div>

            <div class="form-group">
                <label>Training</label>
                <textarea name="user_training" id="user_training" class="form-control"><?= $training ?></textarea>
            </div>

            <div class="form-group">
                <label>Profile Picture</label>
                <input type="file" name="user_image" id="user_image" class="form-control" />
                <?php if ($image): ?>
                    <img src="<?= $image ?>" width="100" class="img-thumbnail mt-2" />
                <?php endif; ?>
            </div>

            <hr />
            <label>Leave password fields blank to keep current password.</label>
            <div class="form-group">
                <label>New Password</label>
                <input type="password" name="user_new_password" id="user_new_password" class="form-control" />
            </div>
            <div class="form-group">
                <label>Re-enter Password</label>
                <input type="password" name="user_re_enter_password" id="user_re_enter_password" class="form-control" />
                <span id="error_password"></span>
            </div>

            <div class="form-group">
                <input type="submit" name="edit_prfile" id="edit_prfile" value="Edit" class="btn btn-info" />
            </div>
        </form>
    </div>
</div>

<script>
$(document).ready(function(){
    $('#edit_profile_form').on('submit', function(event){
        event.preventDefault();
        if ($('#user_new_password').val() !== '') {
            if ($('#user_new_password').val() !== $('#user_re_enter_password').val()) {
                $('#error_password').html('<label class="text-danger">Password Not Match</label>');
                return false;
            } else {
                $('#error_password').html('');
            }
        }

        $('#edit_prfile').attr('disabled', 'disabled');

        const form_data = new FormData(this);
        $.ajax({
            url: "edit_profile.php",
            method: "POST",
            data: form_data,
            contentType: false,
            processData: false,
            success: function(data){
                $('#edit_prfile').attr('disabled', false);
                $('#user_new_password').val('');
                $('#user_re_enter_password').val('');
                $('#message').html(data);
            }
        });
    });
});
</script>

<?php include('footer.php'); ?>