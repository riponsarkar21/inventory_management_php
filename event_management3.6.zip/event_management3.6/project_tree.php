<?php
echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PHP Project Tree</title>
    <style>
        body {
            font-family: Consolas, monospace;
            background-color: #f4f4f4;
            color: #333;
            padding: 20px;
        }
        pre {
            background: #fff;
            padding: 20px;
            border-left: 5px solid #007acc;
            overflow: auto;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
    </style>
</head>
<body>
    <h2>📁 PHP Project Structure</h2>
    <pre><code>' . htmlspecialchars(trim('
event_management/
├── assets/
│   ├── css/
│   ├── js/
│   └── fonts/
│
├── config/
│   ├── database_connection.php
│   └── config.php
│
├── includes/
│   ├── header.php
│   ├── footer.php
│   ├── function.php
│   └── pdf.php
│
├── modules/
│   ├── brand/
│   │   ├── brand.php
│   │   ├── brand_action.php
│   │   └── brand_fetch.php
│   ├── category/
│   │   ├── category.php
│   │   ├── category_action.php
│   │   └── category_fetch.php
│   ├── collection/
│   │   ├── collection.php
│   │   ├── collection_action.php
│   │   └── collection_fetch.php
│   ├── customer/
│   │   ├── customer.php
│   │   ├── customer_profile.php
│   │   └── user_collections.php
│   ├── gift/
│   │   ├── gift.php
│   │   ├── gift_action.php
│   │   ├── gift_fetch.php
│   │   └── gift_pdf.php
│   ├── order/
│   │   ├── order.php
│   │   ├── order_action.php
│   │   ├── order_fetch.php
│   │   ├── user_orders.php
│   │   └── view_order.php
│   ├── product/
│   │   ├── product.php
│   │   ├── product_action.php
│   │   ├── product_fetch.php
│   │   └── load_product.php
│   ├── user/
│   │   ├── user.php
│   │   ├── user_action.php
│   │   ├── user_fetch.php
│   │   ├── user_profile.php
│   │   ├── user_idcard_pdf.php
│   │   └── user_visitingcard_pdf.php
│   ├── report/
│   │   ├── report.php
│   │   └── customized_report.php
│   └── profile/
│       ├── edit_profile.php
│       └── profile.php
│
├── uploads/
├── dompdf/
├── sql/
│   ├── db_abad89_invento.sql
│   └── inventory.sql
│
├── default.asp
├── index.php
├── login.php
├── logout.php
└── README.md
    ')) . '</code></pre>
</body>
</html>';
