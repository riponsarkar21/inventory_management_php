<?php
// todo_action.php
include('database_connection.php');

if (isset($_POST['action'])) {
    if ($_POST['action'] == 'add') {
        $bug_id = uniqid('BUG-');
        $bug_description = $_POST['bug_description'];
        $created_by = $_POST['created_by'];

        $stmt = $connect->prepare("INSERT INTO to_do_update (bug_id, bug_description, created_by) VALUES (?, ?, ?)");
        $stmt->execute([$bug_id, $bug_description, $created_by]);

        echo "Bug Report Added Successfully";
    }

    if ($_POST['action'] == 'solve') {
        $id = $_POST['id'];
        $solved_by = $_POST['solved_by'];

        $stmt = $connect->prepare("UPDATE to_do_update SET status='Solved', solved_by=?, solved_at=NOW() WHERE id=?");
        $stmt->execute([$solved_by, $id]);

        echo "Bug Marked as Solved";
    }
}