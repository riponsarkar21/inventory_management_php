<?php
// todo_fetch.php
include('database_connection.php');

$output = '<table class="table table-bordered">
<thead>
<tr>
    <th>Bug ID</th>
    <th>Description</th>
    <th>Created By</th>
    <th>Created At</th>
    <th>Status</th>
    <th>Action</th>
</tr>
</thead><tbody>';

$query = $connect->query("SELECT * FROM to_do_update ORDER BY id DESC");
foreach ($query as $row) {
    $output .= '
    <tr>
        <td>'.$row['bug_id'].'</td>
        <td>'.$row['bug_description'].'</td>
        <td>'.$row['created_by'].'</td>
        <td>'.$row['created_at'].'</td>
        <td>'.$row['status'].'</td>
        <td>';
    if ($row['status'] == 'Open') {
        $output .= '<button class="btn btn-sm btn-success solve-btn" data-id="'.$row['id'].'">Mark Solved</button>';
    } else {
        $output .= 'Solved by '.$row['solved_by'].'<br><small>'.$row['solved_at'].'</small>';
    }
    $output .= '</td></tr>';
}
$output .= '</tbody></table>';

echo $output;