📦 Project Changelog

All notable changes to this project will be documented in this file.


---

[v1.0.1] - 2025-07-05

✨ Added

Introduced Version Management Module

Publicly viewable version history with DataTables UI

master-only permission for adding/deleting versions

File upload support for changelogs/attachments

PDF export support for individual version details (via Dompdf)


⚙️ Technical

Created new table: version

AJAX-based modular integration using version.php, version_action.php, version_fetch.php, and version_pdf.php

Auto-generated version numbers (v1.0.X)



---

This changelog is automatically updated as versions are released.

