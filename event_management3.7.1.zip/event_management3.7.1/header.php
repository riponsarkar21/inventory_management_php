<?php
// header.php

require 'config/config.php';



if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
    $redirect = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header('Location: ' . $redirect);
    exit();
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$version = time();
$current_page = $_SERVER['REQUEST_URI'];
?>

<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <title>Inventory Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS -->
    <link rel="stylesheet" href="<?= BASE_URL ?>css/bootstrap.min.css?v=<?= $version ?>">
    <link rel="stylesheet" href="<?= BASE_URL ?>css/styles.css?v=<?= $version ?>">
    <link rel="stylesheet" href="<?= BASE_URL ?>css/datepicker.css?v=<?= $version ?>">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">

    <!-- ✅ JS (Correct Order) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="<?= BASE_URL ?>js/bootstrap.min.js?v=<?= $version ?>"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>

    <style>
        body { font-family: 'Segoe UI', sans-serif; margin: 0; padding: 0; }
        .sidebar {
            height: 100vh;
            width: 220px;
            position: fixed;
            background-color: #343a40;
            padding-top: 10px;
            overflow-y: auto;
            transition: width 0.3s ease;
        }

        .sidebar.collapsed { width: 60px; }
        .sidebar a {
            color: white;
            display: block;
            padding: 10px 20px;
            text-decoration: none;
        }

        .sidebar.collapsed a { padding: 10px; text-align: center; }
        .sidebar.collapsed .label { display: none; }

        .content {
            margin-left: 240px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }

        .sidebar.collapsed + .content { margin-left: 80px; }

        #sidebar-toggle {
            color: white;
            padding: 10px 20px;
            cursor: pointer;
            font-size: 18px;
        }

        html[data-theme="dark"] {
            background: #121212;
            color: #e0e0e0;
        }

        html[data-theme="dark"] .sidebar,
        html[data-theme="dark"] .sidebar a {
            background-color: #222;
            color: #ccc;
        }



/* Fix for DataTable header misalignment with scrollX */
.dataTables_wrapper .dataTables_scroll {
    overflow: auto;
}

table.dataTable {
    width: 100% !important;
}

table.dataTable thead th,
table.dataTable tbody td {
    white-space: nowrap;
}




    </style>

    <script>
        function toggleTheme() {
            const html = document.documentElement;
            html.dataset.theme = html.dataset.theme === 'dark' ? 'light' : 'dark';
            localStorage.setItem('theme', html.dataset.theme);
        }

        function toggleSidebar() {
            $('.sidebar').toggleClass('collapsed');
            localStorage.setItem('sidebarCollapsed', $('.sidebar').hasClass('collapsed') ? 'yes' : 'no');
        }

        $(document).ready(function () {
            document.documentElement.dataset.theme = localStorage.getItem('theme') || 'light';
            if (localStorage.getItem('sidebarCollapsed') === 'yes') {
                $('.sidebar').addClass('collapsed');
            }
        });
    </script>
</head>

<body>
<div class="sidebar">
    <div id="sidebar-toggle" onclick="toggleSidebar()">☰</div>
    <a href="<?= BASE_URL ?>index.php" class="<?= strpos($current_page, '/index.php') !== false ? 'active' : '' ?>">🏠 <span class="label">Home</span></a>

    <?php if ($_SESSION['type'] == 'master') { ?>

        <a href="<?= BASE_URL ?>user.php" class="<?= strpos($current_page, '/user.php') !== false ? 'active' : '' ?>">👤 <span class="label">User</span></a>

        <a href="<?= BASE_URL ?>category.php" class="<?= strpos($current_page, '/category.php') !== false ? 'active' : '' ?>">📂 <span class="label">Category</span></a>

        <a href="<?= BASE_URL ?>modules/brand/brand.php" class="<?= strpos($current_page, '/brand/brand.php') !== false ? 'active' : '' ?>">🏷 <span class="label">Brand</span></a>

        <a href="<?= BASE_URL ?>product.php" class="<?= strpos($current_page, '/product.php') !== false ? 'active' : '' ?>">📦 <span class="label">Product</span></a>

        <a href="<?= BASE_URL ?>customer.php" class="<?= strpos($current_page, '/customer.php') !== false ? 'active' : '' ?>">🧑 <span class="label">Customer</span></a>
    <?php } ?>


    <a href="<?= BASE_URL ?>order.php" class="<?= strpos($current_page, '/order.php') !== false ? 'active' : '' ?>">📝 <span class="label">Order</span></a>


    <a href="<?= BASE_URL ?>collection.php" class="<?= strpos($current_page, '/collection.php') !== false ? 'active' : '' ?>">💰 <span class="label">Collection</span></a>


    <a href="<?= BASE_URL ?>report.php" class="<?= strpos($current_page, '/report.php') !== false ? 'active' : '' ?>">📊 <span class="label">Report</span></a>


    <a href="<?= BASE_URL ?>customized_report.php" class="<?= strpos($current_page, '/customized_report.php') !== false ? 'active' : '' ?>">📋 <span class="label">Custom Report</span></a>

    <hr style="border-color: #555;">


    <a href="<?= BASE_URL ?>modules/gift/gift.php" class="<?= strpos($current_page, '/gift/gift.php') !== false ? 'active' : '' ?>">🎁 <span class="label">Gift</span></a>

   
    <hr style="border-color: #555;">

<a href="<?= BASE_URL ?>modules/version/version.php" class="<?= strpos($current_page, '/version/version.php') !== false ? 'active' : '' ?>">🔖 <span class="label">Version</span></a>

<a href="<?= BASE_URL ?>modules/todo/todo.php" class="<?= strpos($current_page, '/todo/todo.php') !== false ? 'active' : '' ?>">📌 <span class="label">Todo</span></a>

<a href="<?= BASE_URL ?>modules/bug/bug.php" class="<?= strpos($current_page, '/bug/bug.php') !== false ? 'active' : '' ?>">🐞 <span class="label">Bug</span></a>




    <a href="#" onclick="toggleTheme()">🌓 <span class="label">Toggle Theme</span></a>


    <hr style="border-color: #555;">
    <a href="<?= BASE_URL ?>profile.php" class="<?= strpos($current_page, '/profile.php') !== false ? 'active' : '' ?>">👤 <span class="label"><?= $_SESSION['user_name'] ?></span></a>
    <a href="#" data-toggle="modal" data-target="#logoutModal">🚪 <span class="label">Logout</span></a>
</div>

<div class="content">
