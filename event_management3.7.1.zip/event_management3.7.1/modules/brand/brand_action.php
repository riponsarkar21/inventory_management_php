<?php
// modules/brand/brand_action.php

include(__DIR__ . '/../../database_connection.php');

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (isset($_POST['btn_action'])) {
    if ($_POST['btn_action'] === 'Add') {
        $query = "INSERT INTO brand (category_id, brand_name) VALUES (:category_id, :brand_name)";
        $statement = $connect->prepare($query);
        $statement->execute([
            ':category_id' => $_POST['category_id'],
            ':brand_name' => $_POST['brand_name']
        ]);
        echo $statement->rowCount() > 0 ? 'Brand Name Added' : 'Failed to add brand.';
    }

    if ($_POST['btn_action'] === 'fetch_single') {
        $query = "SELECT * FROM brand WHERE brand_id = :brand_id";
        $statement = $connect->prepare($query);
        $statement->execute([':brand_id' => $_POST['brand_id']]);
        $row = $statement->fetch(PDO::FETCH_ASSOC);
        echo json_encode([
            'category_id' => $row['category_id'],
            'brand_name' => $row['brand_name']
        ]);
    }

    if ($_POST['btn_action'] === 'Edit') {
        $query = "UPDATE brand SET category_id = :category_id, brand_name = :brand_name WHERE brand_id = :brand_id";
        $statement = $connect->prepare($query);
        $statement->execute([
            ':category_id' => $_POST['category_id'],
            ':brand_name' => $_POST['brand_name'],
            ':brand_id' => $_POST['brand_id']
        ]);
        echo $statement->rowCount() > 0 ? 'Brand Name Edited' : 'No changes made.';
    }

    if ($_POST['btn_action'] === 'status') {
        $new_status = ($_POST['status'] === 'active') ? 'inactive' : 'active';
        $query = "UPDATE brand SET brand_status = :brand_status WHERE brand_id = :brand_id";
        $statement = $connect->prepare($query);
        $statement->execute([
            ':brand_status' => $new_status,
            ':brand_id' => $_POST['brand_id']
        ]);
        echo $statement->rowCount() > 0 ? "Brand status changed to {$new_status}" : 'Failed to change status.';
    }

    if ($_POST['btn_action'] === 'delete') {
        $query = "DELETE FROM brand WHERE brand_id = :brand_id";
        $statement = $connect->prepare($query);
        $statement->execute([':brand_id' => $_POST['brand_id']]);
        echo $statement->rowCount() > 0 ? 'Brand deleted successfully' : 'Failed to delete brand.';
    }
}
?>
