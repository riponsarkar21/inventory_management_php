// modules/bug/bug.js
$(document).ready(function(){
    if ($.fn.DataTable.isDataTable('#bug_data')) {
        $('#bug_data').DataTable().destroy();
    }

    const table = $('#bug_data').DataTable({
        "ajax": "/modules/bug/bug_fetch.php",
        "scrollX": true,
        "order": [[0, "desc"]],
        "columns": [
            { "data": "bug_id" },
            { "data": "bug_title" },
            { "data": "bug_description" },
            {
                "data": "screenshot_image",
                "render": function(data) {
                    return data ? `<img src="${data}" height="50">` : '';
                }
            },
            { "data": "status" },
            { "data": "created_by" },
            { "data": "created_at" },
            { "data": "solved_by" },
            { "data": "solved_at" },
            {
                "data": null,
                "orderable": false,
                "render": function(row) {
                    return `
                        <button class="btn btn-info btn-xs change-status" data-id="${row.bug_id}">Status</button>
                        <button class="btn btn-primary btn-xs update-entry" data-id="${row.bug_id}">Update</button>
                        <button class="btn btn-default btn-xs generate-pdf" data-id="${row.bug_id}">PDF</button>
                        <button class="btn btn-warning btn-xs cancel-entry" data-id="${row.bug_id}">Cancel</button>
                        <button class="btn btn-danger btn-xs delete" data-id="${row.bug_id}">Delete</button>
                    `;
                }
            }
        ],
        "dom":
            "<'row'<'col-sm-6'l><'col-sm-6'f>>" +
            "<'row'<'col-sm-12'tr>>" +
            "<'row'<'col-sm-5'i><'col-sm-7'p>>" +
            "<'row'<'col-sm-12 text-center mt-3'B>>",
        "buttons": ['copy', 'csv', 'excel', 'pdf', 'print']
    });

    $('#bug_form').on('submit', function(e){
        e.preventDefault();
        $('#action').prop('disabled', true);
        const formData = new FormData(this);
        $.ajax({
            url: "/modules/bug/bug_action.php",
            method: "POST",
            data: formData,
            contentType: false,
            processData: false,
            success: function(data){
                $('#bug_form')[0].reset();
                $('#bugModal').modal('hide');
                $('#alert_action').html('<div class="alert alert-success">'+data+'</div>');
                $('#action').prop('disabled', false);
                $('#action').val('Add');
                $('#bug_id').val('');
                table.ajax.reload();
            }
        });
    });

    $(document).on('click', '.delete', function(){
        if(confirm("Are you sure you want to delete this bug?")) {
            const id = $(this).data('id');
            $.post("/modules/bug/bug_action.php", { action: "delete", id: id }, function(data){
                $('#alert_action').html('<div class="alert alert-danger">'+data+'</div>');
                table.ajax.reload();
            });
        }
    });

    $(document).on('click', '.change-status', function(){
        const id = $(this).data('id');
        $.post("/modules/bug/bug_action.php", { action: "change_status", id: id }, function(data){
            $('#alert_action').html('<div class="alert alert-info">'+data+'</div>');
            table.ajax.reload();
        });
    });

    $(document).on('click', '.cancel-entry', function(){
        const id = $(this).data('id');
        if (confirm("Are you sure you want to cancel this bug? This action will mark it as 'Cancelled'.")) {
            $.post("/modules/bug/bug_action.php", { action: "cancel", id: id }, function(data){
                $('#alert_action').html('<div class="alert alert-warning">'+data+'</div>');
                table.ajax.reload();
            });
        }
    });

    $(document).on('click', '.generate-pdf', function(){
        const id = $(this).data('id');
        window.open("/modules/bug/bug_pdf.php?id=" + id, '_blank');
    });

    $(document).on('click', '.update-entry', function(){
        const id = $(this).data('id');
        $.post("/modules/bug/bug_action.php", { action: "fetch_single", id: id }, function(data){
            const d = JSON.parse(data);
            $('#bug_id').val(d.bug_id);
            $('#bug_title').val(d.bug_title);
            $('#bug_description').val(d.bug_description);
            $('#action').val('Update');
            $('#bugModal').modal('show');
        });
    });
});
