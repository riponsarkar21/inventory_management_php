<?php
// modules/version/version_fetch.php

include('../../database_connection.php');
session_start();

$query = "SELECT * FROM version";

if (!empty($_POST['search']['value'])) {
    $query .= ' WHERE version_number LIKE "%' . $_POST['search']['value'] . '%"';
    $query .= ' OR features LIKE "%' . $_POST['search']['value'] . '%"';
    $query .= ' OR changelog LIKE "%' . $_POST['search']['value'] . '%"';
}

$order_column = array('version_number', 'release_date', 'features', 'changelog', 'file_path', 'created_by', 'created_at');

if (isset($_POST['order'])) {
    $query .= ' ORDER BY ' . $order_column[$_POST['order'][0]['column']] . ' ' . $_POST['order'][0]['dir'] . ' ';
} else {
    $query .= ' ORDER BY version_id DESC ';
}

$query1 = '';
if ($_POST['length'] != -1) {
    $query1 .= ' LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}

$statement = $connect->prepare($query);
$statement->execute();
$filtered_rows = $statement->rowCount();

$result = $connect->query($query . $query1)->fetchAll(PDO::FETCH_ASSOC);

$data = array();
foreach ($result as $row) {
    $file_link = $row['file_path'] ? '<a href="../../' . $row['file_path'] . '" target="_blank">Download</a>' : 'N/A';
    $pdf_link = '<a href="version_pdf.php?id=' . $row['version_id'] . '" class="btn btn-xs btn-primary" target="_blank">PDF</a>';
    $delete_btn = ($_SESSION['type'] == 'master') ? '<button type="button" name="delete" id="' . $row['version_id'] . '" class="btn btn-danger btn-xs delete">Delete</button>' : '';

    $data[] = array(
        $row['version_number'],
        $row['release_date'],
        nl2br($row['features']),
        nl2br($row['changelog']),
        $file_link,
        $row['created_by'],
        $row['created_at'],
        $pdf_link,
        $delete_btn
    );
}

$output = array(
    "draw"    => intval($_POST['draw']),
    "recordsTotal"  => $filtered_rows,
    "recordsFiltered" => $filtered_rows,
    "data"    => $data
);

echo json_encode($output);