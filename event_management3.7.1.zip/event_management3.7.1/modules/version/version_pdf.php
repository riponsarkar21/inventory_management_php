<?php
// modules/version/version_pdf.php

require_once '../../dompdf/autoload.inc.php';
use Dompdf\Dompdf;

include('../../database_connection.php');

if (!isset($_GET['id'])) {
    die('Invalid version ID.');
}

$version_id = intval($_GET['id']);
$stmt = $connect->prepare("SELECT * FROM version WHERE version_id = ?");
$stmt->execute([$version_id]);
$version = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$version) {
    die('Version not found.');
}

$html = '<h2 style="text-align:center;">Version Details</h2>';
$html .= '<table width="100%" border="1" cellpadding="10" cellspacing="0">';
$html .= '<tr><td><strong>Version Number</strong></td><td>' . $version['version_number'] . '</td></tr>';
$html .= '<tr><td><strong>Release Date</strong></td><td>' . $version['release_date'] . '</td></tr>';
$html .= '<tr><td><strong>Created By</strong></td><td>' . $version['created_by'] . '</td></tr>';
$html .= '<tr><td><strong>Created At</strong></td><td>' . $version['created_at'] . '</td></tr>';
$html .= '<tr><td><strong>Features</strong></td><td>' . nl2br($version['features']) . '</td></tr>';
$html .= '<tr><td><strong>Changelog</strong></td><td>' . nl2br($version['changelog']) . '</td></tr>';
if (!empty($version['file_path'])) {
    $html .= '<tr><td><strong>Attached File</strong></td><td>' . $version['file_path'] . '</td></tr>';
}
$html .= '</table>';

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream('Version_' . $version['version_number'] . '.pdf', array('Attachment' => false));
exit;