<?php
// order.php

include('database_connection.php');
include('function.php');

if (!isset($_SESSION['type'])) {
    header('location:login.php');
}

include('header.php');
?>

<!-- Additional CSS/JS for DataTables Buttons -->
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
<link rel="stylesheet" href="css/datepicker.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.2/css/bootstrap-select.min.css">

<script src="js/bootstrap-datepicker1.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.2/js/bootstrap-select.min.js"></script>

<script>
$(document).ready(function(){
    $('#inventory_order_date').datepicker({
        format: "yyyy-mm-dd",
        autoclose: true
    });
});
</script>

<span id="alert_action"></span>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-lg-10">
                        <h3 class="panel-title">Order List</h3>
                    </div>
                    <div class="col-lg-2 text-right">
                        <button type="button" name="add" id="add_button" class="btn btn-success btn-xs">Add</button>
                    </div>
                </div>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table id="order_data" class="table table-bordered table-striped w-100">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Customer Name</th>
                                <th>Total Amount</th>
                                <th>Payment Status</th>
                                <th>Order Status</th>
                                <th>Order Date</th>
                                <?php if ($_SESSION['type'] == 'master') { echo '<th>Created By</th>'; } ?>
                                <th>Visibility</th>
                                <th>Invoice</th>
                                <th>Update</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Order Modal -->
<div id="orderModal" class="modal fade">
    <div class="modal-dialog">
        <form method="post" id="order_form">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-plus"></i> Create Order</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label>Enter Receiver Name</label>
                            <input type="text" name="inventory_order_name" id="inventory_order_name" class="form-control" required />
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Date</label>
                            <input type="text" name="inventory_order_date" id="inventory_order_date" class="form-control" required />
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Enter Receiver Address</label>
                        <textarea name="inventory_order_address" id="inventory_order_address" class="form-control" required></textarea>
                    </div>
                    <div class="form-group">
                        <label>Enter Product Details</label>
                        <hr />
                        <span id="span_product_details"></span>
                        <hr />
                    </div>
                    <div class="form-group">
                        <label>Select Payment Status</label>
                        <select name="payment_status" id="payment_status" class="form-control">
                            <option value="cash">Cash</option>
                            <option value="credit">Credit</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="inventory_order_id" id="inventory_order_id" />
                    <input type="hidden" name="btn_action" id="btn_action" />
                    <input type="submit" name="action" id="action" class="btn btn-info" value="Add" />
                </div>
            </div>
        </form>
    </div>
</div>

<script>
$(document).ready(function() {
    const orderdataTable = $('#order_data').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: "order_fetch.php",
            type: "POST"
        },
        "order": [[0, "desc"]],
        columnDefs: [
            <?php
            if ($_SESSION["type"] == 'master') {
                echo '{ targets: [7,8,9,10], orderable: false },';
            } else {
                echo '{ targets: [7,8], orderable: false },';
            }
            ?>
        ],
        lengthMenu: [[5, 10, 25, 50, 100, 1000], [5, 10, 25, 50, 100, 1000]],
        pageLength: 10,
        dom:
            "<'row'<'col-sm-6'l><'col-sm-6'f>>" +
            "<'row'<'col-sm-12'tr>>" +
            "<'row'<'col-sm-5'i><'col-sm-7'p>>" +
            "<'row'<'col-sm-12 text-center mt-3'B>>",
        buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
    });

    $('#add_button').click(function() {
        $('#orderModal').modal('show');
        $('#order_form')[0].reset();
        $('.modal-title').html("<i class='fa fa-plus'></i> Create Order");
        $('#action').val('Add');
        $('#btn_action').val('Add');
        $('#span_product_details').html('');
        add_product_row();
    });

    function add_product_row(count = '') {
        let html = `<span id="row${count}"><div class="row">`;
        html += `<div class="col-md-8"><select name="product_id[]" id="product_id${count}" class="form-control selectpicker" data-live-search="true" required>`;
        html += `<?php echo fill_product_list($connect); ?>`;
        html += `</select><input type="hidden" name="hidden_product_id[]" id="hidden_product_id${count}" /></div>`;
        html += `<div class="col-md-3"><input type="text" name="quantity[]" class="form-control" required /></div>`;
        html += `<div class="col-md-1">`;
        html += count === '' ? `<button type="button" name="add_more" id="add_more" class="btn btn-success btn-xs">+</button>` :
            `<button type="button" name="remove" id="${count}" class="btn btn-danger btn-xs remove">-</button>`;
        html += `</div></div></div><br /></span>`;
        $('#span_product_details').append(html);
        $('.selectpicker').selectpicker();
    }

    let count = 0;
    $(document).on('click', '#add_more', function() {
        count++;
        add_product_row(count);
    });

    $(document).on('click', '.remove', function() {
        $('#row' + $(this).attr("id")).remove();
    });

    $('#order_form').submit(function(event) {
        event.preventDefault();
        $('#action').prop('disabled', true);
        $.post("order_action.php", $(this).serialize(), function(data) {
            $('#order_form')[0].reset();
            $('#orderModal').modal('hide');
            $('#alert_action').html('<div class="alert alert-success">' + data + '</div>');
            $('#action').prop('disabled', false);
            orderdataTable.ajax.reload();
        });
    });

    $(document).on('click', '.update', function() {
        const id = $(this).attr("id");
        $.post("order_action.php", { inventory_order_id: id, btn_action: "fetch_single" }, function(data) {
            $('#orderModal').modal('show');
            $('#inventory_order_name').val(data.inventory_order_name);
            $('#inventory_order_date').val(data.inventory_order_date);
            $('#inventory_order_address').val(data.inventory_order_address);
            $('#span_product_details').html(data.product_details);
            $('#payment_status').val(data.payment_status);
            $('.modal-title').html("<i class='fa fa-pencil-square-o'></i> Edit Order");
            $('#inventory_order_id').val(id);
            $('#action').val('Edit');
            $('#btn_action').val('Edit');
        }, 'json');
    });

    $(document).on('click', '.status', function() {
        if (!confirm("Are you sure you want to change status?")) return;
        const id = $(this).attr("id");
        const status = $(this).data("status");
        $.post("order_action.php", { inventory_order_id: id, status: status, btn_action: "status" }, function(data) {
            $('#alert_action').html('<div class="alert alert-info">' + data + '</div>');
            orderdataTable.ajax.reload();
        });
    });

    $(document).on('click', '.delete', function() {
        if (!confirm("Are you sure you want to delete order?")) return;
        const id = $(this).attr("id");
        const status = $(this).data("status");
        $.post("order_action.php", { inventory_order_id: id, status: status, btn_action: "delete" }, function(data) {
            $('#alert_action').html('<div class="alert alert-danger">' + data + '</div>');
            orderdataTable.ajax.reload();
        });
    });
});
</script>

<?php include('footer.php'); ?>
