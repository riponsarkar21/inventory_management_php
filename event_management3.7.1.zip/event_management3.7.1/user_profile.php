// --- user_profile.php ---
<?php
include('database_connection.php');

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die('Invalid ID');
}

$stmt = $connect->prepare("SELECT * FROM user_details WHERE user_id = ?");
$stmt->execute([$_GET['id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    die('User not found');
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Profile</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h2>User Profile</h2>
    <div class="panel panel-default">
        <div class="panel-heading">Profile Details</div>
        <div class="panel-body">
            <div class="row">
                <div class="col-md-4">
                    <?php if ($user['user_image']) : ?>
                        <img src="<?= $user['user_image'] ?>" class="img-thumbnail" width="150">
                    <?php else : ?>
                        <img src="uploads/default.png" class="img-thumbnail" width="150">
                    <?php endif; ?>
                </div>
                <div class="col-md-8">
                    <p><strong>Name:</strong> <?= $user['user_name'] ?></p>
                    <p><strong>Email:</strong> <?= $user['user_email'] ?></p>
                    <p><strong>Phone:</strong> <?= $user['user_phone'] ?></p>
                    <p><strong>Address:</strong> <?= $user['user_address'] ?></p>
                    <p><strong>Role:</strong> <?= $user['user_type'] ?></p>
                    <p><strong>Status:</strong> <?= $user['user_status'] ?></p>
                    <p><strong>Reference:</strong> <?= $user['user_reference'] ?></p>
                    <p><strong>Education:</strong> <?= $user['user_education'] ?></p>
                    <p><strong>Experience:</strong> <?= $user['user_experience'] ?></p>
                    <p><strong>Training:</strong> <?= $user['user_training'] ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>