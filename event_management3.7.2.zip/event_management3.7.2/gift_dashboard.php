<?php
//gift_dashboard.php 
include('database_connection.php');
// include('gift_function.php');
include('function.php');

if(!isset($_SESSION["type"]))
{
	header("location:login.php");
}

include('header.php');

?>
	<br />
	<div class="row">
	<?php
	if (in_array($_SESSION['type'], ['Super Master', 'Master', 'Gift Admin']))
	{
	?>

    <!-- <hr style="border-color: #555;"> -->

	<div class="col-md-3">
		<div class="panel panel-default">
			<div class="panel-heading"><strong>Total Guest</strong> Active </div>
			<div class="panel-body" align="center">
				<h1><?php 
				echo count_total_guest($connect); 
				?></h1>
			</div>
		</div>
	</div>
	<div class="col-md-3">
		<div class="panel panel-default">
			<div class="panel-heading"><strong>Total Gift </strong>(Money)</div>
			<div class="panel-body" align="center">
				<h1>
					<?php 
					echo count_total_category($connect); 
					?>
				</h1>
			</div>
		</div>
	</div>
	<div class="col-md-3">
		<div class="panel panel-default">
			<div class="panel-heading"><strong>Total Brand</strong></div>
			<div class="panel-body" align="center">
				<h1><?php echo count_total_brand($connect); ?></h1>
			</div>
		</div>
	</div>
	<div class="col-md-3">
		<div class="panel panel-default">
			<div class="panel-heading"><strong>Total Item in Stock</strong></div>
			<div class="panel-body" align="center">
				<h1><?php echo count_total_product($connect); ?></h1>
			</div>
		</div>
	</div>




	<!-- --------------------------------- Gift Value and Number of Gift Box By All User-  (For Master View)----------------------------------------------- -->
		<div class="col-md-3">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Gift Collection Value<br />ALL User</strong><br />(Cash & Others) <strong>Total Received</strong></div>
				<div class="panel-body" align="center">
					<h1>$
						<?php 
							echo count_total_gift_collection_value_all_money_by_all_user($connect); 

						?>
					</h1>
				</div>
			</div>
		</div>

		<div class="col-md-3">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Gift Collection Value <br />ALL User</strong><br />Inactive</div>
				<div class="panel-body" align="center">
					<h1>$
						<?php 
							echo count_total_gift_collection_value_inactive_by_all_user($connect); 
						?>
					</h1>
				</div>
			</div>
		</div>		<div class="col-md-3">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Gift Collection Value <br />ALL User</strong><br />Cancelled</div>
				<div class="panel-body" align="center">
					<h1>$
						<?php 
							echo count_total_gift_collection_value_cancelled_by_all_user($connect); 
						?>
					</h1>
				</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Number of Gift Box<br />ALL User</strong><br />Gift Box, Sharee, Toys, or others</div>
				<div class="panel-body" align="center">
					<h1>
						<?php 
							echo count_total_number_of_giftbox_by_all_user($connect); 
						?>
					</h1>
				</div>
			</div>
		</div>

		<hr />



<!-- --------------------------------- Gift Money By All User ----- (For Master View) -------------------------------------- -->

		<div class="col-md-2">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Gift Collection Value<br />All User</strong><br />Only Active</div>
				<div class="panel-body" align="center">
					<h1>$
						<?php 
							echo count_total_gift_collection_value_by_all_user($connect); 
						?>
					</h1>
				</div>
			</div>
		</div>
		<div class="col-md-2">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Gift Collection Value<br />All User</strong><br /> (Cash)</div>
				<div class="panel-body" align="center">
					<h1>$
						<?php 
							echo count_total_gift_cash_collection_value_by_all_user($connect); 
						?>
					</h1>
				</div>
			</div>
		</div>
		<div class="col-md-2">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Gift Collection Value<br />All User</strong><br /> (Bank)</div>
				<div class="panel-body" align="center">
					<h1>$
						<?php 
							echo count_total_gift_bank_collection_value_by_all_user($connect); 
						?>
					</h1>
				</div>
			</div>
		</div>
		<div class="col-md-2">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Gift Collection Value<br />All User</strong><br /> (Bkash)</div>
				<div class="panel-body" align="center">
					<h1>$
						<?php 
							echo count_total_gift_bkash_collection_value_by_all_user($connect); 
						?>
					</h1>
				</div>
			</div>
		</div>		
		<div class="col-md-2">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Gift Collection Value<br />All User</strong><br /> (Nagad)</div>
				<div class="panel-body" align="center">
					<h1>$
						<?php 
							echo count_total_gift_nagad_collection_value_by_all_user($connect); 
						?>
					</h1>
				</div>
			</div>
		</div>
		<div class="col-md-2">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Gift Collection Value<br />All User</strong><br /> (Others)</div>
				<div class="panel-body" align="center">
					<h1>$
						<?php 
							echo count_total_gift_others_collection_value_by_all_user($connect); 
						?>
					</h1>
				</div>
			</div>
		</div>
		<hr />

	<?php
	}
	?>
<!-- --------------------------------- Gift Summery By You / by User------------------------------------------------ -->
		<div class="col-md-3">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Gift Collection Value</strong><br />(Cash & Others) <strong>Total Received</strong></div>
				<div class="panel-body" align="center">
					<h1>$
						<?php 
							echo count_total_gift_collection_value_all_money($connect); 

						?>
					</h1>
				</div>
			</div>
		</div>

		<div class="col-md-3">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Gift Collection Value </strong><br />Inactive</div>
				<div class="panel-body" align="center">
					<h1>$
						<?php 
							echo count_total_gift_collection_value_inactive($connect); 
						?>
					</h1>
				</div>
			</div>
		</div>		<div class="col-md-3">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Gift Collection Value </strong><br />Cancelled</div>
				<div class="panel-body" align="center">
					<h1>$
						<?php 
							echo count_total_gift_collection_value_cancelled($connect); 
						?>
					</h1>
				</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Number of Gift Box</strong><br />Gift Box, Sharee, Toys, or others</div>
				<div class="panel-body" align="center">
					<h1>
						<?php 
							echo count_total_number_of_giftbox($connect); 
						?>
					</h1>
				</div>
			</div>
		</div>

		<hr />




	<!-- --------------------------------- Gift Money By You / by User ------------------------------------------- -->

		<div class="col-md-2">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Gift Collection Value</strong><br />Only Active</div>
				<div class="panel-body" align="center">
					<h1>$
						<?php 
							echo count_total_gift_collection_value_by_user($connect); 
						?>
					</h1>
				</div>
			</div>
		</div>
		<div class="col-md-2">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Gift Collection Value</strong><br /> (Cash)</div>
				<div class="panel-body" align="center">
					<h1>$
						<?php 
							echo count_total_gift_cash_collection_value_by_user($connect); 
						?>
					</h1>
				</div>
			</div>
		</div>
		<div class="col-md-2">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Gift Collection Value</strong><br /> (Bank)</div>
				<div class="panel-body" align="center">
					<h1>$
						<?php 
							echo count_total_gift_bank_collection_value_by_user($connect); 
						?>
					</h1>
				</div>
			</div>
		</div>
		<div class="col-md-2">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Gift Collection Value</strong><br /> (Bkash)</div>
				<div class="panel-body" align="center">
					<h1>$
						<?php 
							echo count_total_gift_bkash_collection_value_by_user($connect); 
						?>
					</h1>
				</div>
			</div>
		</div>		
		<div class="col-md-2">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Gift Collection Value</strong><br /> (Nagad)</div>
				<div class="panel-body" align="center">
					<h1>$
						<?php 
							echo count_total_gift_nagad_collection_value_by_user($connect); 
						?>
					</h1>
				</div>
			</div>
		</div>
		<div class="col-md-2">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Gift Collection Value</strong><br /> (Others)</div>
				<div class="panel-body" align="center">
					<h1>$
						<?php 
							echo count_total_gift_others_collection_value_by_user($connect); 
						?>
					</h1>
				</div>
			</div>
		</div>
		<hr />

	<!---------------------------------- Total Order Value User wise ---------------------------------->

		<?php
		if($_SESSION['type'] == 'master')
		{
		?>
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Order Value User wise</strong></div>
				<div class="panel-body" align="center">
					<?php echo get_user_wise_total_order($connect); ?>
				</div>
			</div>
		</div>
		<?php
		}
		?>

		<hr />

	<!---------------------------------- Total Collection Value User wise ---------------------------------->
	
		<?php
		if($_SESSION['type'] == 'master')
		{
		?>
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Collection Value User wise</strong></div>
				<div class="panel-body" align="center">
					<?php 
						echo get_user_wise_total_collection($connect); 
					?>
				</div>
			</div>
		</div>
		<?php
		}
		?>
	</div>

<?php
include("footer.php");
?>