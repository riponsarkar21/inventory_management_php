<?php
// init/init_version_sql.php
// Run this file once to create the `version` table

include(__DIR__ . '/../database_connection.php');

$query = "
CREATE TABLE IF NOT EXISTS version (
    version_id INT AUTO_INCREMENT PRIMARY KEY,
    version_number VARCHAR(20) NOT NULL,
    release_date DATE NOT NULL,
    features TEXT,
    changelog TEXT,
    file_path VARCHAR(255),
    created_by VARCHAR(100),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
";

if ($connect->exec($query) !== false) {
    echo "<p style='color:green;'>✅ Version table created successfully.</p>";
} else {
    echo "<p style='color:red;'>❌ Failed to create version table.</p>";
}