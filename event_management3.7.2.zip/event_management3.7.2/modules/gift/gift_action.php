<?php
// modules/gift/gift_action.php

include('../../database_connection.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'delete') {
        $stmt = $connect->prepare("DELETE FROM gift WHERE gift_id = ?");
        $stmt->execute([$_POST['id']]);
        echo "Gift entry deleted.";
        exit;
    }

    if ($action === 'change_status') {
        $stmt = $connect->prepare("UPDATE gift SET status = IF(status='Active','Inactive','Active') WHERE gift_id = ?");
        $stmt->execute([$_POST['id']]);
        echo "Status updated.";
        exit;
    }

    if ($action === 'cancel') {
        $stmt = $connect->prepare("UPDATE gift SET status = 'Cancelled' WHERE gift_id = ?");
        $stmt->execute([$_POST['id']]);
        echo "Gift entry cancelled.";
        exit;
    }

    if ($action === 'fetch_single') {
        $stmt = $connect->prepare("SELECT * FROM gift WHERE gift_id = ?");
        $stmt->execute([$_POST['id']]);
        echo json_encode($stmt->fetch(PDO::FETCH_ASSOC));
        exit;
    }

    $image_path = '';
    if (!empty($_FILES['gift_image']['name'])) {
        $upload_dir = '../../uploads/gift/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $guest_name = preg_replace('/[^A-Za-z0-9]/', '', strtolower(explode(' ', $_POST['guest_name'])[0] ?? 'guest'));
        $address_word = preg_replace('/[^A-Za-z0-9]/', '', strtolower(explode(' ', $_POST['address'])[0] ?? 'address'));
        $timestamp = time();
        $extension = pathinfo($_FILES['gift_image']['name'], PATHINFO_EXTENSION);
        $image_name = "{$guest_name}-{$address_word}-{$timestamp}.{$extension}";
        $image_path = $upload_dir . $image_name;

        move_uploaded_file($_FILES['gift_image']['tmp_name'], $image_path);

        // Relative path for DB
        $image_path = 'uploads/gift/' . $image_name;
    }

    if (!empty($_POST['gift_id'])) {
        // UPDATE MODE
        if (empty($image_path)) {
            $stmt = $connect->prepare("SELECT gift_image FROM gift WHERE gift_id = ?");
            $stmt->execute([$_POST['gift_id']]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $image_path = $row['gift_image'] ?? '';
        }

        $stmt = $connect->prepare("
            UPDATE gift SET guest_name=?, phone=?, address=?, relation=?, gift_type=?, amount=?, payment_method=?, gift_details=?, gift_image=? 
            WHERE gift_id=?
        ");
        $stmt->execute([
            $_POST['guest_name'],
            $_POST['phone'],
            $_POST['address'],
            $_POST['relation'],
            $_POST['gift_type'],
            !empty($_POST['amount']) ? $_POST['amount'] : null,
            $_POST['payment_method'] ?? '',
            $_POST['gift_details'] ?? '',
            $image_path,
            $_POST['gift_id']
        ]);

        echo "Gift entry updated successfully.";

    } else {
        // NEW ENTRY MODE
        $created_by = $_SESSION['user_name'] ?? 'Unknown';
        $user_id = $_SESSION['user_id'] ?? null;

        if ($user_id === null) {
            echo "Error: User not logged in.";
            exit;
        }

        $stmt = $connect->prepare("
            INSERT INTO gift (
                user_id, guest_name, phone, address, relation, gift_type,
                amount, payment_method, gift_details, gift_image,
                status, created_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', ?)
        ");

        $stmt->execute([
            $user_id,
            $_POST['guest_name'],
            $_POST['phone'],
            $_POST['address'],
            $_POST['relation'],
            $_POST['gift_type'],
            !empty($_POST['amount']) ? $_POST['amount'] : null,
            $_POST['payment_method'] ?? '',
            $_POST['gift_details'] ?? '',
            $image_path,
            $created_by
        ]);

        echo "Gift entry added successfully.";
    }
}
