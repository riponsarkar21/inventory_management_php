<?php
// gift_dashboard.php
include('../../database_connection.php');
include('../../header.php');

// Prepare summary stats
$total_gifts = $connect->query("SELECT COUNT(*) FROM gift")->fetchColumn();
$total_cash = $connect->query("SELECT SUM(amount) FROM gift WHERE gift_type IN ('money', 'both')")->fetchColumn();
$total_items = $connect->query("SELECT COUNT(*) FROM gift WHERE gift_type IN ('gift', 'both')")->fetchColumn();
$total_guests = $connect->query("SELECT COUNT(DISTINCT phone) FROM gift")->fetchColumn();
?>

<style>
    .card {
        border-radius: 12px;
    }
    .card h3 {
        font-size: 24px;
        margin: 0;
    }
    .card h5 {
        font-size: 16px;
        color: #fff;
    }
</style>

<div class="container-fluid mt-4">
    <h3 class="mb-4">🎁 Gift Dashboard</h3>

    <!-- Stats Summary -->
    <div class="row">
        <!-- Total Gifts -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card bg-primary text-white shadow text-center p-3">
                <h5>Total Gifts</h5>
                <h3><?= $total_gifts ?></h3>
            </div>
        </div>

        <!-- Total Cash -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card bg-success text-white shadow text-center p-3">
                <h5>Total Cash</h5>
                <h3>৳ <?= number_format($total_cash ?: 0, 2) ?></h3>
            </div>
        </div>

        <!-- Total Items -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card bg-warning text-white shadow text-center p-3">
                <h5>Total Gift Items</h5>
                <h3><?= $total_items ?></h3>
            </div>
        </div>

        <!-- Total Guests -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card bg-danger text-white shadow text-center p-3">
                <h5>Unique Guests</h5>
                <h3><?= $total_guests ?></h3>
            </div>
        </div>
    </div>

    <!-- Recent Gifts Table -->
    <div class="panel panel-default mt-4">
        <div class="panel-heading">
            <h4 class="panel-title">🕒 Recent Gifts</h4>
        </div>
        <div class="panel-body table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Guest Name</th>
                        <th>Phone</th>
                        <th>Type</th>
                        <th>Amount</th>
                        <th>Gift</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $stmt = $connect->query("SELECT * FROM gift ORDER BY gift_id DESC LIMIT 5");
                    foreach ($stmt as $row):
                    ?>
                        <tr>
                            <td><?= $row['gift_id'] ?></td>
                            <td><?= $row['guest_name'] ?></td>
                            <td><?= $row['phone'] ?></td>
                            <td><?= ucfirst($row['gift_type']) ?></td>
                            <td><?= $row['amount'] ? '৳ ' . number_format($row['amount'], 2) : '-' ?></td>
                            <td><?= $row['gift_details'] ?: '-' ?></td>
                            <td><?= $row['status'] ?: 'Pending' ?></td>
                            <td><?= date('d-M-Y', strtotime($row['created_at'] ?? '')) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include('../../footer.php'); ?>
