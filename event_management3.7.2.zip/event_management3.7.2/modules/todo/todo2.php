<?php
// todo.php

include('database_connection.php');

// Create the table if it doesn't exist
$create_table_sql = "
CREATE TABLE IF NOT EXISTS to_do_update (
    id INT AUTO_INCREMENT PRIMARY KEY,
    bug_id VARCHAR(50) NOT NULL,
    bug_description TEXT NOT NULL,
    created_by VARCHAR(100),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    solved_by VARCHAR(100),
    solved_at DATETIME NULL,
    status ENUM('Open','Solved') DEFAULT 'Open'
)";
$connect->exec($create_table_sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>QC Bug To-Do List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="container mt-4">
    <h2 class="mb-3">Quality Control Bug To-Do List</h2>
    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#bugModal">Add Bug</button>
    <div id="alert_action"></div>
    <div id="bug_table"></div>
</div>

<!-- Modal -->
<div class="modal fade" id="bugModal" tabindex="-1" aria-labelledby="bugModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form id="bug_form">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="bugModalLabel">Add New Bug</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="mb-3">
                <label for="bug_description">Bug Description</label>
                <textarea name="bug_description" class="form-control" required></textarea>
            </div>
            <input type="hidden" name="created_by" value="QC_User">
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Add Bug</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </form>
  </div>
</div>

<script>
$(document).ready(function(){
    load_data();

    function load_data(){
        $.ajax({
            url: "todo_fetch.php",
            method: "POST",
            success: function(data){
                $('#bug_table').html(data);
            }
        });
    }

    $('#bug_form').on('submit', function(e){
        e.preventDefault();
        $.ajax({
            url: 'todo_action.php',
            method: 'POST',
            data: $(this).serialize() + "&action=add",
            success: function(response){
                $('#bug_form')[0].reset();
                $('#bugModal').modal('hide');
                $('#alert_action').html('<div class="alert alert-success">'+response+'</div>');
                load_data();
            }
        });
    });

    $(document).on('click', '.solve-btn', function(){
        const id = $(this).data('id');
        $.post('todo_action.php', { action: "solve", id: id, solved_by: "QC_User" }, function(response){
            $('#alert_action').html('<div class="alert alert-info">'+response+'</div>');
            load_data();
        });
    });
});
</script>
</body>
</html>