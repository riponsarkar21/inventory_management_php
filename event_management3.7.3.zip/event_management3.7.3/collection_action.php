<?php
// collection_action.php

include('database_connection.php');
include('function.php');

if (isset($_POST['btn_action'])) {

	if ($_POST['btn_action'] == 'Add') {
		$query = "
		INSERT INTO collection (user_id, inventory_order_id, collected_amount, collection_date, customer_name, payment_method, created_at)
		VALUES (:user_id, :inventory_order_id, :collected_amount, :collection_date, :customer_name, :payment_method, :created_at)
		";
		$statement = $connect->prepare($query);
		$statement->execute(array(
			':user_id'           => $_SESSION["user_id"],
			':inventory_order_id'=> $_POST['order_id'],
			':collected_amount'  => $_POST['amount'],
			':collection_date'   => $_POST['collection_date'],
			':customer_name'     => $_POST['customer_name'],
			':payment_method'    => $_POST['payment_method'],
			':created_at'        => date("Y-m-d H:i:s")
		));
		if ($statement->rowCount() > 0) {
			echo 'Collection Recorded';
		}
	}

	if ($_POST['btn_action'] == 'fetch_single') {
		$query = "
		SELECT * FROM collection WHERE collection_id = :collection_id
		";
		$statement = $connect->prepare($query);
		$statement->execute(array(':collection_id' => $_POST["collection_id"]));
		$result = $statement->fetchAll();
		$output = array();
		foreach ($result as $row) {
			$output['amount']            = $row['collected_amount'];
			$output['collection_date']   = $row['collection_date'];
			$output['customer_name']     = $row['customer_name'];
			$output['payment_method']    = $row['payment_method'];
			$output['order_id']          = $row['inventory_order_id'];
		}
		echo json_encode($output);
	}

	if ($_POST['btn_action'] == 'Edit') {
		$query = "
		UPDATE collection 
		SET collected_amount = :collected_amount,
			collection_date = :collection_date,
			customer_name = :customer_name,
			payment_method = :payment_method,
			inventory_order_id = :inventory_order_id
		WHERE collection_id = :collection_id
		";
		$statement = $connect->prepare($query);
		$statement->execute(array(
			':collected_amount'   => $_POST['amount'],
			':collection_date'    => $_POST['collection_date'],
			':customer_name'      => $_POST['customer_name'],
			':payment_method'     => $_POST['payment_method'],
			':inventory_order_id' => $_POST['order_id'],
			':collection_id'      => $_POST['collection_id']
		));
		if ($statement->rowCount() > 0) {
			echo 'Collection Updated';
		}
	}

	if ($_POST['btn_action'] == 'status') {
		// This section is not applicable because there's no 'collection_status' field in your DB
		echo 'Status toggle not applicable — collection_status column does not exist.';
	}

	if ($_POST['btn_action'] == 'delete') {
		$query = "
		DELETE FROM collection 
		WHERE collection_id = :collection_id
		";
		$statement = $connect->prepare($query);
		$statement->execute(array(':collection_id' => $_POST["collection_id"]));
		if ($statement->rowCount() > 0) {
			echo 'Collection deleted successfully';
		} else {
			echo 'Failed to delete collection';
		}
	}
}
?>
