<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


// for cloud database server 
$host = "mysql1001.site4now.net";
$dbname = "db_abad89_invento";
$username = "abad89_invento";
$password = "@Abc12345";


// // for localhost xampp server 
// $host = "localhost";
// $dbname = "db_abad89_invento";
// $username = "root";
// $password = "";

try {
    // 👇 Include charset=utf8mb4 in DSN
    $connect = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // 👇 Optional but good practice
    $connect->exec("SET NAMES utf8mb4");
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>