<?php
// Legacy-compatible shortcut
include(__DIR__ . '/config/database_connection.php');