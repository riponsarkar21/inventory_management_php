<!-- Logout Confirmation Modal -->
<div id="logoutModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="logoutModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color:#d9534f; color:white;">
        <h4 class="modal-title" id="logoutModalLabel">Confirm Logout</h4>
      </div>
      <div class="modal-body">
        Are you sure you want to logout?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <a href="<?= BASE_URL ?>logout.php" class="btn btn-danger">Logout</a>
      </div>
    </div>
  </div>
</div>


               </div>


	


	</body>
</html>