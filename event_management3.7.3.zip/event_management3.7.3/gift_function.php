<?php
// gift_function.php


// Total Guest
function count_total_guest($connect)
{
	$query = "
	SELECT * FROM gift WHERE status='active'";
	$statement = $connect->prepare($query);
	$statement->execute();
	return $statement->rowCount();
}




function count_total_gift_value($connect)
{
    $query = "
        SELECT SUM(amount) AS total_gift_value
        FROM gift
        WHERE status = 'active' AND created_by = :user_name
    ";

    $statement = $connect->prepare($query);
    $user_name = 'Ripon Sarkar';
    $statement->bindParam(':user_name', $user_name);
    $statement->execute();
    $result = $statement->fetch(PDO::FETCH_ASSOC);

    return ($result && $result['total_gift_value'] !== null)
        ? number_format($result['total_gift_value'], 2)
        : "0.00";
}



// Total Gift Money All Money All User(Only Active)

function count_total_gift_collection_value_active_money_by_all_user($connect)

{
	$query = "

	SELECT SUM(amount) AS total_gift_collection_value_active_money_by_all_user
	FROM gift
	WHERE status = 'active'

	";

	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_gift_collection_value_active_money_by_all_user'], 2);
	}
}




// Total Withdraw All User(Only Active)

function count_total_withdraw_value_active_money_by_all_user($connect)

{
	$query = "

	SELECT SUM(amount) AS total_withdraw_value_active_money_by_all_user
	FROM withdraw
	WHERE status = 'active'

	";

	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_withdraw_value_active_money_by_all_user'], 2);
	}
}


// Total Balence All User(Only Active)

function count_total_balance_active_money_by_all_user($connect)
{
    // Get total gift amount
    $total_gift = floatval(str_replace(',', '', count_total_gift_collection_value_active_money_by_all_user($connect)));

    // Get total withdraw amount
    $total_withdraw = floatval(str_replace(',', '', count_total_withdraw_value_active_money_by_all_user($connect)));

    // Calculate balance
    $balance = $total_gift - $total_withdraw;

    // Return formatted balance
    return number_format($balance, 2);
}


// <!-- --------------------------------- Gift Value and Number of Gift Box By All User ------------------------------------------------ -->

// Total Gift Money All Money (includeing active, inactive, cancelled)

function count_total_gift_collection_value_all_money_by_all_user($connect)

{
	$query = "

	SELECT SUM(amount) AS total_gift_collection_value_all_money_by_all_user
	FROM gift
	";

	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_gift_collection_value_all_money_by_all_user'], 2);
	}
}



// Total Gift Money All Money (inactive)

function count_total_gift_collection_value_inactive_by_all_user($connect)

{
	$query = "

	SELECT SUM(amount) AS total_gift_collection_value_inactive_by_all_user
	FROM gift
	WHERE status = 'inactive'
	";

	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_gift_collection_value_inactive_by_all_user'], 2);
	}
}

// Total Gift Money All Money (cancelled)

function count_total_gift_collection_value_cancelled_by_all_user($connect)

{
	$query = "

	SELECT SUM(amount) AS total_gift_collection_value_cancelled_by_all_user
	FROM gift
	WHERE status = 'cancelled'
	";

	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_gift_collection_value_cancelled_by_all_user'], 2);
	}
}


// Total Number of Gift Box (Active)

function count_total_number_of_giftbox_by_all_user($connect)

{
	$query = "

	SELECT COUNT(amount) AS count_total_number_of_giftbox_by_all_user
	FROM gift
	WHERE status = 'active'
	AND gift_details IS NOT NULL
	AND TRIM(gift_details) <> ''
	";

	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['count_total_number_of_giftbox_by_all_user'], 0);
	}
}

// <!-- --------------------------------- Gift Value and Number of Gift Box By You/ User ------------------------------------------------ -->

// Total Gift Money All Money (includeing active, inactive, cancelled)

function count_total_gift_collection_value_all_money($connect)

{
	$query = "

	SELECT SUM(amount) AS total_gift_collection_value_all_money
	FROM gift
	";
    // Filter by session user_id if available
    if (isset($_SESSION['user_id'])) {
        $query .= " WHERE user_id = :user_id";
    }

    $statement = $connect->prepare($query);

    if (isset($_SESSION['user_id'])) {
        $statement->execute([
            ':user_id' => $_SESSION['user_id']
        ]);
    } else {
        $statement->execute();
    }

	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_gift_collection_value_all_money'], 2);
	}
}

// Total Gift Money All Money (inactive)

function count_total_gift_collection_value_inactive($connect)

{
	$query = "

	SELECT SUM(amount) AS total_gift_collection_value_inactive
	FROM gift
	WHERE status = 'inactive'
	";

    // Filter by session user_id if available
    if (isset($_SESSION['user_id'])) {
        $query .= " AND user_id = :user_id";
    }

    $statement = $connect->prepare($query);

    if (isset($_SESSION['user_id'])) {
        $statement->execute([
            ':user_id' => $_SESSION['user_id']
        ]);
    } else {
        $statement->execute();
    }

	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_gift_collection_value_inactive'], 2);
	}
}

// Total Gift Money All Money (cancelled)

function count_total_gift_collection_value_cancelled($connect)

{
	$query = "

	SELECT SUM(amount) AS total_gift_collection_value_cancelled
	FROM gift
	WHERE status = 'cancelled'
	";

    // Filter by session user_id if available
    if (isset($_SESSION['user_id'])) {
        $query .= " AND user_id = :user_id";
    }

    $statement = $connect->prepare($query);

    if (isset($_SESSION['user_id'])) {
        $statement->execute([
            ':user_id' => $_SESSION['user_id']
        ]);
    } else {
        $statement->execute();
    }

	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_gift_collection_value_cancelled'], 2);
	}
}


// Total Number of Gift Box (Active)

function count_total_number_of_giftbox($connect)

{
	$query = "

	SELECT COUNT(amount) AS count_total_number_of_giftbox
	FROM gift
	WHERE status = 'active'
	AND gift_details IS NOT NULL
	AND TRIM(gift_details) <> ''
	";

    // Filter by session user_id if available
    if (isset($_SESSION['user_id'])) {
        $query .= " AND user_id = :user_id";
    }

    $statement = $connect->prepare($query);

    if (isset($_SESSION['user_id'])) {
        $statement->execute([
            ':user_id' => $_SESSION['user_id']
        ]);
    } else {
        $statement->execute();
    }

	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['count_total_number_of_giftbox'], 0);
	}
}

// <!-- --------------------------------- Gift Money By All User------------------------------------------------ -->

// Total Gift Collection Value
function count_total_gift_collection_value_by_all_user($connect)

{
	$query = "
	SELECT sum(amount) as total_gift_collection_value_by_all_user
	FROM gift
	";
	// $query = "
	// SELECT sum(collected_amount) as total_collection_value FROM collection 
	// WHERE inventory_order_status='active'
	// ";
	// if($_SESSION['type'] == 'user')
	// {
	// 	$query .= ' AND user_id = "'.$_SESSION["user_id"].'"';
	// }
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_gift_collection_value_by_all_user'], 2);
	}
}




// Total Gift (Bank) Collection Value
function count_total_gift_cash_collection_value_by_all_user($connect)
{
	$query = "
	SELECT sum(amount) as total_gift_cash_collection_value_by_all_user FROM gift 
	WHERE payment_method = 'cash' 
	";
	// if($_SESSION['type'] == 'user')
	// {
	// 	$query .= ' AND user_id = "'.$_SESSION["user_id"].'"';
	// }
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_gift_cash_collection_value_by_all_user'], 2);
	}
}


// Total Credit Order Value
function count_total_gift_bank_collection_value_by_all_user($connect)
{
	$query = "
	SELECT sum(amount) as total_gift_bank_collection_value_by_all_user FROM gift WHERE payment_method = 'bank'
	";
	// if($_SESSION['type'] == 'user')
	// {
	// 	$query .= ' AND user_id = "'.$_SESSION["user_id"].'"';
	// }
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_gift_bank_collection_value_by_all_user'], 2);
	}
}

// Total Gfit (Bkash) Collection Value
function count_total_gift_bkash_collection_value_by_all_user($connect)
{
	$query = "
	SELECT sum(amount) as total_gift_bkash_collection_value_by_all_user FROM gift WHERE payment_method = 'bkash'
	";
	// if($_SESSION['type'] == 'user')
	// {
	// 	$query .= ' AND user_id = "'.$_SESSION["user_id"].'"';
	// }
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_gift_bkash_collection_value_by_all_user'], 2);
	}
}// Total Gfit (Nagad) Collection Value
function count_total_gift_nagad_collection_value_by_all_user($connect)
{
	$query = "
	SELECT sum(amount) as total_gift_nagad_collection_value_by_all_user FROM gift WHERE payment_method = 'nagad'
	";
	// if($_SESSION['type'] == 'user')
	// {
	// 	$query .= ' AND user_id = "'.$_SESSION["user_id"].'"';
	// }
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_gift_nagad_collection_value_by_all_user'], 2);
	}
}
// Total Gift (Others) Collection Value
function count_total_gift_others_collection_value_by_all_user($connect)
{
	$query = "
	SELECT sum(amount) as count_total_gift_others_collection_value_by_all_user FROM gift WHERE payment_method = 'others'
	";
	// if($_SESSION['type'] == 'user')
	// {
	// 	$query .= ' AND user_id = "'.$_SESSION["user_id"].'"';
	// }
	$statement = $connect->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['count_total_gift_others_collection_value_by_all_user'], 2);
	}
}








// // ----------------------------------  Gift Money By You / by User  -----------------------------------------------

// Total Gift Collection Value

function count_total_gift_collection_value_by_user($connect)
{
    $query = "
        SELECT SUM(amount) AS total_gift_collection_value_by_user
        FROM gift
        WHERE status = 'active'
    ";

    // Filter by session user_id if available
    if (isset($_SESSION['user_id'])) {
        $query .= " AND user_id = :user_id";
    }

    $statement = $connect->prepare($query);

    if (isset($_SESSION['user_id'])) {
        $statement->execute([
            ':user_id' => $_SESSION['user_id']
        ]);
    } else {
        $statement->execute();
    }

    $result = $statement->fetchAll();

    foreach ($result as $row) {
        return number_format($row['total_gift_collection_value_by_user'], 2);
    }
}




// Total Gift (Bank) Collection Value
function count_total_gift_cash_collection_value_by_user($connect)
{
	$query = "
	SELECT sum(amount) as total_gift_cash_collection_value_by_user FROM gift 
	WHERE payment_method = 'cash' 
	AND status = 'active'
	";
    // Filter by session user_id if available
    if (isset($_SESSION['user_id'])) {
        $query .= " AND user_id = :user_id";
    }

    $statement = $connect->prepare($query);

    if (isset($_SESSION['user_id'])) {
        $statement->execute([
            ':user_id' => $_SESSION['user_id']
        ]);
    } else {
        $statement->execute();
    }

	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_gift_cash_collection_value_by_user'], 2);
	}
}


// Total Credit Order Value
function count_total_gift_bank_collection_value_by_user($connect)
{
	$query = "
	SELECT sum(amount) as total_gift_bank_collection_value_by_user 
	FROM gift 
	WHERE payment_method = 'bank'
	AND status = 'active'

	";
    // Filter by session user_id if available
    if (isset($_SESSION['user_id'])) {
        $query .= " AND user_id = :user_id";
    }

    $statement = $connect->prepare($query);

    if (isset($_SESSION['user_id'])) {
        $statement->execute([
            ':user_id' => $_SESSION['user_id']
        ]);
    } else {
        $statement->execute();
    }

	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_gift_bank_collection_value_by_user'], 2);
	}
}

// Total Gfit (Bkash) Collection Value
function count_total_gift_bkash_collection_value_by_user($connect)
{
	$query = "
	SELECT sum(amount) as total_gift_bkash_collection_value_by_user 
	FROM gift 
	WHERE payment_method = 'bkash'
	AND status = 'active'

	";
    // Filter by session user_id if available
    if (isset($_SESSION['user_id'])) {
        $query .= " AND user_id = :user_id";
    }

    $statement = $connect->prepare($query);

    if (isset($_SESSION['user_id'])) {
        $statement->execute([
            ':user_id' => $_SESSION['user_id']
        ]);
    } else {
        $statement->execute();
    }

	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_gift_bkash_collection_value_by_user'], 2);
	}
}

// Total Gfit (Nagad) Collection Value
function count_total_gift_nagad_collection_value_by_user($connect)
{
	$query = "
	SELECT sum(amount) as total_gift_nagad_collection_value_by_user 
	FROM gift 
	WHERE payment_method = 'nagad'
	AND status = 'active'

	";
    // Filter by session user_id if available
    if (isset($_SESSION['user_id'])) {
        $query .= " AND user_id = :user_id";
    }

    $statement = $connect->prepare($query);

    if (isset($_SESSION['user_id'])) {
        $statement->execute([
            ':user_id' => $_SESSION['user_id']
        ]);
    } else {
        $statement->execute();
    }

	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['total_gift_nagad_collection_value_by_user'], 2);
	}
}
// Total Gift (Others) Collection Value
function count_total_gift_others_collection_value_by_user($connect)
{
	$query = "
	SELECT sum(amount) as count_total_gift_others_collection_value_by_user 
	FROM gift 
	WHERE payment_method = 'others'
	AND status = 'active'

	";
    // Filter by session user_id if available
    if (isset($_SESSION['user_id'])) {
        $query .= " AND user_id = :user_id";
    }

    $statement = $connect->prepare($query);

    if (isset($_SESSION['user_id'])) {
        $statement->execute([
            ':user_id' => $_SESSION['user_id']
        ]);
    } else {
        $statement->execute();
    }

	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		return number_format($row['count_total_gift_others_collection_value_by_user'], 2);
	}
}








// // ---------------------------------- Total Order Value User wise ----------------------------------


// // Total Order Value User wise
// function get_user_wise_total_order($connect)
// {
// 	$query = '
// 	SELECT 
// 		inventory_order.user_id,
// 		SUM(inventory_order.inventory_order_total) AS order_total, 
// 		SUM(CASE WHEN inventory_order.payment_status = "cash" THEN inventory_order.inventory_order_total ELSE 0 END) AS cash_order_total, 
// 		SUM(CASE WHEN inventory_order.payment_status = "credit" THEN inventory_order.inventory_order_total ELSE 0 END) AS credit_order_total, 
// 		user_details.user_name 
// 	FROM inventory_order 
// 	INNER JOIN user_details ON user_details.user_id = inventory_order.user_id 
// 	WHERE inventory_order.inventory_order_status = "active" 
// 	GROUP BY inventory_order.user_id
// 	';

// 	$statement = $connect->prepare($query);
// 	$statement->execute();
// 	$result = $statement->fetchAll();

// 	$output = '
// 	<div class="table-responsive">
// 		<table class="table table-bordered table-striped user-summary-table">

// 			<tr>
// 				<th>User Name</th>
// 				<th>Total Order Value</th>
// 				<th>Total Cash Order</th>
// 				<th>Total Credit Order</th>
// 			</tr>
// 	';

// 	$total_order = 0;
// 	$total_cash_order = 0;
// 	$total_credit_order = 0;

// 	foreach($result as $row)
// 	{
// 		$output .= '
// 		<tr>
// 			<td>
// 				<a href="user_orders.php?user_id='.$row['user_id'].'">
// 					'.$row['user_name'].'
// 				</a>
// 			</td>
// 			<td align="right">$ '.number_format($row["order_total"], 2).'</td>
// 			<td align="right">$ '.number_format($row["cash_order_total"], 2).'</td>
// 			<td align="right">$ '.number_format($row["credit_order_total"], 2).'</td>
// 		</tr>
// 		';

// 		$total_order += $row["order_total"];
// 		$total_cash_order += $row["cash_order_total"];
// 		$total_credit_order += $row["credit_order_total"];
// 	}

// 	$output .= '
// 	<tr>
// 		<td align="right"><b>Total</b></td>
// 		<td align="right"><b>$ '.number_format($total_order, 2).'</b></td>
// 		<td align="right"><b>$ '.number_format($total_cash_order, 2).'</b></td>
// 		<td align="right"><b>$ '.number_format($total_credit_order, 2).'</b></td>
// 	</tr>
// 	</table></div>
// 	';

// 	return $output;
// }

// // Collection


// // function insert_collection($connect, $inventory_order_id, $user_id, $collection_date, $collected_amount, $payment_method = '', $remarks = '') {
// //     $query = "
// //         INSERT INTO collection 
// //         (inventory_order_id, user_id, collection_date, collected_amount, payment_method, remarks) 
// //         VALUES 
// //         (:inventory_order_id, :user_id, :collection_date, :collected_amount, :payment_method, :remarks)
// //     ";

// //     $statement = $connect->prepare($query);
// //     $statement->bindParam(':inventory_order_id', $inventory_order_id);
// //     $statement->bindParam(':user_id', $user_id);
// //     $statement->bindParam(':collection_date', $collection_date);
// //     $statement->bindParam(':collected_amount', $collected_amount);
// //     $statement->bindParam(':payment_method', $payment_method);
// //     $statement->bindParam(':remarks', $remarks);

// //     if ($statement->execute()) {
// //         return true;
// //     } else {
// //         return false;
// //     }
// // }


// // -----------------------


// // Total collection Value User wise
// function get_user_wise_total_collection($connect)
// {
// 	$query = '
// 	SELECT 
// 		collection.user_id,
// 		SUM(collection.collected_amount) AS collection_total, 
// 		SUM(CASE WHEN collection.payment_method = "cash" THEN collection.collected_amount ELSE 0 END) AS cash_collection_total, 
// 		SUM(CASE WHEN collection.payment_method = "bank" THEN collection.collected_amount ELSE 0 END) AS bank_collection_total, 
// 		SUM(CASE WHEN collection.payment_method = "mobile" THEN collection.collected_amount ELSE 0 END) AS mobile_collection_total, 
// 		SUM(CASE WHEN collection.payment_method = "others" THEN collection.collected_amount ELSE 0 END) AS others_collection_total, 
// 		user_details.user_name 
// 	FROM collection 
// 	INNER JOIN user_details ON user_details.user_id = collection.user_id 
// 	GROUP BY collection.user_id
// 	';

// 	$statement = $connect->prepare($query);
// 	$statement->execute();
// 	$result = $statement->fetchAll();

// 	$output = '
// 	<div class="table-responsive">
// 		<table class="table table-bordered table-striped user-summary-table">

// 			<tr>
// 				<th>User Name</th>
// 				<th>Total Collection</th>
// 				<th>Total Cash Collection</th>
// 				<th>Total Bank Collection</th>
// 				<th>Total Mobile Collection</th>
// 				<th>Total Others Collection</th>
// 			</tr>
// 	';

// 	$total_collection = 0;
// 	$total_cash_collection = 0;
// 	$total_bank_collection = 0;
// 	$total_mobile_collection = 0;
// 	$total_others_collection = 0;

// 	foreach($result as $row)
// 	{
// 		$output .= '
// 		<tr>
// 			<td>
// 				<a href="user_collections.php?user_id=' . $row['user_id'] . '">
// 					' . htmlspecialchars($row['user_name']) . '
// 				</a>
// 			</td>
// 			<td align="right">$ ' . number_format($row["collection_total"], 2) . '</td>
// 			<td align="right">$ ' . number_format($row["cash_collection_total"], 2) . '</td>
// 			<td align="right">$ ' . number_format($row["bank_collection_total"], 2) . '</td>
// 			<td align="right">$ ' . number_format($row["mobile_collection_total"], 2) . '</td>
// 			<td align="right">$ ' . number_format($row["others_collection_total"], 2) . '</td>
// 		</tr>
// 		';

// 		$total_collection += $row["collection_total"];
// 		$total_cash_collection += $row["cash_collection_total"];
// 		$total_bank_collection += $row["bank_collection_total"];
// 		$total_mobile_collection += $row["mobile_collection_total"];
// 		$total_others_collection += $row["others_collection_total"];

// 	}

// 	$output .= '
// 	<tr>
// 		<td align="right"><b>Total</b></td>
// 		<td align="right"><b>$ ' . number_format($total_collection, 2) . '</b></td>
// 		<td align="right"><b>$ ' . number_format($total_cash_collection, 2) . '</b></td>
// 		<td align="right"><b>$ ' . number_format($total_bank_collection, 2) . '</b></td>
// 		<td align="right"><b>$ ' . number_format($total_mobile_collection, 2) . '</b></td>
// 		<td align="right"><b>$ ' . number_format($total_others_collection, 2) . '</b></td>
// 	</tr>
// 	</table></div>
// 	';

// 	return $output;
// }


// // Customized Report

// function get_user_wise_order_by_date($connect, $user_id, $start_date, $end_date) {
//     // Prepare and fetch order data for the user between start and end date
//     $query = "
//         SELECT order_id, order_date, order_status, order_total_price 
//         FROM orders 
//         WHERE user_id = :user_id 
//           AND order_date BETWEEN :start_date AND :end_date
//         ORDER BY order_date ASC
//     ";
//     $stmt = $connect->prepare($query);
//     $stmt->execute([
//         ':user_id' => $user_id,
//         ':start_date' => $start_date,
//         ':end_date' => $end_date
//     ]);
//     $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

//     if(!$orders) {
//         return "<div class='alert alert-info'>No orders found for selected criteria.</div>";
//     }

//     $output = "<table class='table table-bordered'>";
//     $output .= "<thead><tr><th>Order ID</th><th>Date</th><th>Status</th><th>Total Price</th></tr></thead><tbody>";

//     foreach($orders as $order) {
//         $output .= "<tr>
//             <td>".htmlspecialchars($order['order_id'])."</td>
//             <td>".htmlspecialchars($order['order_date'])."</td>
//             <td>".htmlspecialchars($order['order_status'])."</td>
//             <td>$ ".number_format($order['order_total_price'], 2)."</td>
//         </tr>";
//     }

//     $output .= "</tbody></table>";
//     return $output;
// }

// function get_user_wise_collection_by_date($connect, $user_id, $start_date, $end_date) {
//     // Prepare and fetch collection data for the user between start and end date
//     $query = "
//         SELECT collection_id, collection_date, collected_amount 
//         FROM collection 
//         WHERE user_id = :user_id 
//           AND collection_date BETWEEN :start_date AND :end_date
//         ORDER BY collection_date ASC
//     ";
//     $stmt = $connect->prepare($query);
//     $stmt->execute([
//         ':user_id' => $user_id,
//         ':start_date' => $start_date,
//         ':end_date' => $end_date
//     ]);
//     $collections = $stmt->fetchAll(PDO::FETCH_ASSOC);

//     if(!$collections) {
//         return "<div class='alert alert-info'>No collections found for selected criteria.</div>";
//     }

//     $output = "<table class='table table-bordered'>";
//     $output .= "<thead><tr><th>Collection ID</th><th>Date</th><th>Amount</th></tr></thead><tbody>";

//     foreach($collections as $collection) {
//         $output .= "<tr>
//             <td>".htmlspecialchars($collection['collection_id'])."</td>
//             <td>".htmlspecialchars($collection['collection_date'])."</td>
//             <td>$ ".number_format($collection['collected_amount'], 2)."</td>
//         </tr>";
//     }

//     $output .= "</tbody></table>";
//     return $output;
// }




?>