<?php
// init/init_gift_sql.php
include(__DIR__ . '/../database_connection.php');

try {
    $sql = "
    CREATE TABLE IF NOT EXISTS gift (
        gift_id INT AUTO_INCREMENT PRIMARY KEY,
        guest_name VARCHAR(100) NOT NULL,
        phone VARCHAR(20),
        address TEXT,
        relation VARCHAR(100),
        gift_type ENUM('money', 'gift', 'both') NOT NULL,
        amount DECIMAL(10,2),
        payment_method VARCHAR(50),
        gift_details VARCHAR(255),
        gift_image VARCHAR(255),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        created_by VARCHAR(100),
        status VARCHAR(50) DEFAULT 'Pending'
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ";

    $connect->exec($sql);
    echo "<h3>✅ 'gift' table created or already exists.</h3>";
} catch (PDOException $e) {
    echo "<h3>❌ Error creating table: " . $e->getMessage() . "</h3>";
}
?>
