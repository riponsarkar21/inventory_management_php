<?php
// init/init_version_sql.php

include(__DIR__ . '/../database_connection.php');

try {
    $query = "
        CREATE TABLE IF NOT EXISTS version (
            version_id INT AUTO_INCREMENT PRIMARY KEY,
            version_number VARCHAR(20) NOT NULL,
            release_date DATE NOT NULL,
            features TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
            changelog TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
            file_path VARCHAR(255),
            created_by VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ";

    $connect->exec($query);
    echo "Version table created successfully with utf8mb4 charset.";

} catch (PDOException $e) {
    echo "Error creating version table: " . $e->getMessage();
}
?>