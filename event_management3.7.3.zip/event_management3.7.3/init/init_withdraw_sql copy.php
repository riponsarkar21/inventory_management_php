<?php
// init/init_withdraw_sql.php

include(__DIR__ . '/../database_connection.php');


try {
    // Connect to the database
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Create the withdraw table
    $sql = "
    CREATE TABLE IF NOT EXISTS withdraw (
        withdraw_id INT AUTO_INCREMENT PRIMARY KEY,

        -- Withdrawer info
        withdrawer_id INT NOT NULL,
        withdrawer_name VARCHAR(100) NOT NULL,
        relation VARCHAR(50),
        withdrawer_address TEXT,
        withdrawer_phone VARCHAR(20),

        -- Paid by user
        user_id INT NOT NULL,

        -- Financial info
        amount DECIMAL(10,2) NOT NULL,
        fees DECIMAL(10,2) DEFAULT 0.00,
        net_amount DECIMAL(10,2) GENERATED ALWAYS AS (amount - fees) STORED,

        method VARCHAR(50) NOT NULL,
        account_details TEXT,
        currency VARCHAR(10) DEFAULT 'BDT',
        reference_no VARCHAR(100),

        -- Cash note breakdown (optional)
        note_1000 INT DEFAULT NULL,
        note_500 INT DEFAULT NULL,
        note_200 INT DEFAULT NULL,
        note_100 INT DEFAULT NULL,
        note_60 INT DEFAULT NULL,
        note_50 INT DEFAULT NULL,
        note_40 INT DEFAULT NULL,
        note_20 INT DEFAULT NULL,
        note_10 INT DEFAULT NULL,
        note_5 INT DEFAULT NULL,
        note_2 INT DEFAULT NULL,
        note_1 INT DEFAULT NULL,

        -- Coin breakdown (optional)
        coin_5 INT DEFAULT NULL,
        coin_2 INT DEFAULT NULL,
        coin_1 INT DEFAULT NULL,

        -- Transaction metadata
        status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
        remarks TEXT,
        proof_image VARCHAR(255),
        payment_gateway_id VARCHAR(100),
        is_recurring TINYINT(1) DEFAULT 0,

        requested_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        processed_at DATETIME DEFAULT NULL,

        -- Admin tracking
        created_by INT DEFAULT NULL,
        updated_by INT DEFAULT NULL,
        approved_by INT DEFAULT NULL,

        -- Security/audit
        deleted_at DATETIME DEFAULT NULL,
        ip_address VARCHAR(45),
        device_info TEXT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ";

    $pdo->exec($sql);
    echo "✅ 'withdraw' table created successfully.";

} catch (PDOException $e) {
    echo "❌ Database error: " . $e->getMessage();
}
?>
