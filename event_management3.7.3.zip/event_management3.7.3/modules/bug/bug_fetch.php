<?php
// modules/bug/bug_fetch.php

include('../../database_connection.php');

$stmt = $connect->prepare("SELECT * FROM bug ORDER BY bug_id DESC");
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($rows as &$row) {
    // If the image exists and isn't already a full URL
    if (!empty($row['screenshot_image']) && strpos($row['screenshot_image'], '/uploads/') !== 0) {
        $row['screenshot_image'] = '/uploads/bug/' . basename($row['screenshot_image']);
    }
}

echo json_encode(['data' => $rows]);
?>
