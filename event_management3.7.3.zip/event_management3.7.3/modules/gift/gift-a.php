<?php
include('../../database_connection.php');

$stmt = $connect->query("SELECT SUM(amount) FROM gift");
$total_cash = $stmt->fetchColumn();

var_dump($total_cash); // Check output here
exit;




