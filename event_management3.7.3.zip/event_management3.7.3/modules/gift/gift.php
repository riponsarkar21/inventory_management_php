<?php
// gift.php
include('../../database_connection.php');
include('../../header.php');
?>

<!-- DataTables CSS & Buttons -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
<link rel="stylesheet" href="../../css/datepicker.css">



<style>
    .btn-wrapper {
        display: flex;
        justify-content: center;
    }

    @media (max-width: 768px) {
        .btn-wrapper {
            flex-direction: column;
            align-items: center;
        }

        .btn-wrapper button {
            margin-bottom: 5px;
            width: 90px;
        }
    }
</style>

<span id="alert_action"></span>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading clearfix">
                <div class="pull-left">
                    <h3 class="panel-title">Gift / Cash Received List</h3>
                </div>
                <div class="pull-right">
                    <button type="button" id="add_button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#giftModal">Add Entry</button>
                </div>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table id="gift_data" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Guest Name</th>
                                <th>Phone</th>
                                <th>Type</th>
                                <th>Amount</th>
                                <th>Gift</th>
                                <th>Image</th>
                                <th>Status</th>
                                <th>Update</th>
                                <th>PDF</th>
                                <th>Change Status</th>
                                <th>Cancel</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="giftModal" class="modal fade">
    <div class="modal-dialog modal-lg">
        <form method="post" id="gift_form" enctype="multipart/form-data">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add Gift / Cash Entry</h4>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="gift_id" id="gift_id">
                    <div class="form-group"><label>Guest Name</label><input type="text" name="guest_name" id="guest_name" class="form-control" required></div>
                    <div class="form-group"><label>Phone</label><input type="text" name="phone" id="phone" class="form-control"></div>
                    <div class="form-group"><label>Address</label><textarea name="address" id="address" class="form-control"></textarea></div>
                    <div class="form-group"><label>Relation</label><input type="text" name="relation" id="relation" class="form-control"></div>
                    <div class="form-group">
                        <label>Type</label>
                        <select name="gift_type" id="gift_type" class="form-control" required>
                            <option value="money">Money</option>
                            <option value="gift">Gift</option>
                            <option value="both">Both</option>
                        </select>
                    </div>

                    <div id="money_section" class="conditional-section">
                        <div class="form-group"><label>Amount</label><input type="number" step="0.01" name="amount" id="amount" class="form-control"></div>
                        <div class="form-group">
                            <label>Payment Method</label>
                            <select name="payment_method" id="payment_method" class="form-control">
                                <option value="Cash">Cash</option>
                                <option value="Bank">Bank</option>
                                <option value="Bkash">Bkash</option>
                                <option value="Nagad">Nagad</option>
                                <option value="Others">Others</option>
                            </select>
                        </div>
                    </div>

                    <div id="gift_section" class="conditional-section">
                        <div class="form-group"><label>Gift Details</label><input type="text" name="gift_details" id="gift_details" class="form-control" placeholder="Gift item, model, size etc."></div>
                        <div class="form-group"><label>Gift Image</label><input type="file" name="gift_image" class="form-control"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="submit" name="action" id="action" class="btn btn-info" value="Add" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- DataTables & Buttons Scripts -->
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap.min.js"></script>

<script>
$(document).ready(function(){
    const table = $('#gift_data').DataTable({
        "ajax": "gift_fetch.php",
        "scrollX": true,
        "order": [[0, "desc"]],
        "columns": [
            { "data": "gift_id" },
            { "data": "guest_name" },
            { "data": "phone" },
            { "data": "gift_type" },
            { "data": "amount" },
            { "data": "gift_details" },
            {
                "data": "gift_image",
                "render": function(data) {
                    return data ? `<img src="<?= BASE_URL ?>${data}" height="50">` : '';
                }
            },
            {
                "data": "status",
                "orderable": true,
                "className": "text-center",
                "render": function(data, type, row) {
                    let colorClass = '';
                    switch (data.toLowerCase()) {
                        case 'active':
                            colorClass = 'label label-success'; // green
                            break;
                        case 'inactive':
                            colorClass = 'label label-warning'; // brown/yellow
                            break;
                        case 'cancel':
                        case 'cancelled':
                            colorClass = 'label label-danger'; // red
                            break;
                        default:
                            colorClass = 'label label-default'; // gray
                    }
                    return `<span class="${colorClass}">${data}</span>`;
                }
            },

            {
                "data": null,
                "orderable": false,
                "className": "text-center",
                "render": function(row) {
                    return `<div class="btn-wrapper"><button class="btn btn-primary btn-xs update-entry" title="Edit Entry" data-id="${row.gift_id}">Update</button></div>`;
                }
            },
            {
                "data": null,
                "orderable": false,
                "className": "text-center",
                "render": function(row) {
                    return `<div class="btn-wrapper"><button class="btn btn-default btn-xs generate-pdf" title="Generate PDF" data-id="${row.gift_id}">PDF</button></div>`;
                }
            },
            {
                "data": null,
                "orderable": false,
                "className": "text-center",
                "render": function(row) {
                    return `<div class="btn-wrapper"><button class="btn btn-info btn-xs change-status" title="Change Status" data-id="${row.gift_id}">Change Status</button></div>`;
                }
            },

            {
                "data": null,
                "orderable": false,
                "className": "text-center",
                "render": function(row) {
                    return `<div class="btn-wrapper"><button class="btn btn-warning btn-xs cancel-entry" title="Cancel Entry" data-id="${row.gift_id}">Cancel</button></div>`;
                }
            },
            {
                "data": null,
                "orderable": false,
                "className": "text-center",
                "render": function(row) {
                    return `<div class="btn-wrapper"><button class="btn btn-danger btn-xs delete" title="Delete Entry" data-id="${row.gift_id}">Delete</button></div>`;
                }
            }
        ],
        "lengthMenu": [[5, 10, 25, 50], [5, 10, 25, 50]],
        "pageLength": 10,
        "dom":
            "<'row'<'col-sm-6'l><'col-sm-6'f>>" +
            "<'row'<'col-sm-12'tr>>" +
            "<'row'<'col-sm-5'i><'col-sm-7'p>>" +
            "<'row'<'col-sm-12 text-center mt-3'B>>",
        "buttons": ['copy', 'csv', 'excel', 'pdf', 'print']
    });

    function toggleSections() {
        const type = $('#gift_type').val();
        $('.conditional-section').hide();
        if (type === 'money') $('#money_section').show();
        else if (type === 'gift') $('#gift_section').show();
        else { $('#money_section, #gift_section').show(); }
    }

    $('#gift_type').change(toggleSections);
    toggleSections();

    $('#gift_form').on('submit', function(e){
        e.preventDefault();
        const formData = new FormData(this);
        $.ajax({
            url: "gift_action.php",
            method: "POST",
            data: formData,
            contentType: false,
            processData: false,
            success: function(data){
                $('#gift_form')[0].reset();
                $('#giftModal').modal('hide');
                $('#alert_action').html('<div class="alert alert-success">'+data+'</div>');
                table.ajax.reload();
                $('#action').val('Add');
                $('#gift_id').val('');
            }
        });
    });

    $(document).on('click', '.delete', function(){
        if(confirm("Are you sure you want to delete this entry?")) {
            const id = $(this).data('id');
            $.post("gift_action.php", { action: "delete", id: id }, function(data){
                $('#alert_action').html('<div class="alert alert-danger">'+data+'</div>');
                table.ajax.reload();
            });
        }
    });

    $(document).on('click', '.change-status', function(){
        const id = $(this).data('id');
        $.post("gift_action.php", { action: "change_status", id: id }, function(data){
            $('#alert_action').html('<div class="alert alert-info">'+data+'</div>');
            table.ajax.reload();
        });
    });

    $(document).on('click', '.cancel-entry', function(){
        const id = $(this).data('id');
        if (confirm("Are you sure you want to cancel this entry? This action will mark it as 'Cancelled'.")) {
            $.post("gift_action.php", { action: "cancel", id: id }, function(data){
                $('#alert_action').html('<div class="alert alert-warning">'+data+'</div>');
                table.ajax.reload();
            });
        }
    });

    $(document).on('click', '.generate-pdf', function(){
        const id = $(this).data('id');
        // window.open("/../gift_pdf.php?id=" + id, '_blank');
        window.open("../gift/gift_ticket_pdf.php?id=" + id, '_blank');
    });

    $(document).on('click', '.update-entry', function(){
        const id = $(this).data('id');
        $.post("gift_action.php", { action: "fetch_single", id: id }, function(data){
            const d = JSON.parse(data);
            $('#gift_id').val(d.gift_id);
            $('#guest_name').val(d.guest_name);
            $('#phone').val(d.phone);
            $('#address').val(d.address);
            $('#relation').val(d.relation);
            $('#gift_type').val(d.gift_type).change();
            $('#amount').val(d.amount);
            $('#payment_method').val(d.payment_method);
            $('#gift_details').val(d.gift_details);
            $('#action').val('Update');
            $('#giftModal').modal('show');
        });
    });
});
</script>

<?php include('../../footer.php'); ?>
