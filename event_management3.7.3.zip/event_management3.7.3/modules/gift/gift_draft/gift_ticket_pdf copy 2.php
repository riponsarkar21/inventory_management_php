<?php
require 'vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

// Generate QR code (temporary)
$qrText = 'Gift ID: 786001 | Name: Abdullah Saad';
$qrImagePath = 'temp_qr.png';
file_put_contents($qrImagePath, file_get_contents('https://api.qrserver.com/v1/create-qr-code/?data=' . urlencode($qrText) . '&size=100x100'));

// Dompdf setup
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true);
$options->set('defaultFont', 'DejaVu Sans');

$dompdf = new Dompdf($options);

// POS paper size: 57mm × 130mm = ~216 x 472 points
$customPaper = array(0, 0, 216, 472);

$html = '
<style>
    body {
        font-family: DejaVu Sans, sans-serif;
        font-size: 9px;
        margin: 5px;
    }
    .wrapper {
        width: 100%;
        border: 1px dashed #000;
        padding: 5px;
        box-sizing: border-box;
    }
    .header {
        text-align: center;
        font-weight: bold;
        margin-bottom: 5px;
        font-size: 10px;
    }
    .section {
        margin-bottom: 3px;
    }
    .label {
        font-weight: bold;
    }
    .qr-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 5px;
    }
    .qr-container img {
        width: 80px;
        height: 80px;
    }
    .signature {
        text-align: right;
        margin-top: 15px;
        font-size: 9px;
    }
    .footer {
        text-align: center;
        font-size: 8px;
        margin-top: 20px;
    }
    .tear-space {
        height: 38px;
    }
</style>

<div class="wrapper">
    <div class="header">
        HASAN GIFT CEREMONY<br>
        Bagerhat Sadar, Bagerhat
    </div>

    <div class="section">
        <span class="label">Date:</span> 17/05/2025<br>
        <span class="label">Time:</span> 01:30 PM<br>
        <span class="label">Gift ID:</span> 786001
    </div>

    <div class="section">
        <span class="label">Name:</span> Abdullah Saad<br>
        <span class="label">Address:</span> Bagerhat<br>
        <span class="label">Relation:</span> Uncle
    </div>

    <div class="section">
        <span class="label">Amount:</span> 1000 Taka<br>
        <span class="label">In Words:</span> One Thousand Taka Only
    </div>

    <div class="qr-container">
        <div>
            <span style="font-size: 8px;">Gift Verification</span>
        </div>
        <div>
            <img src="' . $qrImagePath . '" alt="QR Code">
        </div>
    </div>

    <div class="signature">
        _______________________<br>
        Receiver Signature
    </div>

    <div class="footer">
        Thank you for your kind gift.<br>
        Printed by: Digital Service, 01911-676706
    </div>

    <div class="tear-space"></div>
</div>
';

$dompdf->setPaper($customPaper);
$dompdf->loadHtml($html);
$dompdf->render();
$dompdf->stream("gift_ticket_pos.pdf", ["Attachment" => false]);
exit;
