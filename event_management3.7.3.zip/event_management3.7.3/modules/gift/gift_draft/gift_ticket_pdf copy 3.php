<?php
require 'dompdf/vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

// QR code
$qrText = 'Gift ID: 786001 | Name: Abdullah Saad';
$qrImagePath = 'temp_qr.png';
file_put_contents($qrImagePath, file_get_contents('https://api.qrserver.com/v1/create-qr-code/?data=' . urlencode($qrText) . '&size=100x100'));

$options = new Options();
$options->set('isRemoteEnabled', true);
$options->set('defaultFont', 'DejaVu Sans');
$dompdf = new Dompdf($options);

// Paper size: 57mm × 130mm ≈ 216 x 472 pt
$customPaper = array(0, 0, 216, 360);

// HTML Template
$html = '
<style>
    body {
        font-family: DejaVu Sans, sans-serif;
        font-size: 10px;
        margin-left: -30px;
        margin-right: -15px;
        margin-top: -30px;
        margin-bottom: -50px;
        padding: 0;
    }
    .wrapper {
        width: 100%;
        padding: 6px;
        box-sizing: border-box;
        border: 1px dashed #000;
    }
    .header {
        text-align: center;
        font-weight: bold;
        font-size: 11px;
        margin-bottom: 4px;
    }
    .qr {
        text-align: center;
        margin: 4px 0;
        width: 110px;
        height: 110px;
        background-color: yellow;


    }
    .qr img {
        width: 100px;
        height: 100px;
        text-align: center;


    }
    .qr small {
        font-size: 8px;
    }
    .section {
        margin: 3px 0;
        line-height: 1.4em;
    }
    .section-amount {
        margin: 3px 0;
        line-height: 1.4em;
        height: 60px;
        // color: red;
        // background-color: yellow;
    }
    .label {
        font-weight: regular;
    }
    .data {
        font-weight: Bold;
    }
    .signature {
        text-align: right;
        margin-top: 15px;
    }
    .footer {
        text-align: center;
        font-size: 8.5px;
        margin-top: 8px;
    }
    .cut-line {
        margin-top: 10px;
        margin-left: 10px;
        text-align: center;
        font-size: 1em;
        position: relative;
    }
    // .cut-line:before, .cut-line:after {
    //     content: "---------------------------";
    //     display: block;
    //     margin-bottom: 2px;
    // }
    .cut-line span {
        font-size: 10px;
    }
</style>

<div class="wrapper">
    <div class="header">
        HASAN GIFT CEREMONY<br>
        Bagerhat Sadar, Bagerhat
    </div>

    <div class="qr">
        <img src="' . $qrImagePath . '" alt="QR Code"><br>
        <small>Gift Verification</small>
    </div>

    <div class="section">
        <span class="label">Date:</span> <span class="data">17/05/2025</span><br>
        <span class="label">Time:</span> 01:30 PM<br>
        <span class="label">Gift ID:</span> <span class="data">786001</span>
    </div>

    <div class="section">
        <span class="label">Name:</span> <span class="data">Abdullah Saad</span><br>
        <span class="label">Address:</span> Bagerhat<br>
        <span class="label">Relation:</span> Uncle
    </div>

    <div class="section-amount">
        <span class="label">Amount:</span> <span class="data">1000 </span>Taka<br>
        <span class="label">In Words:</span> One Thousand Taka Only
    </div>

    <div class="signature">
        ____________________<br>
        Receiver Signature
    </div>

    <div class="footer">
        <strong>Thank you for your kind gift.</strong><br>
        Printed by:<br>
        Digital Service, 01911-676706
    </div>
</div>

<div class="cut-line"> 
    -✂--------------------- Tear Here ------------------------ 
</div>

';

$dompdf->setPaper($customPaper);
$dompdf->loadHtml($html);
$dompdf->render();
$dompdf->stream("gift_ticket_pos.pdf", ["Attachment" => false]);
exit;
