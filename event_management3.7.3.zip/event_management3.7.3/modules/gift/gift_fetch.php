<?php
// modules/gift/gift_fetch.php

include('../../database_connection.php');

$stmt = $connect->prepare("SELECT * FROM gift ORDER BY gift_id DESC");
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Optional: ensure image paths are formatted properly (if needed)
foreach ($rows as &$row) {
    if (!empty($row['gift_image'])) {
        $row['gift_image'] = $row['gift_image']; // already relative path
    } else {
        $row['gift_image'] = ''; // ensure empty string if no image
    }
}

echo json_encode(['data' => $rows]);