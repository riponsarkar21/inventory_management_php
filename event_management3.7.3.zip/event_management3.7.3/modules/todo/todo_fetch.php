<?php
// modules/todo/todo_fetch.php
include('../../database_connection.php');

$query = "SELECT * FROM to_do_update ORDER BY created_at DESC";
$stmt = $connect->prepare($query);
$stmt->execute();
$data = $stmt->fetchAll();

$output = '<table class="table table-bordered table-striped">';
$output .= '
    <thead>
        <tr>
            <th>ID</th>
            <th>Bug ID</th>
            <th>Description</th>
            <th>Created By</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>';

foreach ($data as $row) {
    $output .= '<tr>';
    $output .= '<td>' . $row['id'] . '</td>';
    $output .= '<td>' . $row['bug_id'] . '</td>';
    $output .= '<td>' . nl2br(htmlspecialchars($row['bug_description'])) . '</td>';
    $output .= '<td>' . $row['created_by'] . '<br><small>' . $row['created_at'] . '</small></td>';
    $output .= '<td>' . $row['status'] . '</td>';

    if ($row['status'] == 'Open') {
        $output .= '<td><button class="btn btn-sm btn-success solve-btn" data-id="' . $row['id'] . '">Mark as Solved</button></td>';
    } else {
        $output .= '<td><span class="text-muted">Solved by ' . $row['solved_by'] . '<br><small>' . $row['solved_at'] . '</small></span></td>';
    }

    $output .= '</tr>';
}

$output .= '</tbody></table>';

echo $output;