<?php
// modules/version/version.php

include('../../database_connection.php');
include('../../function.php');
include('../../header.php');

?><link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.2/css/bootstrap-select.min.css"><script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.2/js/bootstrap-select.min.js"></script><span id="alert_action"></span>

<div class="row">
  <div class="col-lg-12">
    <div class="panel panel-default">
      <div class="panel-heading">
        <div class="row">
          <div class="col-lg-10">
            <h3 class="panel-title">Version History</h3>
          </div>
          <div class="col-lg-2 text-right">
            <?php if ($_SESSION['type'] == 'Master') { ?>
            <button type="button" name="add" id="add_button" class="btn btn-success btn-xs">Add</button>
            <?php } ?>
          </div>
        </div>
      </div>
      <div class="panel-body">
        <div class="table-responsive">
          <table id="version_data" class="table table-bordered table-striped w-100">
            <thead>
              <tr>
                <th>Version</th>
                <th>Release Date</th>
                <th>Features</th>
                <th>Changelog</th>
                <th>File</th>
                <th>Created By</th>
                <th>Created At</th>
                <th>PDF</th>
                <?php if ($_SESSION['type'] == 'Master') { echo '<th>Delete</th>'; } ?>
              </tr>
            </thead>
          </table>
        </div>
      </div>
    </div>
  </div>
</div><!-- Version Modal --><div id="versionModal" class="modal fade">
  <div class="modal-dialog">
    <form method="post" id="version_form" enctype="multipart/form-data">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><i class="fa fa-plus"></i> Add Version</h4>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Release Date</label>
            <input type="date" name="release_date" class="form-control" required />
          </div>
          <div class="form-group">
            <label>Features</label>
            <textarea name="features" class="form-control" required></textarea>
          </div>
          <div class="form-group">
            <label>Changelog / Notes</label>
            <textarea name="changelog" class="form-control"></textarea>
          </div>
          <div class="form-group">
            <label>Attach File (optional)</label>
            <input type="file" name="version_file" class="form-control" />
          </div>
        </div>
        <div class="modal-footer">
          <input type="hidden" name="btn_action" id="btn_action" />
          <input type="submit" name="action" id="action" class="btn btn-info" value="Add" />
        </div>
      </div>
    </form>
  </div>
</div><script>
$(document).ready(function() {
  var versionTable = $('#version_data').DataTable({
    processing: true,
    serverSide: true,
    ajax: {
      // url: "version_fetch.php",
      url: "version_fetch.php",
      type: "POST"
    },
    order: [],
    columnDefs: [
      { targets: [7<?php if ($_SESSION['type'] == 'Master') echo ',8'; ?>], orderable: false }
    ],
    lengthMenu: [[5, 10, 25, 50], [5, 10, 25, 50]]
  });

  $('#add_button').click(function() {
    $('#version_form')[0].reset();
    $('.modal-title').html("<i class='fa fa-plus'></i> Add Version");
    $('#action').val("Add");
    $('#btn_action').val("Add");
    $('#versionModal').modal('show');
  });

  $('#version_form').on('submit', function(e) {
    e.preventDefault();
    var formData = new FormData(this);
    $('#action').prop('disabled', true);
    $.ajax({
      url: 'version_action.php',
      "order": [[0, "desc"]],
      method: 'POST',
      data: formData,
      contentType: false,
      processData: false,
      success: function(data) {
        $('#version_form')[0].reset();
        $('#versionModal').modal('hide');
        $('#alert_action').html('<div class="alert alert-success">' + data + '</div>');
        $('#action').prop('disabled', false);
        versionTable.ajax.reload();
      }
    });
  });

  $(document).on('click', '.delete', function() {
    if (!confirm("Are you sure you want to delete this version?")) return;
    var id = $(this).attr("id");
    $.post("version_action.php", { version_id: id, btn_action: "delete" }, function(data) {
      $('#alert_action').html('<div class="alert alert-danger">' + data + '</div>');
      versionTable.ajax.reload();
    });
  });
});
</script><?php include('../../footer.php');