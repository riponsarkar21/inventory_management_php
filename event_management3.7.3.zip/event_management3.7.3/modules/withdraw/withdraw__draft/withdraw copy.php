<?php
// File: modules/withdraw/withdraw.php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php'); // Redirect to login if not logged in
    exit;
}
include('../../config/database_connection.php');
include('../../header.php');
?>

<!-- DataTables CSS & Buttons -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
<link rel="stylesheet" href="../../css/datepicker.css">

<style>
    .btn-wrapper {
        display: flex;
        justify-content: center;
    }
    @media (max-width: 768px) {
        .btn-wrapper {
            flex-direction: column;
            align-items: center;
        }
        .btn-wrapper button {
            margin-bottom: 5px;
            width: 90px;
        }
    }
    .label {
        padding: 4px 8px;
        border-radius: 4px;
        color: white;
    }
    .label-success {background-color: #28a745;}
    .label-warning {background-color: #ffc107; color: black;}
    .label-danger {background-color: #dc3545;}
    .label-default {background-color: #6c757d;}
</style>

<div class="container mt-3">
    <span id="alert_action"></span>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading clearfix">
                    <div class="pull-left">
                        <h3 class="panel-title">Withdraw Entry List</h3>
                    </div>
                    <div class="pull-right">
                        <button type="button" id="add_button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#withdrawModal">Add Entry</button>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table id="withdraw_data" class="table table-bordered table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Person Name</th>
                                    <th>Phone</th>
                                    <th>Amount</th>
                                    <th>Method</th>
                                    <th>Note</th>
                                    <th>Status</th>
                                    <th>Update</th>
                                    <th>Change Status</th>
                                    <th>Cancel</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="withdrawModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="withdrawModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <form method="post" id="withdraw_form" enctype="multipart/form-data">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Withdraw Entry</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">&times;</button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="withdraw_id" id="withdraw_id" value="">
                    <div class="form-group">
                        <label for="person_name">Person Name</label>
                        <input type="text" name="person_name" id="person_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input type="text" name="phone" id="phone" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="amount">Amount</label>
                        <input type="number" step="0.01" name="amount" id="amount" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="payment_method">Payment Method</label>
                        <select name="payment_method" id="payment_method" class="form-control" required>
                            <option value="Cash">Cash</option>
                            <option value="Bank">Bank</option>
                            <option value="Bkash">Bkash</option>
                            <option value="Nagad">Nagad</option>
                            <option value="Others">Others</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="note">Note</label>
                        <textarea name="note" id="note" class="form-control"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="submit" name="action" id="action" class="btn btn-info" value="Add" />
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- DataTables & Buttons Scripts -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
$(document).ready(function() {
    var table = $('#withdraw_data').DataTable({
        ajax: "withdraw_fetch.php",
        order: [[0, "desc"]],
        columns: [
            { data: "withdraw_id" },
            { data: "person_name" },
            { data: "phone" },
            { data: "amount" },
            { data: "payment_method" },
            { data: "note" },
            { 
                data: "status",
                className: "text-center",
                render: function(data) {
                    let colorClass = '';
                    switch (data.toLowerCase()) {
                        case 'active': colorClass = 'label label-success'; break;
                        case 'inactive': colorClass = 'label label-warning'; break;
                        case 'cancel':
                        case 'cancelled': colorClass = 'label label-danger'; break;
                        default: colorClass = 'label label-default';
                    }
                    return `<span class="${colorClass}">${data}</span>`;
                }
            },
            {
                data: null,
                orderable: false,
                render: function(row) {
                    return `<button class="btn btn-primary btn-sm update-entry" data-id="${row.withdraw_id}">Update</button>`;
                }
            },
            {
                data: null,
                orderable: false,
                render: function(row) {
                    return `<button class="btn btn-info btn-sm change-status" data-id="${row.withdraw_id}">Change Status</button>`;
                }
            },
            {
                data: null,
                orderable: false,
                render: function(row) {
                    return `<button class="btn btn-warning btn-sm cancel-entry" data-id="${row.withdraw_id}">Cancel</button>`;
                }
            },
            {
                data: null,
                orderable: false,
                render: function(row) {
                    return `<button class="btn btn-danger btn-sm delete" data-id="${row.withdraw_id}">Delete</button>`;
                }
            }
        ],
        lengthMenu: [[5,10,25,50], [5,10,25,50]],
        pageLength: 10,
        dom: "<'row'<'col-sm-6'l><'col-sm-6'f>>" +
             "<'row'<'col-sm-12'tr>>" +
             "<'row'<'col-sm-5'i><'col-sm-7'p>>" +
             "<'row'<'col-sm-12 text-center mt-3'B>>",
        buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
    });

    // 🟢 Submit form (Add/Update)
    $('#withdraw_form').on('submit', function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        formData.set('action', $('#action').val());

        $.ajax({
            url: 'withdraw_action.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                let message = typeof response === 'object' ? JSON.stringify(response) : response;
                $('#alert_action').html('<div class="alert alert-success">✅ ' + message + '</div>');

                // Close modal properly
                $('#withdrawModal').modal('hide');
                setTimeout(function() {
                    $('.modal-backdrop').remove(); // Remove lingering overlay
                    $('body').removeClass('modal-open');
                }, 500);

                $('#withdraw_form')[0].reset();
                $('#action').val('Add');
                $('#withdraw_id').val('');
                table.ajax.reload(null, false);
            },
            error: function(xhr) {
                $('#alert_action').html('<div class="alert alert-danger">❌ Error: ' + xhr.statusText + '</div>');
            }
        });
    });

    // 🟡 Fetch data to update
    $(document).on('click', '.update-entry', function() {
        var id = $(this).data('id');
        $.post('withdraw_action.php', { action: 'fetch_single', id: id }, function(data) {
            var d = JSON.parse(data);
            $('#withdraw_id').val(d.withdraw_id);
            $('#person_name').val(d.person_name);
            $('#phone').val(d.phone);
            $('#amount').val(d.amount);
            $('#payment_method').val(d.payment_method);
            $('#note').val(d.note);
            $('#action').val('Update');
            $('#withdrawModal').modal('show');
        });
    });

    // 🟠 Change status
    $(document).on('click', '.change-status', function() {
        var id = $(this).data('id');
        if(confirm("Change status to inactive?")) {
            $.post('withdraw_action.php', { action: 'change_status', id: id }, function(response) {
                $('#alert_action').html('<div class="alert alert-info">🔄 ' + response + '</div>');
                table.ajax.reload(null, false);
            });
        }
    });

    // 🔴 Cancel
    $(document).on('click', '.cancel-entry', function() {
        var id = $(this).data('id');
        if(confirm("Cancel this withdraw entry?")) {
            $.post('withdraw_action.php', { action: 'cancel', id: id }, function(response) {
                $('#alert_action').html('<div class="alert alert-warning">⚠️ ' + response + '</div>');
                table.ajax.reload(null, false);
            });
        }
    });

    // ⚫ Delete
    $(document).on('click', '.delete', function() {
        var id = $(this).data('id');
        if(confirm("Delete this withdraw entry permanently?")) {
            $.post('withdraw_action.php', { action: 'delete', id: id }, function(response) {
                $('#alert_action').html('<div class="alert alert-danger">🗑️ ' + response + '</div>');
                table.ajax.reload(null, false);
            });
        }
    });
});
</script>


<?php include('../../footer.php'); ?>
