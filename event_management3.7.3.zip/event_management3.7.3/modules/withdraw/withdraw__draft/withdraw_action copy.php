<?php
// File: modules/withdraw/withdraw_action.php
session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo "Unauthorized - Please login.";
    exit;
}

include('../../config/database_connection.php');

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'] ?? 'user';

$action = $_POST['action'] ?? '';

if (!$action) {
    echo "No action received.";
    exit;
}

function isEntryOwner($connect, $entry_id, $user_id) {
    $stmt = $connect->prepare("SELECT user_id FROM withdraw WHERE withdraw_id = ?");
    $stmt->execute([$entry_id]);
    $owner = $stmt->fetchColumn();
    return ($owner == $user_id);
}

try {
    if ($action === 'Add' || $action === 'Update') {
        $withdraw_id = isset($_POST['withdraw_id']) ? intval($_POST['withdraw_id']) : 0;
        $person_name = trim($_POST['person_name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $amount = floatval($_POST['amount'] ?? 0);
        $payment_method = trim($_POST['payment_method'] ?? '');
        $note = trim($_POST['note'] ?? '');
        
        if ($action === 'Update') {
            // Check permission
            if ($role !== 'admin' && !isEntryOwner($connect, $withdraw_id, $user_id)) {
                echo "Permission denied to update this entry.";
                exit;
            }
        }

        if ($action === 'Add') {
            $stmt = $connect->prepare("INSERT INTO withdraw (person_name, phone, amount, payment_method, note, user_id) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$person_name, $phone, $amount, $payment_method, $note, $user_id]);
            echo "Withdraw entry added.";
        } else {
            $stmt = $connect->prepare("UPDATE withdraw SET person_name=?, phone=?, amount=?, payment_method=?, note=?, updated_at=NOW() WHERE withdraw_id=?");
            $stmt->execute([$person_name, $phone, $amount, $payment_method, $note, $withdraw_id]);
            echo "Withdraw entry updated.";
        }
    } elseif ($action === 'delete') {
        $id = intval($_POST['id']);
        if ($role !== 'admin' && !isEntryOwner($connect, $id, $user_id)) {
            echo "Permission denied to delete this entry.";
            exit;
        }
        $stmt = $connect->prepare("DELETE FROM withdraw WHERE withdraw_id=?");
        $stmt->execute([$id]);
        echo "Withdraw entry deleted.";
    } elseif ($action === 'change_status') {
        $id = intval($_POST['id']);
        if ($role !== 'admin' && !isEntryOwner($connect, $id, $user_id)) {
            echo "Permission denied to change status.";
            exit;
        }
        $stmt = $connect->prepare("UPDATE withdraw SET status='inactive', updated_at=NOW() WHERE withdraw_id=?");
        $stmt->execute([$id]);
        echo "Status updated to inactive.";
    } elseif ($action === 'cancel') {
        $id = intval($_POST['id']);
        if ($role !== 'admin' && !isEntryOwner($connect, $id, $user_id)) {
            echo "Permission denied to cancel.";
            exit;
        }
        $stmt = $connect->prepare("UPDATE withdraw SET status='cancel', updated_at=NOW() WHERE withdraw_id=?");
        $stmt->execute([$id]);
        echo "Entry cancelled.";
    } elseif ($action === 'fetch_single') {
        $id = intval($_POST['id']);
        if ($role !== 'admin' && !isEntryOwner($connect, $id, $user_id)) {
            echo json_encode(['error' => 'Permission denied']);
            exit;
        }
        $stmt = $connect->prepare("SELECT * FROM withdraw WHERE withdraw_id = ?");
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode($row ?: []);
    } else {
        echo "Invalid action.";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
