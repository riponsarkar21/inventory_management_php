<?php
// File: modules/withdraw/withdraw_fetch.php
session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

include('../../config/database_connection.php');

$user_id = $_SESSION['user_id'];
$user_type = $_SESSION['user_type'] ?? 'Gift User';

try {
    if ($user_type === 'Gift Admin') {
        $stmt = $connect->prepare("SELECT * FROM withdraw ORDER BY withdraw_id DESC");
        $stmt->execute();
    } else {
        $stmt = $connect->prepare("SELECT * FROM withdraw WHERE user_id = ? ORDER BY withdraw_id DESC");
        $stmt->execute([$user_id]);
    }
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Format data for DataTables
    echo json_encode([
        "data" => $results
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["error" => "Failed to fetch data: " . $e->getMessage()]);
}
