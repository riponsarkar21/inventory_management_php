<?php
include('../../database_connection.php');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(403);
    exit("Access denied");
}

$action = $_POST['action'] ?? '';

if ($action === 'fetch_single') {
    $stmt = $connect->prepare("SELECT * FROM withdraw WHERE withdraw_id = ?");
    $stmt->execute([$_POST['id']]);
    echo json_encode($stmt->fetch(PDO::FETCH_ASSOC));
}

elseif ($action === 'Add') {
    $stmt = $connect->prepare("INSERT INTO withdraw (person_name, phone, amount, payment_method, note, status, user_id) VALUES (?, ?, ?, ?, ?, 'active', ?)");
    $stmt->execute([
        $_POST['person_name'],
        $_POST['phone'],
        $_POST['amount'],
        $_POST['payment_method'],
        $_POST['note'],
        1 // Replace with session user ID if available
    ]);
    echo 'Withdraw entry added successfully.';
}

elseif ($action === 'Update') {
    $stmt = $connect->prepare("UPDATE withdraw SET person_name=?, phone=?, amount=?, payment_method=?, note=? WHERE withdraw_id=?");
    $stmt->execute([
        $_POST['person_name'],
        $_POST['phone'],
        $_POST['amount'],
        $_POST['payment_method'],
        $_POST['note'],
        $_POST['withdraw_id']
    ]);
    echo 'Withdraw entry updated.';
}

elseif ($action === 'delete') {
    $stmt = $connect->prepare("DELETE FROM withdraw WHERE withdraw_id = ?");
    $stmt->execute([$_POST['id']]);
    echo 'Withdraw entry deleted.';
}

elseif ($action === 'change_status') {
    $stmt = $connect->prepare("SELECT status FROM withdraw WHERE withdraw_id = ?");
    $stmt->execute([$_POST['id']]);
    $status = $stmt->fetch(PDO::FETCH_ASSOC)['status'];
    $newStatus = ($status === 'active') ? 'inactive' : 'active';

    $stmt = $connect->prepare("UPDATE withdraw SET status = ? WHERE withdraw_id = ?");
    $stmt->execute([$newStatus, $_POST['id']]);
    echo "Status changed to $newStatus.";
}

else {
    echo "Invalid request. No action found.";
}
