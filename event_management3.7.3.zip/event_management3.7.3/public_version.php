<?php
// public_version.php – Public-facing version changelog

include('database_connection.php');

$stmt = $connect->prepare("SELECT * FROM version ORDER BY version_id DESC");
$stmt->execute();
$versions = $stmt->fetchAll(PDO::FETCH_ASSOC);
?><!DOCTYPE html><html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Version History</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css">
  <style>
    body { padding: 40px; background: #f9f9f9; font-family: sans-serif; }
    .version-card { background: white; padding: 20px; margin-bottom: 20px; border-left: 5px solid #337ab7; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .version-title { font-size: 1.5em; margin-bottom: 5px; color: #337ab7; }
    .meta { font-size: 0.9em; color: #777; }
    pre { background: #f4f4f4; padding: 10px; }
  </style>
</head>
<body>  <div class="container">
    <h2><i class="glyphicon glyphicon-time"></i> Version History</h2>
    <hr><?php foreach ($versions as $row): ?>
  <div class="version-card">
    <div class="version-title">
      <?= htmlspecialchars($row['version_number']) ?>
    </div>
    <div class="meta">
      Released on <?= htmlspecialchars($row['release_date']) ?> | Created by <?= htmlspecialchars($row['created_by']) ?> | <?= htmlspecialchars($row['created_at']) ?>
    </div>

    <h4>Features:</h4>
    <p><?= nl2br(htmlspecialchars($row['features'])) ?></p>

    <?php if (!empty($row['changelog'])): ?>
      <h4>Changelog:</h4>
      <pre><?= htmlspecialchars($row['changelog']) ?></pre>
    <?php endif; ?>

    <?php if (!empty($row['file_path'])): ?>
      <p><strong>Attachment:</strong> <a href="<?= htmlspecialchars($row['file_path']) ?>" target="_blank">Download File</a></p>
    <?php endif; ?>

    <p><a href="modules/version/version_pdf.php?id=<?= $row['version_id'] ?>" target="_blank" class="btn btn-xs btn-primary">View PDF</a></p>
  </div>
<?php endforeach; ?>

  </div></body>
</html>