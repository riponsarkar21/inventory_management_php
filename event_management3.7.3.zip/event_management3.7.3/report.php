<?php
// report.php

session_start();
include('database_connection.php');
include('function.php');
include('header.php')

// Optional: Restrict access if needed
// if(!isset($_SESSION['type'])) {
//     header("location:login.php");
//     exit();
// }
?>

<!DOCTYPE html>
<html>
<head>
    <title>Inventory Report</title>
    <!-- <link rel="stylesheet" href="style.css"> Add your own stylesheet -->
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"> -->
</head>
<body>
<div class="container mt-4">
    <h2 class="text-center">Inventory Summary Report</h2>

    <div class="row mt-5">
        <!-- Summary Cards -->
        <div class="col-md-3">
            <div class="card text-white bg-primary mb-3">
                <div class="card-body">
                    <h5 class="card-title">Total Users</h5>
                    <p class="card-text"><?php echo count_total_user($connect); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-success mb-3">
                <div class="card-body">
                    <h5 class="card-title">Total Categories</h5>
                    <p class="card-text"><?php echo count_total_category($connect); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-warning mb-3">
                <div class="card-body">
                    <h5 class="card-title">Total Brands</h5>
                    <p class="card-text"><?php echo count_total_brand($connect); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-info mb-3">
                <div class="card-body">
                    <h5 class="card-title">Items in Stock</h5>
                    <p class="card-text"><?php echo count_total_product($connect); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Order Summary -->
    <div class="row mt-4">
        <div class="col-md-4">
            <div class="card text-white bg-secondary mb-3">
                <div class="card-body">
                    <h5 class="card-title">Total Order Value</h5>
                    <p class="card-text">$ <?php echo count_total_order_value($connect); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-white bg-success mb-3">
                <div class="card-body">
                    <h5 class="card-title">Cash Orders</h5>
                    <p class="card-text">$ <?php echo count_total_cash_order_value($connect); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-white bg-danger mb-3">
                <div class="card-body">
                    <h5 class="card-title">Credit Orders</h5>
                    <p class="card-text">$ <?php echo count_total_credit_order_value($connect); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- User-wise Orders -->
    <div class="row mt-4">
        <div class="col-12">
            <h4>User-wise Order Summary</h4>
            <?php echo get_user_wise_total_order($connect); ?>
        </div>
    </div>

    <!-- User-wise Collection -->
    <div class="row mt-4">
        <div class="col-12">
            <h4>User-wise Collection Summary</h4>
            <?php echo get_user_wise_total_collection($connect); ?>
        </div>
    </div>

</div>
</body>
</html>
