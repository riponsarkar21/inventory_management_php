<?php
// user.php

include('database_connection.php');

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// if (!isset($_SESSION["type"]) || $_SESSION["type"] !== 'Master') {
//     header("location:login.php");
//     exit();
// }

if (!isset($_SESSION["type"]) || !in_array($_SESSION["type"], ['Super Master', 'Master', 'Gift Admin', 'Inventory Admin'])) {
    header("location:login.php");
    exit();
}


include('header.php');
?>

<span id="alert_action"></span>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading clearfix">
                <div class="pull-left">
                    <h3 class="panel-title">User List</h3>
                </div>
                <div class="pull-right">
                    <button type="button" id="add_button" data-toggle="modal" data-target="#userModal" class="btn btn-success btn-xs">Add</button>
                </div>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table id="user_data" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Photo</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Address</th>
                                <th>Reference</th>
                                <th>Edit</th>
                                <th>Visibility</th>
                                <th>Delete</th>
                                <th>View</th>

                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="userModal" class="modal fade">
    <div class="modal-dialog">
        <form method="post" id="user_form" enctype="multipart/form-data">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-plus"></i> Add User</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>User Name</label>
                        <input type="text" name="user_name" id="user_name" class="form-control" required />
                    </div>
                    <div class="form-group">
                        <label>User Email</label>
                        <input type="email" name="user_email" id="user_email" class="form-control" required />
                    </div>
                    <div class="form-group">
                        <label>User Password</label>
                        <input type="password" name="user_password" id="user_password" class="form-control" />
                    </div>
                    <div class="form-group">
                        <label>User Role</label>
                        <select name="user_type" id="user_type" class="form-control" required>
                            <option value="">Select Role</option>
                            <option value="Super Master">Super Master</option>
                            <option value="Master">Master</option>
                            <option value="Admin">Admin</option>
                            <option value="User">User</option>
                            <option value="Salesman">Salesman</option>
                            <option value="Cashier">Cashier</option>
                            <option value="Supervisor">Supervisor</option>

                            <option value="Gift Admin">Gift Admin</option>
                            <option value="Gift User">Gift User</option>

                            <option value="Inventory Admin">Inventory Admin</option>
                            <option value="Inventory User">Inventory User</option>

                        </select>
                    </div>
                    <div class="form-group">
                        <label>User Address</label>
                        <input type="text" name="user_address" id="user_address" class="form-control" />
                    </div>
                    <div class="form-group">
                        <label>User Image</label>
                        <input type="file" name="user_image" id="user_image" class="form-control" />
                        <span id="uploaded_image"></span>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="user_id" id="user_id" />
                    <input type="hidden" name="btn_action" id="btn_action" />
                    <input type="submit" name="action" id="action" class="btn btn-info" value="Add" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
$(document).ready(function(){
    const userdataTable = $('#user_data').DataTable({
        "processing": true,
        "serverSide": true,
        "ajax": {
            url: "user_fetch.php",
            type: "POST"
        },
        "order": [[0, "desc"]],
        "columnDefs": [
            {
                "targets": [6,7,8],
                "orderable": false
            }
        ]
    });

    $('#add_button').click(function(){
        $('#user_form')[0].reset();
        $('#uploaded_image').html('');
        $('.modal-title').html("<i class='fa fa-plus'></i> Add User");
        $('#action').val("Add");
        $('#btn_action').val("Add");
        $('#user_password').attr('required', true);
    });

    $('#user_form').on('submit', function(event){
        event.preventDefault();
        const formData = new FormData(this);
        $.ajax({
            url: "user_action.php",
            method: "POST",
            data: formData,
            contentType: false,
            processData: false,
            success: function(data){
                $('#user_form')[0].reset();
                $('#userModal').modal('hide');
                $('#alert_action').html('<div class="alert alert-success">'+data+'</div>');
                userdataTable.ajax.reload();
            }
        });
    });

    $(document).on('click', '.update', function(){
        const user_id = $(this).attr("id");
        $.post("user_action.php", { user_id, btn_action: "fetch_single" }, function(data){
            $('#userModal').modal('show');
            $('#user_name').val(data.user_name);
            $('#user_email').val(data.user_email);
            $('#user_type').val(data.user_type);
            $('#user_address').val(data.user_address ?? ''); // Optional, if you're using address in DB
            $('#uploaded_image').html(data.user_image ? `<img src="${data.user_image}" width="100" class="img-thumbnail" />` : '');
            $('.modal-title').html("<i class='fa fa-pencil-square-o'></i> Edit User");
            $('#user_id').val(user_id);
            $('#action').val('Edit');
            $('#btn_action').val('Edit');
            $('#user_password').removeAttr('required');
        }, 'json');
    });

    $(document).on('click', '.status', function(){
        if (!confirm("Change status?")) return;
        const user_id = $(this).attr("id");
        const status = $(this).data('status');
        $.post("user_action.php", { user_id, status, btn_action: "status" }, function(data){
            $('#alert_action').html('<div class="alert alert-info">'+data+'</div>');
            userdataTable.ajax.reload();
        });
    });

    $(document).on('click', '.delete', function(){
        if (!confirm("Delete user?")) return;
        const user_id = $(this).attr("id");
        $.post("user_action.php", { user_id, btn_action: "delete" }, function(data){
            $('#alert_action').html('<div class="alert alert-danger">'+data+'</div>');
            userdataTable.ajax.reload();
        });
    });
});
</script>

<?php include('footer.php'); ?>