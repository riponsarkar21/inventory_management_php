<?php
// user_fetch.php

include('database_connection.php');

$columns = ['user_id', 'user_image', 'user_name', 'user_email', 'user_phone', 'user_type', 'user_status', 'user_address', 'user_reference'];

$query = "SELECT * FROM user_details WHERE 1=1";

if (!empty($_POST['search']['value'])) {
    $query .= " AND (
        user_email LIKE :search OR 
        user_name LIKE :search OR 
        user_phone LIKE :search OR 
        user_status LIKE :search OR 
        user_type LIKE :search OR 
        user_address LIKE :search OR 
        user_reference LIKE :search
    )";
}

$order = " ORDER BY user_id DESC";
if (isset($_POST['order'])) {
    $colIdx = $_POST['order']['0']['column'];
    $dir = $_POST['order']['0']['dir'];
    if (isset($columns[$colIdx])) {
        $order = " ORDER BY {$columns[$colIdx]} {$dir}";
    }
}

$limit = "";
if ($_POST["length"] != -1) {
    $limit = " LIMIT :start, :length";
}

$statement = $connect->prepare($query . $order . $limit);

if (!empty($_POST['search']['value'])) {
    $search_value = '%' . $_POST['search']['value'] . '%';
    $statement->bindValue(':search', $search_value);
}
if ($_POST["length"] != -1) {
    $statement->bindValue(':start', (int)$_POST['start'], PDO::PARAM_INT);
    $statement->bindValue(':length', (int)$_POST['length'], PDO::PARAM_INT);
}

$statement->execute();
$data = [];

foreach($statement->fetchAll() as $row) {
    $status = ($row["user_status"] == 'Active') 
        ? '<span class="label label-success">Active</span>' 
        : '<span class="label label-danger">Inactive</span>';

    $image = $row["user_image"] 
        ? "<img src='{$row["user_image"]}' width='40' class='img-thumbnail'>" 
        : "N/A";

    $data[] = [
        $row["user_id"], // 0
        $image,          // 1
        $row["user_name"], // 2
        $row["user_email"], // 3
        $row["user_phone"], // 4
        $row["user_type"], // 5
        $status,           // 6
        $row["user_address"], // 7
        $row["user_reference"], // 8
        '<button type="button" name="update" id="'.$row["user_id"].'" class="btn btn-warning btn-xs update">Edit</button>', // 9
        '<button type="button" name="status" id="'.$row["user_id"].'" class="btn btn-primary btn-xs status" data-status="'.$row["user_status"].'">Change</button>', // 10
        '<button type="button" name="delete" id="'.$row["user_id"].'" class="btn btn-danger btn-xs delete">Delete</button>', // 11
        '<button type="button" class="btn btn-info btn-xs view" id="'.$row["user_id"].'">View</button>' // 12
    ];
}

function get_total_all_records($connect) {
    $stmt = $connect->prepare("SELECT COUNT(*) FROM user_details");
    $stmt->execute();
    return $stmt->fetchColumn();
}

echo json_encode([
    "draw" => intval($_POST["draw"]),
    "recordsTotal" => get_total_all_records($connect),
    "recordsFiltered" => get_total_all_records($connect),
    "data" => $data
]);
