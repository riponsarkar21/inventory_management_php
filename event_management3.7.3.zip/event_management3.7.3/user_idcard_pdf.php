// --- user_idcard_pdf.php ---
<?php
require_once 'pdf.php';
include('database_connection.php');

if (!isset($_GET['id'])) die('Invalid ID');

$stmt = $connect->prepare("SELECT * FROM user_details WHERE user_id = ?");
$stmt->execute([$_GET['id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) die('User not found');

$html = '<style>
body { font-family: Arial; font-size: 14px; }
.card { border: 1px solid #333; padding: 10px; width: 300px; }
img { width: 80px; height: auto; }
</style>';
$html .= '<div class="card">
<h4>ID Card</h4>
<img src="' . $user['user_image'] . '" /><br>
<b>Name:</b> ' . $user['user_name'] . '<br>
<b>Role:</b> ' . $user['user_type'] . '<br>
<b>Email:</b> ' . $user['user_email'] . '<br>
<b>Phone:</b> ' . $user['user_phone'] . '
</div>';

generate_pdf($html, $user['user_name'] . '_idcard');
?>