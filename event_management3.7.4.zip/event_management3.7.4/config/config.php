<?php
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'];
$script_dir = trim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$base_url = $protocol . $host . ($script_dir ? '/' . $script_dir : '') . '/';
// define('BASE_URL', $base_url);

// define('BASE_URL', 'http://localhost/test3/'); // Important: Include trailing slash

if (!defined('BASE_URL')) {
    define('BASE_URL', 'http://riponsarkartest1-001-site1.anytempurl.com/'); // Use trailing slash
    // define('BASE_URL', 'http://localhost/test3/'); // Use trailing slash
}

// config/config.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
