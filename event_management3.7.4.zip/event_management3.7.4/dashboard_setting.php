<?php
// dashboard_setting.php
// 28.07.205 v1
// This page is for define dashboard for different user




session_start();
include('database_connection.php');

// Only allow super master (e.g., user_type == 'Super Master')
if ($_SESSION['user_type'] !== 'Super Master') {
    echo "Access denied.";
    exit();
}

// Handle form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST['dashboard_version'] as $user_id => $version) {
        $stmt = $connect->prepare("UPDATE user_details SET dashboard_version = ? WHERE user_id = ?");
        $stmt->execute([$version, $user_id]);
    }
    echo "<script>alert('Dashboard versions updated successfully.');</script>";
}

// Fetch users
$stmt = $connect->query("SELECT user_id, user_name, dashboard_version FROM user_details");
$users = $stmt->fetchAll();
?>

<form method="post">
    <table border="1" cellpadding="10">
        <tr>
            <th>User Name</th>
            <th>Dashboard Version</th>
        </tr>
        <?php foreach ($users as $user): ?>
        <tr>
            <td><?= htmlspecialchars($user['user_name']) ?></td>
            <td>
                <select name="dashboard_version[<?= $user['user_id'] ?>]">
                    <option value="gift_dashboard1.php" <?= $user['dashboard_version'] == 'gift_dashboard1.php' ? 'selected' : '' ?>>Dashboard 1</option>
                    <option value="gift_dashboard9.php" <?= $user['dashboard_version'] == 'gift_dashboard9.php' ? 'selected' : '' ?>>Dashboard 9</option>
                    <option value="gift_dashboard3.php" <?= $user['dashboard_version'] == 'gift_dashboard3.php' ? 'selected' : '' ?>>Dashboard 3</option>
                </select>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
    <br>
    <button type="submit">Update Dashboard Settings</button>
</form>
