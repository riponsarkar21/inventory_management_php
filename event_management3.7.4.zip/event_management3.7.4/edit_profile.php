<?php
include('database_connection.php');

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$user_id = $_SESSION['user_id'];

// Fetch existing image in case a new one is not uploaded
$query = "SELECT user_image FROM user_details WHERE user_id = :user_id";
$statement = $connect->prepare($query);
$statement->execute([':user_id' => $user_id]);
$row = $statement->fetch();
$existing_image = $row['user_image'];

// Handle uploaded file
$image_path = $existing_image;
if (!empty($_FILES['user_image']['name'])) {
    $image_name = time() . '_' . $_FILES['user_image']['name'];
    $upload_path = 'uploads/' . $image_name;

    // Optional: Validate image type
    $allowed_types = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif'];
    if (!in_array($_FILES['user_image']['type'], $allowed_types)) {
        echo '<div class="alert alert-danger">Invalid image type.</div>';
        exit();
    }

    if (move_uploaded_file($_FILES['user_image']['tmp_name'], $upload_path)) {
        $image_path = $upload_path;
    } else {
        echo '<div class="alert alert-danger">Failed to upload image.</div>';
        exit();
    }
}

// Update fields
$data = [
    ':user_name'      => $_POST['user_name'],
    ':user_email'     => $_POST['user_email'],
    ':user_phone'     => $_POST['user_phone'],
    ':user_address'   => $_POST['user_address'],
    ':user_reference' => $_POST['user_reference'],
    ':user_education' => $_POST['user_education'],
    ':user_experience'=> $_POST['user_experience'],
    ':user_training'  => $_POST['user_training'],
    ':user_image'     => $image_path,
    ':user_id'        => $user_id
];

// Check password update
if (!empty($_POST['user_new_password'])) {
    $data[':user_password'] = password_hash($_POST['user_new_password'], PASSWORD_DEFAULT);

    $query = "
        UPDATE user_details SET 
            user_name = :user_name,
            user_email = :user_email,
            user_phone = :user_phone,
            user_address = :user_address,
            user_reference = :user_reference,
            user_education = :user_education,
            user_experience = :user_experience,
            user_training = :user_training,
            user_image = :user_image,
            user_password = :user_password
        WHERE user_id = :user_id
    ";
} else {
    $query = "
        UPDATE user_details SET 
            user_name = :user_name,
            user_email = :user_email,
            user_phone = :user_phone,
            user_address = :user_address,
            user_reference = :user_reference,
            user_education = :user_education,
            user_experience = :user_experience,
            user_training = :user_training,
            user_image = :user_image
        WHERE user_id = :user_id
    ";
}

$statement = $connect->prepare($query);
$success = $statement->execute($data);

if ($success) {
    echo '<div class="alert alert-success">Profile updated successfully.</div>';
} else {
    echo '<div class="alert alert-danger">Update failed.</div>';
}
?>