<?php
// gift_dashboard.php
// with redirect fetch
session_start();
include('database_connection.php');

// Assume user is logged in and user_id is stored in session
$user_id = $_SESSION['user_id'] ?? null;

if (!$user_id) {
    // Redirect to login if not logged in
    header("Location: login.php");
    exit();
}

// Get user's assigned dashboard
$query = $connect->prepare("SELECT dashboard_version FROM user_details WHERE user_id = ?");
$query->execute([$user_id]);
$result = $query->fetch();

if ($result && !empty($result['dashboard_version'])) {
    $dashboard = $result['dashboard_version'];
    header("Location: $dashboard");
    exit();
} else {
    // Default fallback if no dashboard assigned
    header("Location: gift_dashboard1.php");
    exit();
}
?>
