<?php
// header.php

// 26.07.2025: v10: 
// added event, gift_settings button to super master

require 'config/config.php';




if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
    $redirect = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header('Location: ' . $redirect);
    exit();
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$version = time();
$current_page = $_SERVER['REQUEST_URI'];
?>

<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <title>Inventory Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS -->
    <link rel="stylesheet" href="<?= BASE_URL ?>css/bootstrap.min.css?v=<?= $version ?>">
    <link rel="stylesheet" href="<?= BASE_URL ?>css/styles.css?v=<?= $version ?>">
    <link rel="stylesheet" href="<?= BASE_URL ?>css/datepicker.css?v=<?= $version ?>">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">

    <!-- ✅ JS (Correct Order) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="<?= BASE_URL ?>js/bootstrap.min.js?v=<?= $version ?>"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>

    <style>
        body { font-family: 'Segoe UI', sans-serif; margin: 0; padding: 0; }
        .sidebar {
            height: 100vh;
            width: 220px;
            position: fixed;
            background-color: #343a40;
            padding-top: 10px;
            overflow-y: auto;
            transition: width 0.3s ease;
        }

        .sidebar.collapsed { width: 60px; }
        .sidebar a {
            color: white;
            display: block;
            padding: 10px 20px;
            text-decoration: none;
        }

        .sidebar.collapsed a { padding: 10px; text-align: center; }
        .sidebar.collapsed .label { display: none; }

        .content {
            margin-left: 240px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }

        .sidebar.collapsed + .content { margin-left: 80px; }

        #sidebar-toggle {
            color: white;
            padding: 10px 20px;
            cursor: pointer;
            font-size: 18px;
        }

        html[data-theme="dark"] {
            background: #121212;
            color: #e0e0e0;
        }

        html[data-theme="dark"] .sidebar,
        html[data-theme="dark"] .sidebar a {
            background-color: #222;
            color: #ccc;
        }



        /* Fix for DataTable header misalignment with scrollX */

        .dataTables_wrapper .dataTables_scroll {
            overflow: auto;
        }

        table.dataTable {
            width: 100% !important;
        }

        table.dataTable thead th,
        table.dataTable tbody td {
            white-space: nowrap;
        }




    </style>

    <script>
        function toggleTheme() {
            const html = document.documentElement;
            html.dataset.theme = html.dataset.theme === 'dark' ? 'light' : 'dark';
            localStorage.setItem('theme', html.dataset.theme);
        }

        function toggleSidebar() {
            $('.sidebar').toggleClass('collapsed');
            localStorage.setItem('sidebarCollapsed', $('.sidebar').hasClass('collapsed') ? 'yes' : 'no');
        }

        $(document).ready(function () {
            document.documentElement.dataset.theme = localStorage.getItem('theme') || 'light';
            if (localStorage.getItem('sidebarCollapsed') === 'yes') {
                $('.sidebar').addClass('collapsed');
            }
        });
    </script>
</head>








<body>
<div class="sidebar">
    <div id="sidebar-toggle" onclick="toggleSidebar()">☰</div>

    <?php if (!in_array($_SESSION['type'], ['Gift Admin', 'Gift User'])) { ?>
    <a href="<?= BASE_URL ?>index.php" class="<?= strpos($current_page, '/index.php') !== false ? 'active' : '' ?>">🏠 <span class="label">Home</span></a>
    <hr style="border-color: #555;">
    <?php } ?>

   <!-- ------------------------- template for show ----------------------------  -->
    <?php if (in_array($_SESSION['type'], ['Super Master'])) { ?>

    <?php } ?>

   <!-- ------------------------- template for not show ----------------------------  -->

    <?php if (!in_array($_SESSION['type'], ['Super Master'])) { ?>

    <?php } ?>




   <!-- ------------------------- demo / ongoing ----------------------------  -->

    <?php if (in_array($_SESSION['type'], ['Super Master'])) { ?>

    <a href="<?= BASE_URL ?>modules/event/event.php" class="<?= strpos($current_page, '/event/event.php') !== false ? 'active' : '' ?>" title = "Event">🎃 <span class="label">Event</span></a>
    <a href="<?= BASE_URL ?>modules/gift_settings/gift_settings.php" class="<?= strpos($current_page, '/gift_settings/gift_settings.php') !== false ? 'active' : '' ?>" title = "Gift Settings">☀️ <span class="label">Gift Settings</span></a>
    <?php } ?>
    
    <hr style="border-color: #555;">

   <!-- ------------------------- demo / ongoing ----------------------------  -->


    <?php if (in_array($_SESSION['type'], ['Super Master', 'Master', 'Inventory Admin'])) { ?>
        <a href="<?= BASE_URL ?>user.php" class="<?= strpos($current_page, '/user.php') !== false ? 'active' : '' ?>">👤 <span class="label">User</span></a>
    <?php } ?>


    <?php if (in_array($_SESSION['type'], ['Super Master', 'Master'])) { ?>
        <a href="<?= BASE_URL ?>category.php" class="<?= strpos($current_page, '/category.php') !== false ? 'active' : '' ?>">📂 <span class="label">Category</span></a>
        <a href="<?= BASE_URL ?>modules/brand/brand.php" class="<?= strpos($current_page, '/brand/brand.php') !== false ? 'active' : '' ?>">🏷 <span class="label">Brand</span></a>
        <a href="<?= BASE_URL ?>product.php" class="<?= strpos($current_page, '/product.php') !== false ? 'active' : '' ?>">📦 <span class="label">Product</span></a>
        <a href="<?= BASE_URL ?>customer.php" class="<?= strpos($current_page, '/customer.php') !== false ? 'active' : '' ?>">🧑 <span class="label">Customer</span></a>
    <?php } ?>


    <?php if (in_array($_SESSION['type'], ['Super Master', 'Master', 'Inventory Master', 'Inventory User'])) { ?>
        <a href="   <?= BASE_URL ?>user.php" class="<?= strpos($current_page, '/user.php') !== false ? 'active' : '' ?>">👤 <span class="label">User</span></a>
        <a href="<?= BASE_URL ?>order.php" class="<?= strpos($current_page, '/order.php') !== false ? 'active' : '' ?>">📝 <span class="label">Order</span></a>
        <a href="<?= BASE_URL ?>collection.php" class="<?= strpos($current_page, '/collection.php') !== false ? 'active' : '' ?>">💰 <span class="label">Collection</span></a>
        <a href="<?= BASE_URL ?>report.php" class="<?= strpos($current_page, '/report.php') !== false ? 'active' : '' ?>">📊 <span class="label">Report</span></a>
        <a href="<?= BASE_URL ?>customized_report.php" class="<?= strpos($current_page, '/customized_report.php') !== false ? 'active' : '' ?>">📋 <span class="label">Custom Report</span></a>
        <hr style="border-color: #555;">
    
    <?php } ?>


    <!-- ------------------ Gift ------------------------  -->

    <?php if (in_array($_SESSION['type'], ['Super Master', 'Master', 'Gift Admin'])) { ?>
        <a href="<?= BASE_URL ?>user.php" class="<?= strpos($current_page, '/user.php') !== false ? 'active' : '' ?>" title="User">👤 <span class="label">User</span></a>
    <?php } ?>    
    
    <?php if (in_array($_SESSION['type'], ['Super Master', 'Master', 'Gift Admin', 'Gift User'])) { ?>
        <a href="<?= BASE_URL ?>gift_dashboard.php" class="<?= strpos($current_page, '/gift_dashboard.php') !== false ? 'active' : '' ?>" title="Gift Dashboard">🏠 <span class="label">Gift Dash</span></a>
        <a href="<?= BASE_URL ?>modules/gift/gift.php" class="<?= strpos($current_page, '/gift/gift.php') !== false ? 'active' : '' ?>" title="Gift">🎁 <span class="label">Gift</span></a>                                               
        <a href="<?= BASE_URL ?>modules/withdraw/withdraw.php" class="<?= strpos($current_page, '/withdraw/withdraw.php') !== false ? 'active' : '' ?>" title="Withdraw">💸 <span class="label">Wtihdraw</span></a>
        <a href="<?= BASE_URL ?>modules/gift/gift_report.php" class="<?= strpos($current_page, '/gift/gift_report.php') !== false ? 'active' : '' ?>" title="Gift Report">📊 <span class="label">Report</span></a>

        <hr style="border-color: #555;">

    <?php } ?>


    <!-- ------------------------------------------  -->
    
    <?php if (in_array($_SESSION['type'], ['Super Master', 'Master'])) { ?>


        <a href="<?= BASE_URL ?>modules/version/version.php" class="<?= strpos($current_page, '/version/version.php') !== false ? 'active' : '' ?>">🔖 <span class="label">Version</span></a>

        <a href="<?= BASE_URL ?>modules/todo/todo.php" class="<?= strpos($current_page, '/todo/todo.php') !== false ? 'active' : '' ?>">📌 <span class="label">Todo</span></a>

        <a href="<?= BASE_URL ?>modules/bug/bug.php" class="<?= strpos($current_page, '/bug/bug.php') !== false ? 'active' : '' ?>">🐞 <span class="label">Bug</span></a>

    <?php } ?>

    <?php if (in_array($_SESSION['type'], ['Super Master', 'Master'])) { ?>

        <a href="#" onclick="toggleTheme()">🌓 <span class="label">Toggle Theme</span></a>
        <hr style="border-color: #555;">


    <?php } ?>



    <?php
    $role_emojis = [
        'Super Master'     => '🧠',
        'Master'           => '🧑‍💼',
        'Admin'            => '🛡️',
        'User'             => '👤',
        'Gift Admin'       => '🎁🛡️',
        'Gift User'        => '🎁👤',
        'Salesman'         => '💼',
        'Cashier'          => '💰',
        'Supervisor'       => '🧐',
        'Inventory Admin'  => '📦🛡️',
        'Inventory User'   => '📦👤'
    ];


    $emoji = $role_emojis[$_SESSION['user_type']] ?? '👤';
    ?>


    <a href="<?= BASE_URL ?>profile.php" 
    class="<?= strpos($current_page, '/profile.php') !== false ? 'active' : '' ?>" 
    title="<?= htmlspecialchars($_SESSION['user_type']) ?>">
        <?= $emoji ?> 
        <span class="label">
            <?= $_SESSION['user_name'] ?><br />
            <span style="display: block; text-align: center;">
                <?= $_SESSION['user_type'] ?>
            </span>
        </span>
    </a>



    <a href="#" data-toggle="modal" data-target="#logoutModal" title="Log Out">🚪 <span class="label">Logout</span></a>
</div>

<div class="content">
