<?php
// modules/init/init_withdraw_sql.php

include('../database_connection.php');

$connect->exec("
    CREATE TABLE IF NOT EXISTS withdraw (
        withdraw_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        withdrawer_id INT DEFAULT NULL,
        withdraw_type VARCHAR(100),
        withdraw_amount DECIMAL(10,2),
        withdraw_method VARCHAR(100),
        withdraw_date DATE,
        withdraw_note TEXT,
        status VARCHAR(20) DEFAULT 'active',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");
echo "Withdraw table has been successfully created.";
?>
