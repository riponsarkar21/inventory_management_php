<?php
// modules/brand/brand_fetch.php

ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

include(__DIR__ . '/../../database_connection.php');

$draw = intval($_POST["draw"] ?? 0);
$start = intval($_POST["start"] ?? 0);
$length = intval($_POST["length"] ?? -1);
$search = $_POST["search"]["value"] ?? '';
$order_column = $_POST['order'][0]['column'] ?? null;
$order_dir = $_POST['order'][0]['dir'] ?? 'DESC';

$columns = ['brand.brand_id', 'category.category_name', 'brand.brand_name', 'brand.brand_status'];
$order_by = $columns[$order_column] ?? 'brand.brand_id';

// Base query
$query = "
    SELECT brand.*, category.category_name 
    FROM brand 
    INNER JOIN category ON category.category_id = brand.category_id
";

// Build WHERE clause for search
$conditions = [];
$params = [];

if (!empty($search)) {
    $conditions[] = "(brand.brand_name LIKE :search OR category.category_name LIKE :search OR brand.brand_status LIKE :search)";
    $params[':search'] = '%' . $search . '%';
}

if ($conditions) {
    $query .= ' WHERE ' . implode(' AND ', $conditions);
}

// Add ORDER BY and LIMIT for pagination
$query .= " ORDER BY $order_by $order_dir";
if ($length != -1) {
    $query .= " LIMIT :start, :length";
}

// Prepare statement with parameters
$statement = $connect->prepare($query);
foreach ($params as $key => $val) {
    $statement->bindValue($key, $val, PDO::PARAM_STR);
}
if ($length != -1) {
    $statement->bindValue(':start', $start, PDO::PARAM_INT);
    $statement->bindValue(':length', $length, PDO::PARAM_INT);
}

$statement->execute();
$result = $statement->fetchAll();

// ✅ Correct filtered count
$count_query = "
    SELECT COUNT(*) 
    FROM brand 
    INNER JOIN category ON category.category_id = brand.category_id
";
if ($conditions) {
    $count_query .= ' WHERE ' . implode(' AND ', $conditions);
}
$count_stmt = $connect->prepare($count_query);
foreach ($params as $key => $val) {
    $count_stmt->bindValue($key, $val, PDO::PARAM_STR);
}
$count_stmt->execute();
$filtered_rows = $count_stmt->fetchColumn();

// ✅ Total records without filter
function get_total_all_records($connect) {
    $stmt = $connect->prepare("
        SELECT COUNT(*) 
        FROM brand 
        INNER JOIN category ON category.category_id = brand.category_id
    ");
    $stmt->execute();
    return $stmt->fetchColumn();
}

// Prepare data for DataTables
$data = [];
foreach ($result as $row) {
    $status_label = $row['brand_status'] === 'active'
        ? '<span class="label label-success">Active</span>'
        : '<span class="label label-danger">Inactive</span>';

    $data[] = [
        $row['brand_id'],
        $row['category_name'],
        $row['brand_name'],
        $status_label,
        '<button type="button" name="update" id="' . $row["brand_id"] . '" class="btn btn-warning btn-xs update">Update</button>',
        '<button type="button" name="status" id="' . $row["brand_id"] . '" class="btn btn-primary btn-xs status" data-status="' . $row["brand_status"] . '">Change status</button>',
        '<button type="button" name="delete" id="' . $row["brand_id"] . '" class="btn btn-danger btn-xs delete" data-status="' . $row["brand_name"] . '">Delete</button>',
    ];
}

// Output JSON
echo json_encode([
    "draw" => $draw,
    "recordsTotal" => get_total_all_records($connect),
    "recordsFiltered" => $filtered_rows,
    "data" => $data
]);
