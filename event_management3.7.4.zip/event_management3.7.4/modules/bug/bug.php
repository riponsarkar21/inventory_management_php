<?php
// modules/bug/bug.php

include('../../database_connection.php');
include('../../header.php');

if (!isset($_SESSION['user_name'])) {
    header("location:/module/login.php");
    exit();
}

// Create bug table if not exists
$create_sql = "
CREATE TABLE IF NOT EXISTS bug (
    bug_id INT AUTO_INCREMENT PRIMARY KEY,
    bug_title VARCHAR(255),
    bug_description TEXT,
    screenshot_image VARCHAR(255),
    status ENUM('Open', 'Solved', 'Cancelled') DEFAULT 'Open',
    created_by VARCHAR(100),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    solved_by VARCHAR(100),
    solved_at DATETIME
)";
$connect->exec($create_sql);
?>

<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
<link rel="stylesheet" href="<?= BASE_URL ?>css/datepicker.css">

<span id="alert_action"></span>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading clearfix">
                <div class="pull-left">
                    <h3 class="panel-title">QC Bug Tracking List</h3>
                </div>
                <div class="pull-right">
                    <button type="button" id="add_button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#bugModal">Add Bug</button>
                </div>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table id="bug_data" class="table table-bordered table-striped w-100">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Screenshot</th>
                                <th>Status</th>
                                <th>Created By</th>
                                <th>Created At</th>
                                <th>Solved By</th>
                                <th>Solved At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="bugModal" class="modal fade">
    <div class="modal-dialog">
        <form method="post" id="bug_form" enctype="multipart/form-data">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add Bug</h4>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="bug_id" id="bug_id">
                    <div class="form-group">
                        <label>Bug Title</label>
                        <input type="text" name="bug_title" id="bug_title" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="bug_description" id="bug_description" class="form-control" required></textarea>
                    </div>
                    <div class="form-group">
                        <label>Screenshot</label>
                        <input type="file" name="screenshot_image" class="form-control">
                    </div>
                    <input type="hidden" name="created_by" value="<?php echo $_SESSION['user_name']; ?>">
                </div>
                <div class="modal-footer">
                    <input type="submit" name="action" id="action" class="btn btn-info" value="Add" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap.min.js"></script>
<script src="<?= BASE_URL ?>modules/bug/bug.js?ver=<?php echo time(); ?>"></script>

<?php include('../../footer.php'); ?>
