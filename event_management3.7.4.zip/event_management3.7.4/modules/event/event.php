<?php
// event.php
include('../../database_connection.php');
include('../../header.php');
?>

<!-- DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">

<span id="alert_action"></span>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading clearfix">
                <div class="pull-left"><h3 class="panel-title">Event Management</h3></div>
                <div class="pull-right">
                    <button type="button" id="add_button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#eventModal">Add Event</button>
                </div>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table id="event_data" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Location</th>
                                <th>Date</th>
                                <th>Host</th>
                                <th>Contact</th>
                                <th>Participants</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Update</th>
                                <th>Change Status</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="eventModal" class="modal fade">
    <div class="modal-dialog modal-lg">
        <form method="post" id="event_form">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add Event</h4>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" id="event_id">
                    <div class="form-group"><label>Title</label><input type="text" name="event_title" id="event_title" class="form-control" required></div>
                    <div class="form-group"><label>Location</label><input type="text" name="event_location" id="event_location" class="form-control" required></div>
                    <div class="form-group"><label>Date</label><input type="date" name="event_date" id="event_date" class="form-control" required></div>
                    <div class="form-group"><label>Host</label><input type="text" name="event_host" id="event_host" class="form-control"></div>
                    <div class="form-group"><label>Host Contact</label><input type="text" name="event_host_contact" id="event_host_contact" class="form-control"></div>
                    <div class="form-group"><label>Participants</label><input type="number" name="event_participant_number" id="event_participant_number" class="form-control"></div>
                    <div class="form-group"><label>Deal Amount</label><input type="number" step="0.01" name="event_deal_amount" id="event_deal_amount" class="form-control"></div>
                    <div class="form-group"><label>Contract Details</label><textarea name="event_deal_contract_details" id="event_deal_contract_details" class="form-control"></textarea></div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="action" id="action" value="Add" />
                    <input type="submit" class="btn btn-info" value="Save" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="event_ajax.js"></script>

<?php include('../../footer.php'); ?>