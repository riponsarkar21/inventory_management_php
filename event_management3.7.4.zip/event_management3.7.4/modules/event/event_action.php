<?php
include('../../database_connection.php');

$response = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {

    if ($_POST['action'] == 'Add') {
        $query = "
            INSERT INTO event (
                event_title, event_location, event_date, event_host, 
                event_host_contact, event_participant_number, 
                event_deal_amount, event_deal_contract_details
            ) VALUES (
                :event_title, :event_location, :event_date, :event_host, 
                :event_host_contact, :event_participant_number, 
                :event_deal_amount, :event_deal_contract_details
            )
        ";

        $statement = $connect->prepare($query);
        $result = $statement->execute([
            ':event_title' => $_POST['event_title'],
            ':event_location' => $_POST['event_location'],
            ':event_date' => $_POST['event_date'],
            ':event_host' => $_POST['event_host'],
            ':event_host_contact' => $_POST['event_host_contact'],
            ':event_participant_number' => $_POST['event_participant_number'],
            ':event_deal_amount' => $_POST['event_deal_amount'],
            ':event_deal_contract_details' => $_POST['event_deal_contract_details']
        ]);

        $response['message'] = $result ? '<div class="alert alert-success">Event added.</div>' 
                                       : '<div class="alert alert-danger">Failed to add event.</div>';
        echo json_encode($response);
        exit;
    }

    if ($_POST['action'] == 'Update') {
        $query = "UPDATE event SET 
            event_title = :event_title,
            event_location = :event_location,
            event_date = :event_date,
            event_host = :event_host,
            event_host_contact = :event_host_contact,
            event_participant_number = :event_participant_number,
            event_deal_amount = :event_deal_amount,
            event_deal_contract_details = :event_deal_contract_details
            WHERE id = :id";

        $stmt = $connect->prepare($query);
        $stmt->execute([
            ':event_title' => $_POST['event_title'],
            ':event_location' => $_POST['event_location'],
            ':event_date' => $_POST['event_date'],
            ':event_host' => $_POST['event_host'],
            ':event_host_contact' => $_POST['event_host_contact'],
            ':event_participant_number' => $_POST['event_participant_number'],
            ':event_deal_amount' => $_POST['event_deal_amount'],
            ':event_deal_contract_details' => $_POST['event_deal_contract_details'],
            ':id' => $_POST['id']
        ]);

        echo json_encode(['message' => 'Event updated successfully.']);
        exit;
    }

    if ($_POST['action'] == 'fetch_single') {
        $stmt = $connect->prepare("SELECT * FROM event WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        echo json_encode($stmt->fetch(PDO::FETCH_ASSOC));
        exit;
    }

    if ($_POST['action'] == 'delete') {
        $stmt = $connect->prepare("DELETE FROM event WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        echo json_encode(['message' => 'Event deleted.']);
        exit;
    }

    if ($_POST['action'] == 'change_status') {
        $stmt = $connect->prepare("SELECT status FROM event WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $row = $stmt->fetch();
        $new_status = ($row['status'] == 'Active') ? 'Inactive' : 'Active';

        $update = $connect->prepare("UPDATE event SET status = ? WHERE id = ?");
        $update->execute([$new_status, $_POST['id']]);

        echo json_encode(['message' => "Status changed to $new_status."]);
        exit;
    }

} else {
    echo json_encode(['message' => 'Invalid request.']);
    exit;
}
