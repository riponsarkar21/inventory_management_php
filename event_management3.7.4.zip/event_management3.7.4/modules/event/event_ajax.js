$(document).ready(function () {
    const table = $('#event_data').DataTable({
        ajax: "event_fetch.php",
        order: [[0, "desc"]],
        columns: [
            { data: "id" },
            { data: "event_title" },
            { data: "event_location" },
            { data: "event_date" },
            { data: "event_host" },
            { data: "event_host_contact" },
            { data: "event_participant_number" },
            { data: "event_deal_amount" },
            {
                data: "status",
                render: function (data) {
                    let label = 'label-default';
                    if (data === 'Active') label = 'label-success';
                    else if (data === 'Inactive') label = 'label-warning';
                    else if (data === 'Cancelled') label = 'label-danger';
                    return `<span class="label ${label}">${data}</span>`;
                }
            },
            {
                data: null,
                render: row => `<button class="btn btn-primary btn-xs update" data-id="${row.id}">Update</button>`
            },
            {
                data: null,
                render: row => `<button class="btn btn-info btn-xs change-status" data-id="${row.id}">Change</button>`
            },
            {
                data: null,
                render: row => `<button class="btn btn-danger btn-xs delete" data-id="${row.id}">Delete</button>`
            }
        ]
    });

    $('#event_form').on('submit', function (e) {
        e.preventDefault();
        const formData = $(this).serialize();
        $.ajax({
            url: 'event_action.php',
            method: 'POST',
            data: formData,
            success: function (data) {
                $('#event_form')[0].reset();
                $('#eventModal').modal('hide');
                $('#alert_action').html(`<div class="alert alert-success">${data}</div>`);
                table.ajax.reload();
            }
        });
    });

    $(document).on('click', '.update', function () {
        const id = $(this).data('id');
        $.post('event_action.php', { action: 'fetch_single', id }, function (data) {
            const event = JSON.parse(data);
            $('#event_id').val(event.id);
            $('#event_title').val(event.event_title);
            $('#event_location').val(event.event_location);
            $('#event_date').val(event.event_date);
            $('#event_host').val(event.event_host);
            $('#event_host_contact').val(event.event_host_contact);
            $('#event_participant_number').val(event.event_participant_number);
            $('#event_deal_amount').val(event.event_deal_amount);
            $('#event_deal_contract_details').val(event.event_deal_contract_details);
            $('#action').val('Update');
            $('#eventModal').modal('show');
        });
    });

    $(document).on('click', '.change-status', function () {
        const id = $(this).data('id');
        $.post('event_action.php', { action: 'change_status', id }, function (data) {
            $('#alert_action').html(`<div class="alert alert-info">${data}</div>`);
            table.ajax.reload();
        });
    });

    $(document).on('click', '.delete', function () {
        if (confirm('Delete this event?')) {
            const id = $(this).data('id');
            $.post('event_action.php', { action: 'delete', id }, function (data) {
                $('#alert_action').html(`<div class="alert alert-danger">${data}</div>`);
                table.ajax.reload();
            });
        }
    });
});
