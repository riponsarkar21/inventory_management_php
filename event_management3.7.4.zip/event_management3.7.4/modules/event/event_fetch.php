<?php
include('../../database_connection.php');

$query = "SELECT * FROM event ORDER BY id DESC";
$statement = $connect->prepare($query);
$statement->execute();
$result = $statement->fetchAll();

$data = [];
foreach ($result as $row) {
    $data[] = [
        'id' => $row['id'],
        'event_title' => $row['event_title'],
        'event_location' => $row['event_location'],
        'event_date' => $row['event_date'],
        'event_host' => $row['event_host'],
        'event_host_contact' => $row['event_host_contact'],
        'event_participant_number' => $row['event_participant_number'],
        'event_deal_amount' => $row['event_deal_amount'],
        'event_deal_contract_details' => $row['event_deal_contract_details'],
        'status' => $row['status']
    ];
}

echo json_encode([ "data" => $data ]);
