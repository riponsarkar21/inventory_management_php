<?php
// init_event.php
// Run this script once to initialize the `event` table

include('../../database_connection.php');

$query = "
CREATE TABLE IF NOT EXISTS event (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_title VARCHAR(255) NOT NULL,
    event_location VARCHAR(255) NOT NULL,
    event_date DATE NOT NULL,
    event_host VARCHAR(255),
    event_host_contact VARCHAR(100),
    event_participant_number INT DEFAULT 0,
    event_deal_amount DECIMAL(12,2) DEFAULT 0.00,
    event_deal_contract_details TEXT,
    status ENUM('Active', 'Inactive', 'Cancelled') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

if ($connect->query($query)) {
    echo "✅ 'event' table created successfully.";
} else {
    echo "❌ Error creating table: " . $connect->errorInfo()[2];
}
?>
