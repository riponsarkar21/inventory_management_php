<?php
require_once 'lib/phpqrcode/qrlib.php';

// The content you want in the QR code
$data = "http://riponsarkartest1-001-site1.anytempurl.com/modules/gift/gift_ticket_pdf.php?id=22";

// Output QR code directly to browser
QRcode::png($data);
?>
