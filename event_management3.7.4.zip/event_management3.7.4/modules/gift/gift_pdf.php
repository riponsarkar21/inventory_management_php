<?php
// modules/gift/gift_pdf.php

include(__DIR__ . '/../../database_connection.php');
require_once __DIR__ . '/../../pdf.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die('Invalid ID');
}

$id = intval($_GET['id']);
$stmt = $connect->prepare("SELECT * FROM gift WHERE gift_id = ?");
$stmt->execute([$id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    die('No gift entry found');
}

$html = '
<style>
    body { font-family: DejaVu Sans, sans-serif; }
    h2 { text-align: center; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th, td { padding: 8px; border: 1px solid #000; }
    .cancelled { color: red; font-size: 20px; text-align: center; }
</style>

<h2>Gift / Cash Received Report</h2>';

if (strtolower($row['status']) === 'cancelled') {
    $html .= '<div class="cancelled">❌ This Entry is Cancelled</div>';
}

$html .= '<table>
    <tr><th>Guest Name</th><td>' . htmlspecialchars($row['guest_name']) . '</td></tr>
    <tr><th>Phone</th><td>' . htmlspecialchars($row['phone']) . '</td></tr>
    <tr><th>Address</th><td>' . htmlspecialchars($row['address']) . '</td></tr>
    <tr><th>Relation</th><td>' . htmlspecialchars($row['relation']) . '</td></tr>
    <tr><th>Type</th><td>' . htmlspecialchars($row['gift_type']) . '</td></tr>
    <tr><th>Amount</th><td>' . htmlspecialchars($row['amount']) . '</td></tr>
    <tr><th>Payment Method</th><td>' . htmlspecialchars($row['payment_method']) . '</td></tr>
    <tr><th>Gift Details</th><td>' . htmlspecialchars($row['gift_details']) . '</td></tr>
    <tr><th>Status</th><td>' . htmlspecialchars($row['status']) . '</td></tr>';

$imageFile = __DIR__ . '/../../' . $row['gift_image'];
if (!empty($row['gift_image']) && file_exists($imageFile)) {
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_file($finfo, $imageFile);
    finfo_close($finfo);

    $base64 = base64_encode(file_get_contents($imageFile));
    $src    = 'data:' . $mime . ';base64,' . $base64;

    $html .= '<tr><th>Gift Image</th><td><img src="' . $src . '" width="200" style="border:1px solid #000;"></td></tr>';
}

$html .= '</table>';

$pdf = new Pdf();
$pdf->loadHtml($html);
$pdf->setPaper('A4', 'portrait');
$pdf->render();
$pdf->stream("gift_entry_{$id}.pdf", ["Attachment" => false]);
exit;