<?php
// gift_report.php/ 
// 27.07.2025 v1: 
// the image thumb show every row


include('../../database_connection.php');
include('../../header.php');
?>

<!-- DataTables CSS & Export Buttons -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">

<div class="container-fluid mt-4">
    <h3 class="mb-3">Gift Report</h3>

    <!-- Filter Panel -->
    <div class="row mb-3">
        <div class="col-md-2">
            <input type="date" id="from_date" class="form-control" placeholder="From Date">
        </div>
        <div class="col-md-2">
            <input type="date" id="to_date" class="form-control" placeholder="To Date">
        </div>
        <div class="col-md-2">
            <select id="gift_type" class="form-control">
                <option value="">All Types</option>
                <option value="money">Money</option>
                <option value="gift">Gift</option>
                <option value="both">Both</option>
            </select>
        </div>
        <div class="col-md-2">
            <select id="status" class="form-control">
                <option value="">All Status</option>
                <option value="received">Received</option>
                <option value="pending">Pending</option>
                <option value="cancelled">Cancelled</option>
            </select>
        </div>
        <div class="col-md-3">
            <input type="text" id="search_text" class="form-control" placeholder="Guest Name or Phone">
        </div>
        <div class="col-md-1">
            <button class="btn btn-primary w-100" id="filter_btn">Filter</button>
        </div>
    </div>

    <!-- Table -->
    <div class="panel-body">
        <div class="table-responsive">
            <table id="gift_report_table" class="table table-bordered table-striped">
                <thead>
            <tr>
                <th>ID</th>
                <th>Guest</th>
                <th>Phone</th>
                <th>Relation</th>
                <th>Gift Type</th>
                <th>Amount</th>
                <th>Gift Details</th>
                <th>Image</th>
                <th>Status</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
                </thead>
            </table>
        </div>
    </div>



</div>

<!-- DataTables JS -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>

<script>
$(document).ready(function() {
    function load_data(from_date = '', to_date = '', gift_type = '', status = '', search_text = '') {
        $('#gift_report_table').DataTable({
            destroy: true,
            processing: true,
            serverSide: true,
            order: [[0, "desc"]],
            ajax: {
                url: "gift_report_fetch.php",
                type: "POST",
                data: {
                    from_date: from_date,
                    to_date: to_date,
                    gift_type: gift_type,
                    status: status,
                    search_text: search_text
                }
            },
            dom: 'Bfrtip',
            buttons: ['copy', 'excel', 'pdf', 'print'],
            columns: [
                { data: "gift_id" },
                { data: "guest_name" },
                { data: "phone" },
                { data: "relation" },
                { data: "gift_type" },
                { data: "amount" },
                { data: "gift_details" },


                {
                    data: "gift_image",
                    render: function(data) {
                        return `<img src="../../${data}" width="50" class="img-thumbnail" />`;
                    }
                },


                { data: "status" },
                { data: "created_at" },
                {
                    data: "gift_id",
                    render: function(id) {
                        return `
                            <a href="gift_ticket_pdf.php?id=${id}" class="btn btn-sm btn-secondary">PDF</a>
                            <a href="gift_view.php?id=${id}" class="btn btn-sm btn-info">View</a>
                            <a href="gift_edit.php?id=${id}" class="btn btn-sm btn-warning">Edit</a>
                        `;
                    }
                }
            ]
        });
    }

    load_data();

    $('#filter_btn').on('click', function() {
        const from = $('#from_date').val();
        const to = $('#to_date').val();
        const type = $('#gift_type').val();
        const status = $('#status').val();
        const search = $('#search_text').val();
        load_data(from, to, type, status, search);
    });
});
</script>
