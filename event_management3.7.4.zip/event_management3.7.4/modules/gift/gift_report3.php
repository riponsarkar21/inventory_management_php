<?php

// gift_report.php/ 
// 27.07.2025 v3: 
// the image thumb show every row
// image show only available with a goodlooking border
// use checkbox to show columns




include('../../database_connection.php');
include('../../header.php');
?>

<!-- DataTables CSS & Export Buttons -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">

<div class="container-fluid mt-4">
    <h3 class="mb-3">Gift Report</h3>

    <!-- Filter Panel -->
    <div class="row mb-3">
        <div class="col-md-2">
            <input type="date" id="from_date" class="form-control" placeholder="From Date">
        </div>
        <div class="col-md-2">
            <input type="date" id="to_date" class="form-control" placeholder="To Date">
        </div>
        <div class="col-md-2">
            <select id="gift_type" class="form-control">
                <option value="">All Types</option>
                <option value="money">Money</option>
                <option value="gift">Gift</option>
                <option value="both">Both</option>
            </select>
        </div>
        <div class="col-md-2">
            <select id="status" class="form-control">
                <option value="">All Status</option>
                <option value="received">Received</option>
                <option value="pending">Pending</option>
                <option value="cancelled">Cancelled</option>
            </select>
        </div>
        <div class="col-md-3">
            <input type="text" id="search_text" class="form-control" placeholder="Guest Name or Phone">
        </div>
        <div class="col-md-1">
            <button class="btn btn-primary w-100" id="filter_btn">Filter</button>
        </div>
    </div>

    <!-- table column selection  -->
    <div class="mb-3">
        <label class="me-3"><strong>Select Columns to Show:</strong></label>

        <label class="me-2"><input type="checkbox" class="col-toggle" data-column="1" checked> Guest</label>
        <label class="me-2"><input type="checkbox" class="col-toggle" data-column="2" checked> Phone</label>
        <label class="me-2"><input type="checkbox" class="col-toggle" data-column="3" checked> Relation</label>
        <label class="me-2"><input type="checkbox" class="col-toggle" data-column="4" checked> Gift Type</label>
        <label class="me-2"><input type="checkbox" class="col-toggle" data-column="5" checked> Amount</label>
        <label class="me-2"><input type="checkbox" class="col-toggle" data-column="6" checked> Gift Details</label>
        <label class="me-2"><input type="checkbox" class="col-toggle" data-column="7" checked> Image</label>
        <label class="me-2"><input type="checkbox" class="col-toggle" data-column="8" checked> Status</label>
        <label class="me-2"><input type="checkbox" class="col-toggle" data-column="9" checked> Created At</label>
        <!-- Don't add checkbox for column 10 (Actions) – always visible -->
    </div>


    <!-- Table -->
    <div class="panel-body">
        <div class="table-responsive">
            <table id="gift_report_table" class="table table-bordered table-striped">
                <thead>
            <tr>
                <th>ID</th>
                <th>Guest</th>
                <th>Phone</th>
                <th>Relation</th>
                <th>Gift Type</th>
                <th>Amount</th>
                <th>Gift Details</th>
                <th>Image</th>
                <th>Status</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
                </thead>
            </table>
        </div>
    </div>



</div>




<!-- DataTables JS -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>

<script>
$(document).ready(function() {
    function load_data(from_date = '', to_date = '', gift_type = '', status = '', search_text = '') {
        $('#gift_report_table').DataTable({
            destroy: true,
            processing: true,
            serverSide: true,
            order: [[0, "desc"]],
            ajax: {
                url: "gift_report_fetch.php",
                type: "POST",
                data: {
                    from_date: from_date,
                    to_date: to_date,
                    gift_type: gift_type,
                    status: status,
                    search_text: search_text
                }
            },
            dom: 'Bfrtip',
            buttons: ['copy', 'excel', 'pdf', 'print'],
            columns: [
                { data: "gift_id" },
                { data: "guest_name" },
                { data: "phone" },
                { data: "relation" },
                { data: "gift_type" },
                { data: "amount" },
                { data: "gift_details" },


                {
                    data: "gift_image",
                    render: function(data) {
                        return data
                        ?`<img src="../../${data}" width="40" class="img-thumbnail" />` 
                        : '';
                    }
                },


                { data: "status" },
                { data: "created_at" },
                {
                    data: "gift_id",
                    render: function(id) {
                        return `
                            <a href="gift_ticket_pdf.php?id=${id}" class="btn btn-sm btn-secondary">PDF</a>
                            <a href="gift_view.php?id=${id}" class="btn btn-sm btn-info">View</a>
                            <a href="gift_edit.php?id=${id}" class="btn btn-sm btn-warning">Edit</a>
                        `;
                    }
                }
            ]
        });
    }

    // Column Toggle Handler
    $(document).on('change', '.col-toggle', function () {
        const column = $('#gift_report_table').DataTable().column($(this).data('column'));
        column.visible(this.checked);
    });


    load_data();

    $('#filter_btn').on('click', function() {
        const from = $('#from_date').val();
        const to = $('#to_date').val();
        const type = $('#gift_type').val();
        const status = $('#status').val();
        const search = $('#search_text').val();
        load_data(from, to, type, status, search);
    });
});
</script>
