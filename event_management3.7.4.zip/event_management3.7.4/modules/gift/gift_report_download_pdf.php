<?php
// 28.07.2025 v1
// only download the pdf file 
?>


<?php
// Use your existing working Dompdf autoloader
require_once __DIR__ . '/../../dompdf/vendor/autoload.php';
require_once __DIR__ . '/../../database_connection.php';

use Dompdf\Dompdf;
use Dompdf\Options;

// Fetch data
$query = "SELECT * FROM gift ORDER BY gift_id DESC";
$statement = $connect->prepare($query);
$statement->execute();
$data = $statement->fetchAll(PDO::FETCH_ASSOC);

// Create HTML content
$html = '
<style>
    body { font-family: DejaVu Sans, sans-serif; font-size: 12px; }
    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    th, td { border: 1px solid #000; padding: 4px; text-align: left; }
    th { background-color: #f2f2f2; }
</style>
<h2 style="text-align: center;">Gift Report</h2>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Guest Name</th>
            <th>Phone</th>
            <th>Address</th>
            <th>Relation</th>
            <th>Type</th>
            <th>Amount</th>
            <th>Payment Method</th>
            <th>Gift Details</th>
            <th>Status</th>
            <th>Created At</th>
        </tr>
    </thead>
    <tbody>';

foreach ($data as $item) {
    $html .= '<tr>
        <td>' . $item['gift_id'] . '</td>
        <td>' . htmlspecialchars($item['guest_name']) . '</td>
        <td>' . htmlspecialchars($item['phone']) . '</td>
        <td>' . htmlspecialchars($item['address']) . '</td>
        <td>' . htmlspecialchars($item['relation']) . '</td>
        <td>' . htmlspecialchars($item['gift_type']) . '</td>
        <td>' . htmlspecialchars($item['amount']) . '</td>
        <td>' . htmlspecialchars($item['payment_method']) . '</td>
        <td>' . htmlspecialchars($item['gift_details']) . '</td>
        <td>' . htmlspecialchars($item['status']) . '</td>
        <td>' . htmlspecialchars($item['created_at']) . '</td>
    </tr>';
}

$html .= '</tbody></table>';

// Generate PDF
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true);

$dompdf = new Dompdf($options);
$dompdf->loadHtml($html, 'UTF-8');
$dompdf->setPaper('A4', 'landscape');
$dompdf->render();

// Output PDF
$filename = 'gift_report_' . date('Ymd_His') . '.pdf';
$dompdf->stream($filename, ['Attachment' => true]);
exit;
