<?php
// 28.07.2025 v1
// only download excel file 

// Make sure this is the VERY FIRST line
require '../../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Your database connection
require '../../database_connection.php';

// Fetch data
$query = "SELECT * FROM gift ORDER BY gift_id DESC";
$statement = $connect->prepare($query);
$statement->execute();
$data = $statement->fetchAll(PDO::FETCH_ASSOC);

// Create Spreadsheet
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Add headings
$sheet->fromArray([
    'ID', 'Guest Name', 'Phone', 'Address', 'Relation', 'Type', 'Amount', 
    'Payment Method', 'Gift Details', 'Status', 'Created At'
], NULL, 'A1');

// Add rows
$row = 2;
foreach ($data as $item) {
    $sheet->fromArray([
        $item['gift_id'],
        $item['guest_name'],
        $item['phone'],
        $item['address'],
        $item['relation'],
        $item['gift_type'],
        $item['amount'],
        $item['payment_method'],
        $item['gift_details'],
        $item['status'],
        $item['created_at'],
    ], NULL, 'A' . $row);
    $row++;
}

// Download as Excel
$filename = 'gift_report_' . date('Ymd_His') . '.xlsx';
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header("Content-Disposition: attachment; filename=\"$filename\"");

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
?>
