<?php
include('../../database_connection.php'); // make sure this contains your PDO $connect

header('Content-Type: application/json');

// DataTables parameters
$draw = isset($_POST['draw']) ? intval($_POST['draw']) : 0;
$start = isset($_POST['start']) ? intval($_POST['start']) : 0;
$length = isset($_POST['length']) ? intval($_POST['length']) : 10;

$columnIndex = $_POST['order'][0]['column'];
$columnName = $_POST['columns'][$columnIndex]['data'];
$columnSortOrder = $_POST['order'][0]['dir'];

$searchValue = $_POST['search']['value'] ?? '';

// Filters
$from_date = $_POST['from_date'] ?? '';
$to_date = $_POST['to_date'] ?? '';
$gift_type = $_POST['gift_type'] ?? '';
$status = $_POST['status'] ?? '';
$search_text = $_POST['search_text'] ?? '';

// Build the WHERE clause
$where = ' WHERE 1=1 ';
$params = [];

if (!empty($from_date) && !empty($to_date)) {
    $where .= " AND DATE(created_at) BETWEEN :from_date AND :to_date";
    $params[':from_date'] = $from_date;
    $params[':to_date'] = $to_date;
}

if (!empty($gift_type)) {
    $where .= " AND gift_type = :gift_type";
    $params[':gift_type'] = $gift_type;
}

if (!empty($status)) {
    $where .= " AND status = :status";
    $params[':status'] = $status;
}

if (!empty($search_text)) {
    $where .= " AND (guest_name LIKE :search_text OR phone LIKE :search_text)";
    $params[':search_text'] = '%' . $search_text . '%';
}

// Count total records
$stmt = $connect->prepare("SELECT COUNT(*) FROM gift");
$stmt->execute();
$totalRecords = $stmt->fetchColumn();

// Count filtered records
$stmt = $connect->prepare("SELECT COUNT(*) FROM gift $where");
$stmt->execute($params);
$totalFiltered = $stmt->fetchColumn();

// Fetch actual data
$sql = "SELECT * FROM gift $where ORDER BY $columnName $columnSortOrder LIMIT :start, :length";
$stmt = $connect->prepare($sql);

// Bind values
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->bindValue(':start', (int)$start, PDO::PARAM_INT);
$stmt->bindValue(':length', (int)$length, PDO::PARAM_INT);

$stmt->execute();
$data = [];

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $data[] = [
        'gift_id' => $row['gift_id'],
        'guest_name' => htmlspecialchars($row['guest_name']),
        'phone' => htmlspecialchars($row['phone']),
        'relation' => htmlspecialchars($row['relation']),
        'gift_type' => ucfirst($row['gift_type']),
        'amount' => $row['amount'],
        'payment_method' => $row['payment_method'],
        'gift_details' => htmlspecialchars($row['gift_details']),
        'gift_image' => $row['gift_image'],
        'created_at' => date("d-M-Y h:i A", strtotime($row['created_at'])),
        'status' => ucfirst($row['status'])
    ];
}

// Output JSON
echo json_encode([
    "draw" => $draw,
    "iTotalRecords" => $totalRecords,
    "iTotalDisplayRecords" => $totalFiltered,
    "aaData" => $data
]);
