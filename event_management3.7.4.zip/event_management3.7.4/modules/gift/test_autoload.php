<?php
require 'C:/xampp/htdocs/test3/event_management3.7.3/vendor/autoload.php';

echo "Autoload works!";
