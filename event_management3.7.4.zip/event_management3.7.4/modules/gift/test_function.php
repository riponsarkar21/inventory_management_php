<?php
// gift_function.php


function convertToWords($number) {
    $hyphen = '-';
    $conjunction = ' and ';
    $separator = ', ';
    $negative = 'Negative ';
    $decimal = ' point ';
    $dictionary = [
        0 => 'Zero', 1 => 'One', 2 => 'Two', 3 => 'Three', 4 => 'Four',
        5 => 'Five', 6 => 'Six', 7 => 'Seven', 8 => 'Eight', 9 => 'Nine',
        10 => 'Ten', 11 => 'Eleven', 12 => 'Twelve', 13 => 'Thirteen',
        14 => 'Fourteen', 15 => 'Fifteen', 16 => 'Sixteen', 17 => 'Seventeen',
        18 => 'Eighteen', 19 => 'Nineteen', 20 => 'Twenty', 30 => 'Thirty',
        40 => 'Forty', 50 => 'Fifty', 60 => 'Sixty', 70 => 'Seventy',
        80 => 'Eighty', 90 => 'Ninety',
        100 => 'Hundred', 1000 => 'Thousand', 100000 => 'Lakh', 10000000 => 'Crore'
    ];

    if (!is_numeric($number)) {
        return false;
    }

    if ($number < 0) {
        return $negative . convertToWords(abs($number));
    }

    $string = '';

    if (strpos($number, '.') !== false) {
        [$taka, $paisa] = explode('.', $number);
        $taka = (int) $taka;
        $paisa = (int) str_pad($paisa, 2, '0', STR_PAD_RIGHT);
    } else {
        $taka = (int) $number;
        $paisa = 0;
    }

    $string .= numberToWords($taka, $dictionary) . ' Taka';

    if ($paisa > 0) {
        $string .= $conjunction . numberToWords($paisa, $dictionary) . ' Paisa';
    }

    return $string . ' Only';
}

function numberToWords($number, $dictionary) {
    if ($number < 21) {
        return $dictionary[$number];
    } elseif ($number < 100) {
        $tens = ((int) ($number / 10)) * 10;
        $units = $number % 10;
        return $dictionary[$tens] . ($units ? '-' . $dictionary[$units] : '');
    } elseif ($number < 1000) {
        $hundreds = (int) ($number / 100);
        $remainder = $number % 100;
        return $dictionary[$hundreds] . ' ' . $dictionary[100] . ($remainder ? ' and ' . numberToWords($remainder, $dictionary) : '');
    } elseif ($number < 100000) {
        $thousands = (int) ($number / 1000);
        $remainder = $number % 1000;
        return numberToWords($thousands, $dictionary) . ' ' . $dictionary[1000] . ($remainder ? ' ' . numberToWords($remainder, $dictionary) : '');
    } elseif ($number < 10000000) {
        $lakhs = (int) ($number / 100000);
        $remainder = $number % 100000;
        return numberToWords($lakhs, $dictionary) . ' ' . $dictionary[100000] . ($remainder ? ' ' . numberToWords($remainder, $dictionary) : '');
    } else {
        $crores = (int) ($number / 10000000);
        $remainder = $number % 10000000;
        return numberToWords($crores, $dictionary) . ' ' . $dictionary[10000000] . ($remainder ? ' ' . numberToWords($remainder, $dictionary) : '');
    }
}


?>