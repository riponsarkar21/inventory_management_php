<?php
// modules/version/version_action.php

include('../../database_connection.php');
session_start();

if (isset($_POST['btn_action'])) {

    if ($_POST['btn_action'] == 'Add') {

        $release_date = $_POST['release_date'];
        $features = $_POST['features'];
        $changelog = $_POST['changelog'];
        $created_by = $_SESSION['user_name'] ?? 'Public';

        // Auto-generate version number (e.g., v1.0.0, v1.0.1, etc.)
        $stmt = $connect->prepare("SELECT MAX(version_id) AS max_id FROM version");
        $stmt->execute();
        $max_id = $stmt->fetch(PDO::FETCH_ASSOC)['max_id'] ?? 0;
        $new_version_number = 'v1.0.' . ($max_id + 1);

        // Handle file upload
        $file_path = '';
        if (!empty($_FILES['version_file']['name'])) {
            $target_dir = '../../uploads/versions/';
            if (!file_exists($target_dir)) {
                mkdir($target_dir, 0777, true);
            }
            $filename = time() . '_' . basename($_FILES['version_file']['name']);
            $target_file = $target_dir . $filename;

            if (move_uploaded_file($_FILES['version_file']['tmp_name'], $target_file)) {
                $file_path = 'uploads/versions/' . $filename;
            }
        }

        $stmt = $connect->prepare("INSERT INTO version (version_number, release_date, features, changelog, file_path, created_by)
                                   VALUES (?, ?, ?, ?, ?, ?)");

        $result = $stmt->execute([
            $new_version_number,
            $release_date,
            $features,
            $changelog,
            $file_path,
            $created_by
        ]);

        if ($result) {
            echo 'New version <strong>' . $new_version_number . '</strong> added successfully!';
        } else {
            echo 'Error adding version.';
        }

    }

    if ($_POST['btn_action'] == 'delete' && $_SESSION['type'] == 'master') {
        $version_id = $_POST['version_id'];

        // Optional: Delete file from server
        $stmt = $connect->prepare("SELECT file_path FROM version WHERE version_id = ?");
        $stmt->execute([$version_id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row && !empty($row['file_path']) && file_exists('../../' . $row['file_path'])) {
            unlink('../../' . $row['file_path']);
        }

        $stmt = $connect->prepare("DELETE FROM version WHERE version_id = ?");
        $stmt->execute([$version_id]);

        echo 'Version deleted successfully.';
    }
}
?>