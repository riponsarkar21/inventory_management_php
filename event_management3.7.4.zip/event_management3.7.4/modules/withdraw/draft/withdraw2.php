<?php
// modules/withdraw/withdraw.php
include('../../database_connection.php');
include('../../header.php');

if (!isset($_SESSION['user_id'])) {
    die("Unauthorized access.");
}
$user_id = $_SESSION['user_id'];
?>

<!-- DataTables CSS & Buttons -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
<link rel="stylesheet" href="../../css/datepicker.css">

<style>
    .btn-wrapper {
        display: flex;
        justify-content: center;
    }
    @media (max-width: 768px) {
        .btn-wrapper {
            flex-direction: column;
            align-items: center;
        }
        .btn-wrapper button {
            margin-bottom: 5px;
            width: 90px;
        }
    }
</style>

<span id="alert_action"></span>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading clearfix">
                <div class="pull-left">
                    <h3 class="panel-title">Withdraw List</h3>
                </div>
                <div class="pull-right">
                    <button type="button" id="add_button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#withdrawModal">Add Withdraw</button>
                </div>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table id="withdraw_data" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Relation</th>
                                <th>Amount</th>
                                <th>Method</th>
                                <th>Status</th>
                                <th>Update</th>
                                <th>PDF</th>
                                <th>Change Status</th>
                                <th>Cancel</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="withdrawModal" class="modal fade">
    <div class="modal-dialog modal-lg">
        <form method="post" id="withdraw_form">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add Withdraw Entry</h4>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="withdraw_id" id="withdraw_id">
                    <div class="form-group"><label>Withdrawer Name</label><input type="text" name="withdrawer_name" id="withdrawer_name" class="form-control" required></div>
                    <div class="form-group"><label>Phone</label><input type="text" name="withdrawer_phone" id="withdrawer_phone" class="form-control"></div>
                    <div class="form-group"><label>Address</label><textarea name="withdrawer_address" id="withdrawer_address" class="form-control"></textarea></div>
                    <div class="form-group"><label>Relation</label><input type="text" name="relation" id="relation" class="form-control"></div>
                    <div class="form-group"><label>Amount</label><input type="number" step="0.01" name="amount" id="amount" class="form-control" required></div>
                    <div class="form-group">
                        <label>Payment Method</label>
                        <select name="method" id="method" class="form-control">
                            <option value="Cash">Cash</option>
                            <option value="Bank">Bank</option>
                            <option value="Bkash">Bkash</option>
                            <option value="Nagad">Nagad</option>
                            <option value="Others">Others</option>
                        </select>
                    </div>
                    <div id="cash_breakdown" style="display:none">
                        <label>Cash Breakdown</label>
                        <div class="row">
                            <div class="col-md-3"><input type="number" name="note_1000" placeholder="1000 TK" class="form-control"></div>
                            <div class="col-md-3"><input type="number" name="note_500" placeholder="500 TK" class="form-control"></div>
                            <div class="col-md-3"><input type="number" name="note_100" placeholder="100 TK" class="form-control"></div>
                            <div class="col-md-3"><input type="number" name="coin_1" placeholder="1 TK Coin" class="form-control"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="user_id" value="<?= $user_id ?>">
                    <input type="hidden" name="action" value="Add">
                    <input type="submit" id="submit_button" class="btn btn-info" value="Add" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function() {
    $('#withdraw_form').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url: "withdraw_action.php",
            method: "POST",
            data: $(this).serialize(),
            success: function(data) {
                $('#withdraw_form')[0].reset();
                $('#withdrawModal').modal('hide');
                $('#alert_action').html('<div class="alert alert-success">'+data+'</div>');
                $('#withdraw_data').DataTable().ajax.reload();
            }
        });
    });

    $('#method').on('change', function() {
        if ($(this).val() === 'Cash') {
            $('#cash_breakdown').slideDown();
        } else {
            $('#cash_breakdown').slideUp();
        }
    });


$('#withdraw_data').DataTable({
    "processing": true,
    "serverSide": true,
    "ajax": {
        "url": "withdraw_fetch.php",
        "type": "POST"
    }
});

});
</script>