<?php
// modules/withdraw/withdraw_action.php

include('../../database_connection.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'delete') {
        $stmt = $connect->prepare("DELETE FROM withdraw WHERE withdraw_id = ?");
        $stmt->execute([$_POST['id']]);
        echo "Withdraw entry deleted.";
        exit;
    }

    if ($action === 'change_status') {
        $stmt = $connect->prepare("UPDATE withdraw SET status = IF(status='approved','pending','approved') WHERE withdraw_id = ?");
        $stmt->execute([$_POST['id']]);
        echo "Status updated.";
        exit;
    }

    if ($action === 'cancel') {
        $stmt = $connect->prepare("UPDATE withdraw SET status = 'cancelled' WHERE withdraw_id = ?");
        $stmt->execute([$_POST['id']]);
        echo "Withdraw entry cancelled.";
        exit;
    }

    if ($action === 'fetch_single') {
        $stmt = $connect->prepare("SELECT * FROM withdraw WHERE withdraw_id = ?");
        $stmt->execute([$_POST['id']]);
        echo json_encode($stmt->fetch(PDO::FETCH_ASSOC));
        exit;
    }

    if (!empty($_POST['withdraw_id'])) {
        // UPDATE MODE
        $stmt = $connect->prepare("UPDATE withdraw SET withdrawer_name=?, withdrawer_phone=?, withdrawer_address=?, relation=?, amount=?, method=?, note_1000=?, note_500=?, note_100=?, coin_1=? WHERE withdraw_id=?");
        $stmt->execute([
            $_POST['withdrawer_name'],
            $_POST['withdrawer_phone'],
            $_POST['withdrawer_address'],
            $_POST['relation'],
            $_POST['amount'],
            $_POST['method'],
            $_POST['note_1000'] ?? null,
            $_POST['note_500'] ?? null,
            $_POST['note_100'] ?? null,
            $_POST['coin_1'] ?? null,
            $_POST['withdraw_id']
        ]);

        echo "Withdraw entry updated successfully.";

    } else {
        // NEW ENTRY MODE
        $created_by = $_SESSION['user_id'] ?? 'Unknown';
        $user_id = $_SESSION['user_id'] ?? null;

        if ($user_id === null) {
            echo "Error: User not logged in.";
            exit;
        }

        $stmt = $connect->prepare("INSERT INTO withdraw (
            withdrawer_id, withdrawer_name, withdrawer_phone, withdrawer_address, relation, user_id,
            amount, method, note_1000, note_500, note_100, coin_1, status, created_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)");

        $stmt->execute([
            null, // placeholder for withdrawer_id if not managed in UI yet
            $_POST['withdrawer_name'],
            $_POST['withdrawer_phone'],
            $_POST['withdrawer_address'],
            $_POST['relation'],
            $user_id,
            $_POST['amount'],
            $_POST['method'],
            $_POST['note_1000'] ?? null,
            $_POST['note_500'] ?? null,
            $_POST['note_100'] ?? null,
            $_POST['coin_1'] ?? null,
            $created_by
        ]);

        echo "Withdraw entry added successfully.";
    }
}
