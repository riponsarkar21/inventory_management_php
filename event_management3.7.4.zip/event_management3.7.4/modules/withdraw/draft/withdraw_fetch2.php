<?php
// modules/withdraw/withdraw_fetch.php

include('../../database_connection.php');

$column = array(
    "withdraw_id",
    "withdrawer_name",
    "withdrawer_phone",
    "relation",
    "amount",
    "method",
    "status"
);

// Prepare base query
$query = "SELECT * FROM withdraw WHERE deleted_at IS NULL ";

// Search handling
if (isset($_POST["search"]["value"])) {
    $search_value = $_POST["search"]["value"];
    $query .= 'AND (
        withdrawer_name LIKE :search OR 
        withdrawer_phone LIKE :search OR 
        relation LIKE :search OR 
        method LIKE :search OR 
        status LIKE :search
    ) ';
}

// Order handling
if (isset($_POST["order"])) {
    $query .= 'ORDER BY ' . $column[$_POST['order']['0']['column']] . ' ' . $_POST['order']['0']['dir'] . ' ';
} else {
    $query .= 'ORDER BY withdraw_id DESC ';
}

// Pagination
$start = $_POST['start'] ?? 0;
$length = $_POST['length'] ?? 10;
$query .= "LIMIT $start, $length";

// Prepare statement
$statement = $connect->prepare($query);

// Bind search value
if (isset($search_value)) {
    $statement->bindValue(':search', '%' . $search_value . '%');
}

$statement->execute();
$data = $statement->fetchAll();

$filtered_rows = count($data);

$sub_array = [];
foreach ($data as $row) {
    $sub_array[] = [
        $row["withdraw_id"],
        htmlspecialchars($row["withdrawer_name"]),
        htmlspecialchars($row["withdrawer_phone"]),
        htmlspecialchars($row["relation"]),
        number_format($row["amount"], 2),
        htmlspecialchars($row["method"]),
        ucfirst($row["status"]),
        '<button type="button" name="update" id="' . $row["withdraw_id"] . '" class="btn btn-warning btn-xs update">Update</button>',
        '<a href="withdraw_pdf.php?id=' . $row["withdraw_id"] . '" class="btn btn-info btn-xs" target="_blank">PDF</a>',
        '<button type="button" name="status" id="' . $row["withdraw_id"] . '" class="btn btn-success btn-xs status">Change</button>',
        '<button type="button" name="cancel" id="' . $row["withdraw_id"] . '" class="btn btn-secondary btn-xs cancel">Cancel</button>',
        '<button type="button" name="delete" id="' . $row["withdraw_id"] . '" class="btn btn-danger btn-xs delete">Delete</button>',
    ];
}

$output = array(
    "draw" => intval($_POST["draw"]),
    "recordsTotal" => get_total_records($connect),
    "recordsFiltered" => $filtered_rows,
    "data" => $sub_array
);

// Send JSON response
echo json_encode($output);

// Helper to get total records
function get_total_records($connect) {
    $stmt = $connect->prepare("SELECT COUNT(*) FROM withdraw WHERE deleted_at IS NULL");
    $stmt->execute();
    return $stmt->fetchColumn();
}