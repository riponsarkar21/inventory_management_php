<?php
// File: modules/withdraw/init_withdraw_sql.php
include('../../config/database_connection.php');

try {
    $sql = "
    CREATE TABLE IF NOT EXISTS withdraw (
        withdraw_id INT AUTO_INCREMENT PRIMARY KEY,
        person_name VARCHAR(255) NOT NULL,
        phone VARCHAR(50) NULL,
        amount DECIMAL(10,2) NOT NULL,
        payment_method VARCHAR(50) NOT NULL,
        note TEXT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'active',
        user_id INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ";

    $connect->exec($sql);
    echo "Table 'withdraw' created or already exists.";
} catch (PDOException $e) {
    echo "Error creating table: " . $e->getMessage();
}
