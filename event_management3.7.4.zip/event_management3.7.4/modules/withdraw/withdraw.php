<?php
include('../../database_connection.php');
include('../../header.php');
?>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">

<span id="alert_action"></span>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading clearfix">
                <h3 class="panel-title pull-left">Withdraw List</h3>
                <button type="button" id="add_button" class="btn btn-success btn-xs pull-right" data-toggle="modal" data-target="#withdrawModal">Add Withdraw</button>
            </div>
            <div class="panel-body">
                <table id="withdraw_data" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Person</th>
                            <th>Phone</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Note</th>
                            <th>Status</th>
                            <th>Update</th>
                            <th>Status</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Form -->
<div id="withdrawModal" class="modal fade">
    <div class="modal-dialog">
        <form method="post" id="withdraw_form">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add Withdraw</h4>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="withdraw_id" id="withdraw_id">
                    <input type="hidden" name="action" id="action" value="Add">
                    <div class="form-group"><label>Person Name</label><input type="text" name="person_name" id="person_name" class="form-control" required></div>
                    <div class="form-group"><label>Phone</label><input type="text" name="phone" id="phone" class="form-control"></div>
                    <div class="form-group"><label>Amount</label><input type="number" name="amount" id="amount" class="form-control" required></div>
                    <div class="form-group">
                        <label>Payment Method</label>
                        <select name="payment_method" id="payment_method" class="form-control">
                            <option value="Cash">Cash</option>
                            <option value="Bank">Bank</option>
                            <option value="Bkash">Bkash</option>
                            <option value="Nagad">Nagad</option>
                            <option value="Others">Others</option>
                        </select>
                    </div>
                    <div class="form-group"><label>Note</label><textarea name="note" id="note" class="form-control"></textarea></div>
                </div>
                <div class="modal-footer">
                    <input type="submit" class="btn btn-info" value="Save">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function(){
    const table = $('#withdraw_data').DataTable({
        "ajax": "withdraw_fetch.php",
        "order": [[0, "desc"]],
        "columns": [
            { "data": "withdraw_id" },
            { "data": "person_name" },
            { "data": "phone" },
            { "data": "amount" },
            { "data": "payment_method" },
            { "data": "note" },
            { 
                "data": "status",
                "render": function(data) {
                    let cls = data === 'active' ? 'label-success' : 'label-danger';
                    return `<span class="label ${cls}">${data}</span>`;
                }
            },
            {
                "data": null,
                "render": function(row) {
                    return `<button class="btn btn-primary btn-xs update-entry" data-id="${row.withdraw_id}">Update</button>`;
                }
            },
            {
                "data": null,
                "render": function(row) {
                    return `<button class="btn btn-info btn-xs change-status" data-id="${row.withdraw_id}">Change</button>`;
                }
            },
            {
                "data": null,
                "render": function(row) {
                    return `<button class="btn btn-danger btn-xs delete" data-id="${row.withdraw_id}">Delete</button>`;
                }
            }
        ]
    });

    $('#withdraw_form').on('submit', function(e){
        e.preventDefault();
        $.post('withdraw_action.php', $(this).serialize(), function(data){
            $('#withdraw_form')[0].reset();
            $('#withdrawModal').modal('hide');
            $('#alert_action').html('<div class="alert alert-success">'+data+'</div>');
            $('#action').val('Add');
            table.ajax.reload();
        });
    });

    $(document).on('click', '.update-entry', function(){
        const id = $(this).data('id');
        $.post('withdraw_action.php', { action: 'fetch_single', id: id }, function(data){
            const d = JSON.parse(data);
            $('#withdraw_id').val(d.withdraw_id);
            $('#person_name').val(d.person_name);
            $('#phone').val(d.phone);
            $('#amount').val(d.amount);
            $('#payment_method').val(d.payment_method);
            $('#note').val(d.note);
            $('#action').val('Update');
            $('#withdrawModal').modal('show');
        });
    });

    $(document).on('click', '.delete', function(){
        if(confirm("Delete this entry?")) {
            $.post('withdraw_action.php', { action: 'delete', id: $(this).data('id') }, function(data){
                $('#alert_action').html('<div class="alert alert-danger">'+data+'</div>');
                table.ajax.reload();
            });
        }
    });

    $(document).on('click', '.change-status', function(){
        $.post('withdraw_action.php', { action: 'change_status', id: $(this).data('id') }, function(data){
            $('#alert_action').html('<div class="alert alert-info">'+data+'</div>');
            table.ajax.reload();
        });
    });
});
</script>

<?php include('../../footer.php'); ?>
