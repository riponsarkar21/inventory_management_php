<?php
include('../../database_connection.php');

$query = "SELECT * FROM withdraw ORDER BY withdraw_id DESC";
$statement = $connect->prepare($query);
$statement->execute();
$result = $statement->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(['data' => $result]);
?>
