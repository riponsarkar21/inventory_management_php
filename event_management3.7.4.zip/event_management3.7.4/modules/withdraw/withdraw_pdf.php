
<?php
// File: baseurl/modules/withdraw/withdraw_pdf.php
require('../../fpdf/fpdf.php');
include('../../database_connection.php');

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $mysqli->prepare("SELECT * FROM withdraw WHERE withdraw_id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();

    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial','B',16);
    $pdf->Cell(40,10,'Withdraw Entry Report');
    $pdf->Ln(10);

    foreach ($result as $key => $value) {
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(50,10, ucfirst(str_replace('_', ' ', $key)) . ':', 0);
        $pdf->SetFont('Arial','',12);
        $pdf->Cell(100,10, $value, 0);
        $pdf->Ln(8);
    }
    $pdf->Output();
    exit;
}
?>
