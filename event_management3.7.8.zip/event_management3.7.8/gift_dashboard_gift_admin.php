<?php
//gift_dashboard_Gift_admin.php 

// 26.07.2025 v10 : 

include('database_connection.php');
// include('gift_function.php');
include('function.php');

if(!isset($_SESSION["type"]))
{
    header("location:login.php");
}

include('header.php');
?>

<!-- Override external styles with embedded styles -->
<style>
    :root {
        --primary-color: rgb(82, 81, 163);
        --secondary-color: #afaefa;
        --theme-color: #afaefa;
        --content-background-color: rgb(255, 222, 222);
        --box-content-color: rgb(37, 32, 109);
        --circle-font-color: rgb(255, 255, 255);
    }

    html,
    body {
        height: 100%;
        margin: 0;
        padding: 0;
        background-color: var(--theme-color);
        font-family: sans-serif;
    }

    .container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-items: center;
        min-height: 100%;
        padding: 20px;
        box-sizing: border-box;
    }

    .box {
        margin: 15px;
        width: 300px;
        height: 300px;
        box-sizing: border-box;
        padding: 15px;
        position: relative;
        overflow: hidden;
    }

    .box::before {
        content: '';
        position: absolute;
        width: 150%;
        height: 150%;
        background: repeating-linear-gradient(
            white 0%,
            white 7.5px,
            var(--primary-color) 7.5px,
            var(--primary-color) 15px,
            white 15px,
            white 22.5px,
            var(--primary-color) 22.5px,
            var(--primary-color) 30px);
        transform: translateX(-20%) translateY(-20%) rotate(-45deg);
        animation: animate 20s linear infinite;
    }

    .box .content {
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        background-color: var(--content-background-color);
        flex-direction: column;
        box-sizing: border-box;
        padding: 20px;
        text-align: center;
        z-index: 2;
    }

    .box,
    .box .content {
        box-shadow: 0 0 2px var(--primary-color),
                    0 0 5px rgba(0, 0, 0, 1),
                    inset 0 0 5px rgba(0, 0, 0, 1);
        border-radius: 10px;
    }

    .box .content h2 {
        color: var(--primary-color);
        margin: 2px;
        font-size: 1.2rem;
    }

    .box .content .circle{
        display: flex;
        color: var(--circle-font-color);
        margin: 2px;
        font-size: 2rem;
        font-weight: bold;
        border-radius: 50%;
        background-color: var(--secondary-color);
        min-height: 110px;
        min-width: 110px;
        align-items: center;
        justify-content: center;
        padding: 5px;
        border: 2px solid;
    }

    .box .content p {
        color: var(--box-content-color);
        margin: 5px 0;
        font-size: 1rem;
        font-weight: bold;
    }

    .box .content .withdraw h2 {
        color: var(--box-content-color);
        margin: 5px 0;
        font-size: 1rem;
        font-weight: bold;
        padding: 10px 0;
    }

    .withdraw{
        display: inline-flexbox;
        align-content: space-between ;
        margin-bottom: 50px;
    }

    .draw-border {
        box-shadow: inset 0 0 0 4px #58cdd1;
        color: #58afd1;
        -webkit-transition: color 0.25s 0.0833333333s;
        transition: color 0.25s 0.0833333333s;
        position: relative;
    }

    .draw-border::before,
    .draw-border::after {
        border: 0 solid transparent;
        box-sizing: border-box;
        content: '';
        pointer-events: none;
        position: absolute;
        width: 0rem;
        height: 0;
        bottom: 0;
        right: 0;
    }

    .draw-border::before {
        border-bottom-width: 4px;
        border-left-width: 4px;
    }

    .draw-border::after {
        border-top-width: 4px;
        border-right-width: 4px;
    }

    .draw-border:hover {
        color: var(--primary-color);
        border-radius: 20px;
    }

    .draw-border:hover::before,
    .draw-border:hover::after {
        border-color: #eb196e;
        -webkit-transition: border-color 0s, width 0.25s, height 0.25s;
        transition: border-color 0s, width 0.25s, height 0.25s;
        width: 100%;
        height: 100%;
        border-radius: 20px;
    }

    .draw-border:hover::before {
        -webkit-transition-delay: 0s, 0s, 0.25s;
        transition-delay: 0s, 0s, 0.25s;
    }

    .draw-border:hover::after {
        -webkit-transition-delay: 0s, 0.25s, 0s;
        transition-delay: 0s, 0.25s, 0s;
    }

    .btn {
        background: none;
        border: none;
        cursor: pointer;
        line-height: 1.5;
        font: 700 1.2rem 'Roboto Slab', sans-serif;
        padding: 0.75em 2em;
        letter-spacing: 0.05rem;
        margin: 1em;
        width: 13rem;
    }

    @keyframes animate {
        from {
            background-position: 0;
        }

        to {
            background-position: 0 450px;
        }
    }

    /* Media queries for responsive design */
    @media (max-width: 768px) {
        .box {
            width: 280px;
            height: 280px;
            margin: 10px;
        }

        .box .content {
            padding: 15px;
        }

        .box .content h2 {
            font-size: 1.1rem;
        }

        .box .content p {
            font-size: 0.85rem;
        }
    }

    @media (max-width: 480px) {
        .box {
            width: 90vw;
            max-width: 320px;
            height: auto;
            min-height: 250px;
            margin: 10px 0;
        }

        .box .content {
            padding: 15px;
            min-height: 220px;
        }

        .box .content h2 {
            font-size: 1rem;
        }

        .box .content p {
            font-size: 0.8rem;
        }
    }
</style>

<br />
<div class="row">
<?php
if (in_array($_SESSION['type'], ['Super Master', 'Master', 'Gift Admin']))
{
?>
    <div class="container">
        <div class="box">
            <div class="content">
                <h2>Total Guest</h2>
                <div class="circle">
                    <?php echo count_total_guest($connect); ?>
                </div>
                <p>Gift Provider : 100</p>
                <p>Gift Provider : 100</p>
                <p>Both Provider : 10</p>
            </div>
        </div>
        
        <div class="box">
            <div class="content">
                <h2>Total Collection</h2>
                <div class="circle">
                    <?php echo count_total_gift_collection_value_active_money_by_all_user($connect); ?>
                </div>
                <p>Bkash, Nagad : 
                    <span>
                        <?php echo count_total_gift_bkash_collection_value_by_all_user($connect); ?>
                    </span>
                </p>
                <p>Cash : 
                    <span>
                        <?php echo count_total_gift_cash_collection_value_by_user($connect); ?>
                    </span>
                </p>
            </div>
        </div>
        
        <div class="box">
            <div class="content">
                <div class="withdraw">
                    <h2>Total Withdraw: 
                        <span>
                            <?php echo count_total_withdraw_value_active_money_by_all_user($connect); ?>
                        </span>
                    </h2>
                    <h2>Total Balance: 
                        <span>
                            <?php echo count_total_balance_active_money_by_all_user($connect); ?>
                        </span>
                    </h2>
                </div>
                <button class="btn draw-border">Full Paid</button>
            </div>
        </div>
    </div>
<?php
}
?>
</div>

<?php
include("footer.php");
?>