<?php
// Include the database connection from config
require_once('config/database_connection.php');

// Include functions
require_once('function.php');

// Handle API requests
header('Content-Type: application/json');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch($action) {
    case 'totalGuest':
        echo json_encode(['value' => count_total_user($connect)]);
        break;
        
    case 'totalCollection':
        echo json_encode(['value' => count_total_collection_value($connect)]);
        break;
        
    case 'mobileCollection':
        echo json_encode(['value' => count_total_mobile_collection_value($connect)]);
        break;
        
    case 'cashCollection':
        echo json_encode(['value' => count_total_cash_collection_value($connect)]);
        break;
        
    case 'totalWithdraw':
        // Since this function doesn't exist in your code, we'll return 0
        echo json_encode(['value' => 0]);
        break;
        
    case 'totalBalance':
        // Since this function doesn't exist in your code, we'll return 0
        echo json_encode(['value' => 0]);
        break;
        
    default:
        echo json_encode(['error' => 'Invalid action']);
}
?>