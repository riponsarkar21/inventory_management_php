<?php
// category.php

session_start();
include('database_connection.php');

session_start(); // Make sure this is at the top

if (!isset($_SESSION['type']) || !in_array($_SESSION['type'], ['Super Master', 'Master'])) {
    header('location:login.php');
    exit();
}
include('header.php');
?>

<span id="alert_action"></span>
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				<div class="row">
					<div class="col-md-10">
						<h3 class="panel-title">Category List</h3>
					</div>
					<div class="col-md-2 text-right">
						<button type="button" name="add" id="add_button" data-toggle="modal" data-target="#categoryModal" class="btn btn-success btn-xs">
							<i class="fa fa-plus"></i> Add
						</button>
					</div>
				</div>
			</div>
			<div class="panel-body">
				<div class="table-responsive">
					<table id="category_data" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>ID</th>
								<th>Category Name</th>
								<th>Status</th>
								<th>Edit</th>
								<th>Visibility</th>
								<th>Delete</th>
							</tr>
						</thead>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Modal -->
<div id="categoryModal" class="modal fade">
	<div class="modal-dialog">
		<form method="post" id="category_form">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title"><i class="fa fa-plus"></i> Add Category</h4>
				</div>
				<div class="modal-body">
					<label>Enter Category Name</label>
					<input type="text" name="category_name" id="category_name" class="form-control" required />
				</div>
				<div class="modal-footer">
					<input type="hidden" name="category_id" id="category_id" />
					<input type="hidden" name="btn_action" id="btn_action" />
					<input type="submit" name="action" id="action" class="btn btn-info" value="Add" />
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		</form>
	</div>
</div>

<!-- JavaScript -->
<script>
$(document).ready(function(){

	var categorydataTable = $('#category_data').DataTable({
		"processing": true,
		"serverSide": true,
		"order": [],
		"ajax": {
			url: "category_fetch.php",
			type: "POST"
		},
		"columnDefs": [
			{
				"targets": [3, 4],
				"orderable": false,
			}
		],
		"lengthMenu": [ [5, 10, 25, 50, 100, 1000], [5, 10, 25, 50, 100, 1000] ],
			"pageLength": 10,

				// 👇 Add this section
			"dom": 
				"<'row'<'col-sm-6'l><'col-sm-6'f>>" + 
				"<'row'<'col-sm-12'tr>>" + 
				"<'row'<'col-sm-5'i><'col-sm-7'p>>" + 
				"<'row'<'col-sm-12 text-center mt-3'B>>",

			"buttons": [
				'copy', 'csv', 'excel', 'pdf', 'print'
			]
	});

	$('#add_button').click(function(){
		$('#category_form')[0].reset();
		$('.modal-title').html("<i class='fa fa-plus'></i> Add Category");
		$('#action').val('Add');
		$('#btn_action').val('Add');
	});

	$(document).on('submit', '#category_form', function(event){
		event.preventDefault();
		$('#action').attr('disabled', 'disabled');
		var form_data = $(this).serialize();
		$.ajax({
			url: "category_action.php",
			method: "POST",
			data: form_data,
			success: function(data){
				$('#category_form')[0].reset();
				$('#categoryModal').modal('hide');
				$('#alert_action').fadeIn().html('<div class="alert alert-success">'+data+'</div>');
				$('#action').attr('disabled', false);
				categorydataTable.ajax.reload();
			}
		});
	});

	$(document).on('click', '.update', function(){
		var category_id = $(this).attr("id");
		var btn_action = 'fetch_single';
		$.ajax({
			url: "category_action.php",
			method: "POST",
			data: {category_id: category_id, btn_action: btn_action},
			dataType: "json",
			success: function(data){
				$('#categoryModal').modal('show');
				$('#category_name').val(data.category_name);
				$('.modal-title').html("<i class='fa fa-pencil-square-o'></i> Edit Category");
				$('#category_id').val(category_id);
				$('#action').val('Edit');
				$('#btn_action').val("Edit");
			}
		});
	});

	$(document).on('click', '.status', function(){
		var category_id = $(this).attr("id");
		var status = $(this).data('status');
		var btn_action = "status";
		if(confirm("Are you sure you want to change the status of this category?")) {
			$.ajax({
				url: "category_action.php",
				method: "POST",
				data: {category_id: category_id, status: status, btn_action: btn_action},
				success: function(data){
					$('#alert_action').fadeIn().html('<div class="alert alert-info">'+data+'</div>');
					categorydataTable.ajax.reload();
				}
			});
		}
	});

	$(document).on('click', '.delete', function(){
		var category_id = $(this).attr("id");
		var status = $(this).data('delete');
		var btn_action = "delete";
		if(confirm("Are you sure you want to delete this category?")) {
			$.ajax({
				url: "category_action.php",
				method: "POST",
				data: {category_id: category_id, status: status, btn_action: btn_action},
				success: function(data){
					$('#alert_action').fadeIn().html('<div class="alert alert-warning">'+data+'</div>');
					categorydataTable.ajax.reload();
				}
			});
		}
	});
});
</script>

<?php include('footer.php'); ?>
