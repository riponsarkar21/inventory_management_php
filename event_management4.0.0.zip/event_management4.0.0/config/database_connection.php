<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


//  // for cloud database server 
//  $host = "mysql5049.site4now.net";
//  $dbname = "db_abe065_invento";
//  $username = "abe065_invento";
//  $password = "@Abc12345";


// for localhost xampp server 
$host = "localhost";
$dbname = "db_abe065_invento";
$username = "root";
$password = "";

try {
    // 👇 Include charset=utf8mb4 in DSN
    $connect = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // 👇 Optional but good practice
    $connect->exec("SET NAMES utf8mb4");
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>