<?php
// event_setting.php
// Event Management v4.0
// 10.08.2025

session_start();
include('config/database_connection.php');
include('header.php');

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $template = $_POST['gift_ticket_template'] ?? '';
    $default_event_id = $_POST['default_event_id'] ?? '';

    if (in_array($template, ['gift_ticket_pdf_qr.php', 'gift_ticket_pdf_qr_logo.php'])) {
        $stmt = $connect->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('gift_ticket_template', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->execute([$template, $template]);
        
        $stmt = $connect->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('default_event_id', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->execute([$default_event_id, $default_event_id]);
        
        $message = "✅ Settings saved successfully.";
    } else {
        $error = "❌ Invalid template selected.";
    }
}

// Fetch current settings
$stmt = $connect->prepare("SELECT setting_value FROM settings WHERE setting_key = 'gift_ticket_template'");
$stmt->execute();
$current_template = $stmt->fetchColumn() ?: 'gift_ticket_pdf_qr.php';

$stmt = $connect->prepare("SELECT setting_value FROM settings WHERE setting_key = 'default_event_id'");
$stmt->execute();
$default_event_id = $stmt->fetchColumn() ?: '';

?>

<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Event Settings</h1>
            
            <?php if (isset($message)): ?>
                <div class="alert alert-success"><?= $message ?></div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>

            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-cog fa-fw"></i> Configure Event Settings
                </div>
                <div class="panel-body">
                    <form method="POST" class="form-horizontal">
                        <div class="form-group">
                            <label for="gift_ticket_template" class="col-sm-3 control-label">Gift Ticket PDF Template</label>
                            <div class="col-sm-6">
                                <select name="gift_ticket_template" id="gift_ticket_template" class="form-control" required>
                                    <option value="gift_ticket_pdf_qr.php" <?= $current_template === 'gift_ticket_pdf_qr.php' ? 'selected' : '' ?>>gift_ticket_pdf_qr.php</option>
                                    <option value="gift_ticket_pdf_qr_logo.php" <?= $current_template === 'gift_ticket_pdf_qr_logo.php' ? 'selected' : '' ?>>gift_ticket_pdf_qr_logo.php</option>
                                </select>
                                <p class="help-block">Select the default PDF template for gift tickets.</p>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="default_event_id" class="col-sm-3 control-label">Default Event ID</label>
                            <div class="col-sm-6">
                                <input type="number" name="default_event_id" id="default_event_id" class="form-control" value="<?= htmlspecialchars($default_event_id) ?>" placeholder="Enter event ID">
                                <p class="help-block">Enter the default event ID to use for gift tickets. Leave blank to use hardcoded values.</p>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-6">
                                <button type="submit" class="btn btn-primary">Save Settings</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>