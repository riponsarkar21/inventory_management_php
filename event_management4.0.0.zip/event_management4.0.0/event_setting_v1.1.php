<?php
// event_setting.php
// Event Management v4.0
// 10.08.2025

session_start();
include('config/database_connection.php');

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $template = $_POST['gift_ticket_template'] ?? '';
    $default_event_id = $_POST['default_event_id'] ?? '';

    if (in_array($template, ['gift_ticket_pdf_qr.php', 'gift_ticket_pdf_qr_logo.php'])) {
        $stmt = $connect->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('gift_ticket_template', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->execute([$template, $template]);
        
        $stmt = $connect->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('default_event_id', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->execute([$default_event_id, $default_event_id]);
        
        $message = "✅ Settings saved successfully.";
    } else {
        $error = "❌ Invalid template selected.";
    }
}

// Fetch current settings
$stmt = $connect->prepare("SELECT setting_value FROM settings WHERE setting_key = 'gift_ticket_template'");
$stmt->execute();
$current_template = $stmt->fetchColumn() ?: 'gift_ticket_pdf_qr.php';

$stmt = $connect->prepare("SELECT setting_value FROM settings WHERE setting_key = 'default_event_id'");
$stmt->execute();
$default_event_id = $stmt->fetchColumn() ?: '';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Event Settings</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        .container { max-width: 600px; margin: 40px auto; padding: 20px; }
        .form-group { margin: 15px 0; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        select, button { padding: 8px; font-size: 16px; }
        .message { padding: 10px; margin: 10px 0; border-radius: 4px; }
        .success { background: #d4edda; color: #155724; }
        .error { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Event Settings</h1>
        <?php if (isset($message)): ?><div class="message success"><?= $message ?></div><?php endif; ?>
        <?php if (isset($error)): ?><div class="message error"><?= $error ?></div><?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label for="gift_ticket_template">Gift Ticket PDF Template</label>
                <select name="gift_ticket_template" id="gift_ticket_template" required>
                    <option value="gift_ticket_pdf_qr.php" <?= $current_template === 'gift_ticket_pdf_qr.php' ? 'selected' : '' ?>>gift_ticket_pdf_qr.php</option>
                    <option value="gift_ticket_pdf_qr_logo.php" <?= $current_template === 'gift_ticket_pdf_qr_logo.php' ? 'selected' : '' ?>>gift_ticket_pdf_qr_logo.php</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="default_event_id">Default Event ID (Optional)</label>
                <input type="number" name="default_event_id" id="default_event_id" value="<?= htmlspecialchars($default_event_id) ?>" placeholder="Enter event ID">
                <small>Leave blank to use hardcoded values</small>
            </div>
            
            <button type="submit">Save Settings</button>
        </form>
    </div>
</body>
</html>