<?php
if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
    $redirect = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header('Location: ' . $redirect);
    exit();
}
?>




<?php
//index.php

// 21/7/2025/ 1:57AM
require 'config/config.php';

include('database_connection.php');
include('function.php');



if(!isset($_SESSION["type"]))
{
	header("location:login.php");
}

// Block Gift Admin or Gift User from accessing index.php
if ($_SESSION["user_type"] == 'Gift Admin' || $_SESSION["user_type"] == 'Gift User') {
    header("location:gift_dashboard.php");
    exit();
}



include('header.php');

?>


	<br />
	<div class="row">
	<?php
	if (!isset($_SESSION["type"]) || in_array($_SESSION["type"], ['Super Master', 'Master', 'Gift Admin', 'Inventory Admin']))
	{
	?>
	<div class="col-md-3">
		<div class="panel panel-default">
			<div class="panel-heading"><strong>Total User</strong></div>
			<div class="panel-body" align="center">
				<h1><?php echo count_total_user($connect); ?></h1>
			</div>
		</div>
	</div>
	<div class="col-md-3">
		<div class="panel panel-default">
			<div class="panel-heading"><strong>Total Category</strong></div>
			<div class="panel-body" align="center">
				<h1><?php echo count_total_category($connect); ?></h1>
			</div>
		</div>
	</div>
	<div class="col-md-3">
		<div class="panel panel-default">
			<div class="panel-heading"><strong>Total Brand</strong></div>
			<div class="panel-body" align="center">
				<h1><?php echo count_total_brand($connect); ?></h1>
			</div>
		</div>
	</div>
	<div class="col-md-3">
		<div class="panel panel-default">
			<div class="panel-heading"><strong>Total Item in Stock</strong></div>
			<div class="panel-body" align="center">
				<h1><?php echo count_total_product($connect); ?></h1>
			</div>
		</div>
	</div>
	<?php
	}
	?>

	<!-- --------------------------------- Order ------------------------------------------------ -->
		<div class="col-md-4">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Order Value</strong></div>
				<div class="panel-body" align="center">
					<h1>$<?php echo count_total_order_value($connect); ?></h1>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Cash Order Value</strong></div>
				<div class="panel-body" align="center">
					<h1>$<?php echo count_total_cash_order_value($connect); ?></h1>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Credit Order Value</strong></div>
				<div class="panel-body" align="center">
					<h1>$<?php echo count_total_credit_order_value($connect); ?></h1>
				</div>
			</div>
		</div>
		<hr />


	<!-- --------------------------------- Collection ------------------------------------------- -->

		<div class="col-md-4">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Collection Value</strong></div>
				<div class="panel-body" align="center">
					<h1>$<?php echo count_total_collection_value($connect); ?></h1>
				</div>
			</div>
		</div>
		<div class="col-md-2">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Cash Collection Value</strong></div>
				<div class="panel-body" align="center">
					<h1>$<?php echo count_total_cash_collection_value($connect); ?></h1>
				</div>
			</div>
		</div>
		<div class="col-md-2">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Bank Collection Value</strong></div>
				<div class="panel-body" align="center">
					<h1>$<?php echo count_total_bank_collection_value($connect); ?></h1>
				</div>
			</div>
		</div>
				<div class="col-md-2">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Mobile Collection Value</strong></div>
				<div class="panel-body" align="center">
					<h1>$<?php echo count_total_mobile_collection_value($connect); ?></h1>
				</div>
			</div>
		</div>
				<div class="col-md-2">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Others Collection Value</strong></div>
				<div class="panel-body" align="center">
					<h1>$<?php echo count_total_others_collection_value($connect); ?></h1>
				</div>
			</div>
		</div>
		<hr />




	<!---------------------------------- Total Order Value User wise ---------------------------------->

		<?php
		if($_SESSION['type'] == 'Master')
		{
		?>
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Order Value User wise</strong></div>
				<div class="panel-body" align="center">
					<?php echo get_user_wise_total_order($connect); ?>
				</div>
			</div>
		</div>
		<?php
		}
		?>

		<hr />

	<!---------------------------------- Total Collection Value User wise ---------------------------------->
	
		<?php
		if($_SESSION['type'] == 'Master')
		{
		?>
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Collection Value User wise</strong></div>
				<div class="panel-body" align="center">
					<?php 
						echo get_user_wise_total_collection($connect); 
					?>
				</div>
			</div>
		</div>
		<?php
		}
		?>
	</div>

<?php
include("footer.php");
?>