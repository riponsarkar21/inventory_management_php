<?php
// init_settings_sql.php
// event_management 3.7.6
// 10.08.2025

$root = dirname(__DIR__);
require_once $root . '/database_connection.php';

if (!isset($connect)) {
    die('❌ Database connection not available.');
}

$query = "
CREATE TABLE IF NOT EXISTS `settings` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `setting_key` VARCHAR(100) NOT NULL UNIQUE,
  `setting_value` TEXT,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES
('gift_ticket_template', 'gift_ticket_pdf_qr.php'),
('app_version', 'event_management_v4.0')
ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`);
";

try {
    $connect->exec($query);
    echo "✅ Settings table created and initialized successfully.";
} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>