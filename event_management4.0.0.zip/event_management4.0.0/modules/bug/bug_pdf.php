<?php
// modules/bug/bug_pdf.php

include(__DIR__ . '/../../database_connection.php');
require_once(__DIR__ . '/../../pdf.php'); // Adjust if pdf.php is in a different location

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die('Invalid ID');
}

$id = intval($_GET['id']);
$stmt = $connect->prepare("SELECT * FROM bug WHERE bug_id = ?");
$stmt->execute([$id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    die('No bug entry found');
}

$html = '
<style>
    body { font-family: DejaVu Sans, sans-serif; }
    h2 { text-align: center; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th, td { padding: 8px; border: 1px solid #000; }
    .cancelled { color: red; font-size: 20px; text-align: center; }
</style>

<h2>Bug Report</h2>';

if (strtolower($row['status']) === 'cancelled') {
    $html .= '<div class="cancelled">❌ This Bug is Cancelled</div>';
}

$html .= '<table>
    <tr><th>Title</th><td>' . htmlspecialchars($row['bug_title']) . '</td></tr>
    <tr><th>Description</th><td>' . nl2br(htmlspecialchars($row['bug_description'])) . '</td></tr>
    <tr><th>Status</th><td>' . htmlspecialchars($row['status']) . '</td></tr>
    <tr><th>Created By</th><td>' . htmlspecialchars($row['created_by']) . '</td></tr>
    <tr><th>Created At</th><td>' . htmlspecialchars($row['created_at']) . '</td></tr>
    <tr><th>Solved By</th><td>' . htmlspecialchars($row['solved_by']) . '</td></tr>
    <tr><th>Solved At</th><td>' . htmlspecialchars($row['solved_at']) . '</td></tr>';

if (!empty($row['screenshot_image'])) {
    $serverPath = $_SERVER['DOCUMENT_ROOT'] . $row['screenshot_image'];
    if (file_exists($serverPath)) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime  = finfo_file($finfo, $serverPath);
        finfo_close($finfo);

        $base64 = base64_encode(file_get_contents($serverPath));
        $src    = 'data:' . $mime . ';base64,' . $base64;

        $html .= '<tr><th>Screenshot</th><td><img src="' . $src . '" width="300" style="border:1px solid #000;"></td></tr>';
    }
}

$html .= '</table>';

$pdf = new Pdf();
$pdf->loadHtml($html);
$pdf->setPaper('A4', 'portrait');
$pdf->render();
$pdf->stream("bug_report_{$id}.pdf", ["Attachment" => false]);
exit;
?>
