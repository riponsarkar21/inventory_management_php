    $(document).ready(function(){
    const table = $('#event_data').DataTable({
        "ajax": "event_fetch.php",
        "order": [[0, "desc"]],
        "columns": [
            { "data": "id" },
            { "data": "event_title" },
            { "data": "event_location" },
            { "data": "event_date" },
            { "data": "event_host" },
            { "data": "event_host_contact" },
            { "data": "event_participant_number" },
            { "data": "event_deal_amount" },
            {
                "data": "status",
                "render": function(data) {
                    let colorClass = '';
                    switch (data.toLowerCase()) {
                        case 'active': colorClass = 'label label-success'; break;
                        case 'inactive': colorClass = 'label label-warning'; break;
                        case 'cancelled': colorClass = 'label label-danger'; break;
                        default: colorClass = 'label label-default';
                    }
                    return `<span class="${colorClass}">${data}</span>`;
                }
            },
            { "data": null, "render": row => `<button class="btn btn-primary btn-xs update-entry" data-id="${row.id}">Update</button>` },
            { "data": null, "render": row => `<button class="btn btn-info btn-xs change-status" data-id="${row.id}">Change Status</button>` },
            { "data": null, "render": row => `<button class="btn btn-warning btn-xs cancel-entry" data-id="${row.id}">Cancel</button>` },
            { "data": null, "render": row => `<button class="btn btn-danger btn-xs delete" data-id="${row.id}">Delete</button>` }
        ],        "lengthMenu": [[5, 10, 25, 50], [5, 10, 25, 50]],
        "pageLength": 10,
        "dom":
            "<'row'<'col-sm-6'l><'col-sm-6'f>>" +
            "<'row'<'col-sm-12'tr>>" +
            "<'row'<'col-sm-5'i><'col-sm-7'p>>" +
            "<'row'<'col-sm-12 text-center mt-3'B>>",
        "buttons": ['copy', 'csv', 'excel', 'pdf', 'print']
    });

    $('#event_form').on('submit', function(e){
        e.preventDefault();
        const formData = $(this).serialize();
        $.post("event_action.php", formData, function(data){
            $('#event_form')[0].reset();
            $('#eventModal').modal('hide');
            $('#alert_action').html('<div class="alert alert-success">'+data+'</div>');
            table.ajax.reload();
            $('#action').val('Add');
            $('#id').val('');
        });
    });

    $(document).on('click', '.delete', function(){
        if(confirm("Delete this event?")) {
            $.post("event_action.php", { action: "delete", id: $(this).data('id') }, function(data){
                $('#alert_action').html('<div class="alert alert-danger">'+data+'</div>');
                table.ajax.reload();
            });
        }
    });

    $(document).on('click', '.change-status', function(){
        $.post("event_action.php", { action: "change_status", id: $(this).data('id') }, function(data){
            $('#alert_action').html('<div class="alert alert-info">'+data+'</div>');
            table.ajax.reload();
        });
    });

    $(document).on('click', '.cancel-entry', function(){
        if (confirm("Cancel this event?")) {
            $.post("event_action.php", { action: "cancel", id: $(this).data('id') }, function(data){
                $('#alert_action').html('<div class="alert alert-warning">'+data+'</div>');
                table.ajax.reload();
            });
        }
    });

    $(document).on('click', '.update-entry', function(){
        $.post("event_action.php", { action: "fetch_single", id: $(this).data('id') }, function(data){
            const d = JSON.parse(data);
            $('#id').val(d.id);
            $('#event_title').val(d.event_title);
            $('#event_location').val(d.event_location);
            $('#event_date').val(d.event_date);
            $('#event_host').val(d.event_host);
            $('#event_host_contact').val(d.event_host_contact);
            $('#event_participant_number').val(d.event_participant_number);
            $('#event_deal_amount').val(d.event_deal_amount);
            $('#discount').val(d.discount);
            $('#vat').val(d.vat);
            $('#total').val(d.total);
            $('#advance').val(d.advance);
            $('#due').val(d.due);

            // Clear all checkboxes first
            $('input[name="contract_details[]"]').prop('checked', false);

            // Parse contract details JSON, check checkboxes
            const contractDetails = JSON.parse(d.event_deal_contract_details || '[]');
            contractDetails.forEach(function(key) {
                $('input[name="contract_details[]"][value="' + key + '"]').prop('checked', true);
            });

            $('#action').val('Update');
            $('#eventModal').modal('show');
        });
    });

    

});




$(document).ready(function(){

    function calculateDealAmount() {
        let participants = parseFloat($('#event_participant_number').val()) || 0;
        let calculated = participants * 10;
        if (participants > 0) {
            if (calculated < 5000) {
                calculated = 5000;
            }
            $('#event_deal_amount').val(calculated.toFixed(2));
            calculateDue();
        }
    }

    function calculateTotal() {
        let deal = parseFloat($('#event_deal_amount').val()) || 0;
        let discount = parseFloat($('#discount').val()) || 0;
        let vat = parseFloat($('#vat').val()) || 0;

        let total = (deal - discount + vat);
        $('#total').val(total.toFixed(2));
    }

    function calculateDue() {
        let deal = parseFloat($('#event_deal_amount').val()) || 0;
        let discount = parseFloat($('#discount').val()) || 0;
        let vat = parseFloat($('#vat').val()) || 0;
        let advance = parseFloat($('#advance').val()) || 0;

        let due = (deal - discount + vat - advance);
        $('#due').val(due.toFixed(2));
    }


    // Auto-calc deal amount when participants change
    $('#event_participant_number').on('input', calculateDealAmount);

    // Recalculate total when any amount field changes
    $('#event_participant_number, #event_deal_amount, #discount, #vat').on('input', calculateTotal);

    // Recalculate due when any amount field changes
    $('#event_deal_amount, #discount, #vat, #advance').on('input', calculateDue);

    // Full Paid button
    $('#full_paid_btn').click(function(){
        let deal = parseFloat($('#event_deal_amount').val()) || 0;
        $('#advance').val(deal.toFixed(2));
        calculateDue();
    });




    // ------------ 

    document.getElementById('full_paid_btn').addEventListener('click', function() {
        let dealAmount = parseFloat(document.getElementById('event_deal_amount').value) || 0;
        let discount = parseFloat(document.getElementById('discount').value) || 0;
        let vat = parseFloat(document.getElementById('vat').value) || 0;
        let advanceField = document.getElementById('advance');

        if (dealAmount === 0) {
            alert('Please enter a valid Deal Amount first.');
            return;
        }

        if (confirm("This will set Advance = Deal Amount - Discount + Vat. Continue?")) {
            let advance = dealAmount - discount + vat;
            advanceField.value = advance.toFixed(2);

            // Optional: recalc due if you have calculateDue function
            if (typeof calculateDue === 'function') {
                calculateDue();
            }
        }
    });


});
