<?php
// modules/event/event.php
// 11.8.2025 v3
// When you enter participants, Deal Amount auto-fills = participants × 10 but minimum 5000.
// If you change Deal Amount manually, it will still recalculate Due.
// Due updates instantly if you change Deal Amount, Discount, VAT, or Advance.
// Total updates instantly if you change participants, deal amount, discount, or vat
// Clicking Full Paid sets Advance = Deal Amount and Due = 0.


// 10.08.2025 v2
// form update 
// checkbox split in 4 column for large screen
// added Discount, Vat, Advance, Due



if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!in_array($_SESSION['type'], ['Super Master', 'Master', 'Event Admin', 'Gift Admin', 'Event User'])) {
    header('location:' . (!isset($_SESSION['type']) ? '../../login.php' : '../../index.php'));
    exit;
}

include('../../database_connection.php');
include('../../header.php');
?>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
<link rel="stylesheet" href="../../css/datepicker.css">

<span id="alert_action"></span>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading clearfix">
                <div class="pull-left">
                    <h3 class="panel-title">Event List</h3>
                </div>
                <div class="pull-right">
                    <button type="button" id="add_button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#eventModal">Add Event</button>
                </div>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table id="event_data" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Location</th>
                                <th>Date</th>
                                <th>Host</th>
                                <th>Contact</th>
                                <th>Participants</th>
                                <th>Deal Amount</th>
                                <th>Status</th>
                                <th>Update</th>
                                <th>Change Status</th>
                                <th>Cancel</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="eventModal" class="modal fade">
    <div class="modal-dialog modal-lg">
        <form method="post" id="event_form">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add Event</h4>
                </div>
          <div class="modal-body">
                <input type="hidden" name="id" id="id">

                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="event_title" id="event_title" class="form-control" required>
                </div>

                <div class="form-group">
                    <label>Location</label>
                    <input type="text" name="event_location" id="event_location" class="form-control" required>
                </div>

                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Date</label>
                            <input type="date" name="event_date" id="event_date" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Participants</label>
                            <input type="number" name="event_participant_number" id="event_participant_number" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Host</label>
                            <input type="text" name="event_host" id="event_host" class="form-control" required>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Host Contact</label>
                            <input type="text" name="event_host_contact" id="event_host_contact" class="form-control" required>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>Deal Amount</label>
                            <input type="number" name="event_deal_amount" id="event_deal_amount" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>Discount</label>
                            <input type="number" name="discount" id="discount" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>Vat</label>
                            <input type="number" name="vat" id="vat" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>Total</label>
                            <input type="number" name="total" id="total" class="form-control" readonly>
                        </div>
                    </div>                    
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>Advance</label>
                            <input type="number" name="advance" id="advance" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>Due</label>
                            <input type="number" name="due" id="due" class="form-control" readonly>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <button type="button" class="btn btn-success btn-block" id="full_paid_btn">
                                Full Paid
                            </button>
                        </div>
                    </div>
                </div>

                    

                <h4>Contract Details</h4>
                    <div class="row">
                        <?php
                            $checkbox_fields = [
                                "gift_id"        => "Gift ID",
                                "created_by"     => "Created By",
                                "user_id"        => "User ID",
                                "guest_name"     => "Guest Name",
                                "phone"          => "Phone",
                                "address"        => "Address",
                                "relation"       => "Relation",
                                "gift_type"      => "Gift Type",
                                "amount"         => "Amount",
                                "payment_method" => "Payment Method",
                                "gift_details"   => "Gift Details",
                                "gift_image"     => "Gift Image"
                            ];

                            $count = 0;
                            foreach ($checkbox_fields as $field_key => $field_label) {
                                echo '<div class="col-md-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="contract_details[]" value="' . $field_key . '" id="' . $field_key . '">
                                            <label class="form-check-label" for="' . $field_key . '">' . $field_label . '</label>
                                        </div>
                                    </div>';
                                $count++;
                                if ($count % 4 === 0) { // after every 4 columns, start a new row
                                    echo '</div><div class="row">';
                                }
                            }
                        ?>
                    </div>


                <div class="modal-footer">
                    <input type="submit" name="action" id="action" class="btn btn-info" value="Add" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap.min.js"></script>


<script src="event.js"></script>

<!-- <script> -->

<!-- </script> -->

<?php include('../../footer.php'); ?>
