<?php
// modules/event/event_action.php
// event_management 3.7.6
// 10.08.2025

include('../../database_connection.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // DELETE
    if ($action === 'delete') {
        $stmt = $connect->prepare("DELETE FROM event WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        echo "Event deleted.";
        exit;
    }

    // TOGGLE STATUS
    if ($action === 'change_status') {
        $stmt = $connect->prepare("
            UPDATE event 
            SET status = IF(status='Active','Inactive','Active'),
                updated_at = NOW(),
                updated_by = ?
            WHERE id = ?
        ");
        $stmt->execute([$_SESSION['user_id'], $_POST['id']]);
        echo "Status updated.";
        exit;
    }

    // CANCEL
    if ($action === 'cancel') {
        $stmt = $connect->prepare("
            UPDATE event 
            SET status = 'Cancelled',
                updated_at = NOW(),
                updated_by = ?
            WHERE id = ?
        ");
        $stmt->execute([$_SESSION['user_id'], $_POST['id']]);
        echo "Event cancelled.";
        exit;
    }

    // FETCH SINGLE
    if ($action === 'fetch_single') {
        $stmt = $connect->prepare("SELECT * FROM event WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        echo json_encode($stmt->fetch(PDO::FETCH_ASSOC));
        exit;
    }

    // Collect contract details (checkbox array)
    $contract_details = $_POST['contract_details'] ?? [];
    $contract_json = json_encode($contract_details);

    // UPDATE
    if (!empty($_POST['id'])) {
        $stmt = $connect->prepare("
            UPDATE event
            SET event_title = ?, event_location = ?, event_date = ?, event_host = ?, event_host_contact = ?,
                event_participant_number = ?, event_deal_amount = ?,
                 discount = ?, vat = ?, total = ?,
                  advance = ?, due = ?, event_deal_contract_details = ?, 
                status = ?, updated_at = NOW(), updated_by = ?
            WHERE id = ?
        ");

        $stmt->execute([
            $_POST['event_title'],
            $_POST['event_location'],
            $_POST['event_date'],
            $_POST['event_host'],
            $_POST['event_host_contact'],
            $_POST['event_participant_number'],
            $_POST['event_deal_amount'],
            $_POST['discount'],
            $_POST['vat'],
            $_POST['total'],
            $_POST['advance'],
            $_POST['due'],
            $contract_json,
            $_POST['status'] ?? 'Active',
            $_SESSION['user_id'],
            $_POST['id']
        ]);

        echo "Event updated successfully.";
    }
    // INSERT
    else {
        if (!isset($_SESSION['user_id'])) {
            echo "Error: User not logged in.";
            exit;
        }

        $stmt = $connect->prepare("
            INSERT INTO event (
                event_title, event_location, event_date, event_host, event_host_contact,
                event_participant_number, event_deal_amount, event_deal_contract_details,
                status, created_at, created_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Active', NOW(), ?)
        ");

        $stmt->execute([
            $_POST['event_title'],
            $_POST['event_location'],
            $_POST['event_date'],
            $_POST['event_host'],
            $_POST['event_host_contact'],
            $_POST['event_participant_number'],
            $_POST['event_deal_amount'],
            $contract_json,
            $_SESSION['user_id']
        ]);

        echo "Event added successfully.";
    }
}
?>
