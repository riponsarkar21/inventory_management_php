<?php
// modules/event/event_fetch.php
// event_management 3.7.6
// 10.08.2025

include('../../database_connection.php');

$query = "SELECT * FROM event ORDER BY id DESC";
$stmt = $connect->prepare($query);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

$data = ['data' => $result];
echo json_encode($data);
