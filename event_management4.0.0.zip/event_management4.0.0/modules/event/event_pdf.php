<?php
// require_once 'dompdf/vendor/autoload.php';
require __DIR__ . '/../../dompdf/vendor/autoload.php';

include('../../database_connection.php');


use Dompdf\Dompdf;

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die('Event ID not specified.');
}

$event_id = intval($_GET['id']);

// Fetch event data
$stmt = $connect->prepare("SELECT * FROM event WHERE id = ?");
$stmt->execute([$event_id]);
$event = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$event) {
    die('Event not found.');
}

// Decode contract details JSON
$contractDetails = json_decode($event['event_deal_contract_details'], true);
if (!is_array($contractDetails)) {
    $contractDetails = [];
}

// Simple mapping for contract detail labels (optional)
$contractLabels = [
    "gift_id" => "Gift ID",
    "created_by" => "Created By",
    "user_id" => "User ID",
    "guest_name" => "Guest Name",
    "phone" => "Phone",
    "address" => "Address",
    "relation" => "Relation",
    "gift_type" => "Gift Type",
    "amount" => "Amount",
    "payment_method" => "Payment Method",
    "gift_details" => "Gift Details",
    "gift_image" => "Gift Image"
];

// Build contract details HTML list
$contractHtml = '<ul>';
foreach ($contractDetails as $detail) {
    $label = $contractLabels[$detail] ?? ucfirst(str_replace('_', ' ', $detail));
    $contractHtml .= '<li>' . htmlspecialchars($label) . '</li>';
}
$contractHtml .= '</ul>';

// Build full HTML for PDF
$html = '
<h1>Event Deal Details</h1>
<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%;">
    <tr><th>Title</th><td>' . htmlspecialchars($event['event_title']) . '</td></tr>
    <tr><th>Location</th><td>' . htmlspecialchars($event['event_location']) . '</td></tr>
    <tr><th>Date</th><td>' . htmlspecialchars($event['event_date']) . '</td></tr>
    <tr><th>Host</th><td>' . htmlspecialchars($event['event_host']) . '</td></tr>
    <tr><th>Host Contact</th><td>' . htmlspecialchars($event['event_host_contact']) . '</td></tr>
    <tr><th>Participants</th><td>' . htmlspecialchars($event['event_participant_number']) . '</td></tr>
    <tr><th>Deal Amount</th><td>' . htmlspecialchars($event['event_deal_amount']) . '</td></tr>
    <tr><th>Contract Details</th><td>' . $contractHtml . '</td></tr>
</table>
';

// Initialize Dompdf
$dompdf = new Dompdf();
$dompdf->loadHtml($html);

// (Optional) Setup paper size and orientation
$dompdf->setPaper('A4', 'portrait');

// Render PDF
$dompdf->render();

// Output PDF to browser inline
$dompdf->stream("event_deal_{$event_id}.pdf", ["Attachment" => false]);
exit;
?>
