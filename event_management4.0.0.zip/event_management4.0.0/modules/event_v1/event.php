<?php
// modules/event/event.php
// 10.08.2025 v1



if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!in_array($_SESSION['type'], ['Super Master', 'Master', 'Event Admin', 'Gift Admin', 'Event User'])) {
    header('location:' . (!isset($_SESSION['type']) ? '../../login.php' : '../../index.php'));
    exit;
}

include('../../database_connection.php');
include('../../header.php');
?>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
<link rel="stylesheet" href="../../css/datepicker.css">

<span id="alert_action"></span>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading clearfix">
                <div class="pull-left">
                    <h3 class="panel-title">Event List</h3>
                </div>
                <div class="pull-right">
                    <button type="button" id="add_button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#eventModal">Add Event</button>
                </div>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table id="event_data" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Location</th>
                                <th>Date</th>
                                <th>Host</th>
                                <th>Contact</th>
                                <th>Participants</th>
                                <th>Deal Amount</th>
                                <th>Status</th>
                                <th>Update</th>
                                <th>Change Status</th>
                                <th>Cancel</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="eventModal" class="modal fade">
    <div class="modal-dialog modal-lg">
        <form method="post" id="event_form">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add Event</h4>
                </div>
          <div class="modal-body">
                <input type="hidden" name="id" id="id">

                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="event_title" id="event_title" class="form-control" required>
                </div>

                <div class="form-group">
                    <label>Location</label>
                    <input type="text" name="event_location" id="event_location" class="form-control" required>
                </div>

                <div class="form-group">
                    <label>Date</label>
                    <input type="date" name="event_date" id="event_date" class="form-control" required>
                </div>

                <div class="form-group">
                    <label>Host</label>
                    <input type="text" name="event_host" id="event_host" class="form-control" required>
                </div>

                <div class="form-group">
                    <label>Host Contact</label>
                    <input type="text" name="event_host_contact" id="event_host_contact" class="form-control">
                </div>

                <div class="form-group">
                    <label>Participants</label>
                    <input type="number" name="event_participant_number" id="event_participant_number" class="form-control">
                </div>

                <div class="form-group">
                    <label>Deal Amount</label>
                    <input type="number" name="event_deal_amount" id="event_deal_amount" class="form-control">
                </div>

                <h4>Contract Details</h4>
                <?php
                    $checkbox_fields = [
                        "gift_id"        => "Gift ID",
                        "created_by"     => "Created By",
                        "user_id"        => "User ID",
                        "guest_name"     => "Guest Name",
                        "phone"          => "Phone",
                        "address"        => "Address",
                        "relation"       => "Relation",
                        "gift_type"      => "Gift Type",
                        "amount"         => "Amount",
                        "payment_method" => "Payment Method",
                        "gift_details"   => "Gift Details",
                        "gift_image"     => "Gift Image"
                    ];
                    foreach ($checkbox_fields as $field_key => $field_label) {
                        echo '<div class="form-check">
                                <input class="form-check-input" type="checkbox" name="contract_details[]" value="' . $field_key . '" id="' . $field_key . '">
                                <label class="form-check-label" for="' . $field_key . '">' . $field_label . '</label>
                            </div>';
                    }
                ?>
            </div>

                <div class="modal-footer">
                    <input type="submit" name="action" id="action" class="btn btn-info" value="Add" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap.min.js"></script>

<script>
$(document).ready(function(){
    const table = $('#event_data').DataTable({
        "ajax": "event_fetch.php",
        "order": [[0, "desc"]],
        "columns": [
            { "data": "id" },
            { "data": "event_title" },
            { "data": "event_location" },
            { "data": "event_date" },
            { "data": "event_host" },
            { "data": "event_host_contact" },
            { "data": "event_participant_number" },
            { "data": "event_deal_amount" },
            {
                "data": "status",
                "render": function(data) {
                    let colorClass = '';
                    switch (data.toLowerCase()) {
                        case 'active': colorClass = 'label label-success'; break;
                        case 'inactive': colorClass = 'label label-warning'; break;
                        case 'cancelled': colorClass = 'label label-danger'; break;
                        default: colorClass = 'label label-default';
                    }
                    return `<span class="${colorClass}">${data}</span>`;
                }
            },
            { "data": null, "render": row => `<button class="btn btn-primary btn-xs update-entry" data-id="${row.id}">Update</button>` },
            { "data": null, "render": row => `<button class="btn btn-info btn-xs change-status" data-id="${row.id}">Change Status</button>` },
            { "data": null, "render": row => `<button class="btn btn-warning btn-xs cancel-entry" data-id="${row.id}">Cancel</button>` },
            { "data": null, "render": row => `<button class="btn btn-danger btn-xs delete" data-id="${row.id}">Delete</button>` }
        ],        "lengthMenu": [[5, 10, 25, 50], [5, 10, 25, 50]],
        "pageLength": 10,
        "dom":
            "<'row'<'col-sm-6'l><'col-sm-6'f>>" +
            "<'row'<'col-sm-12'tr>>" +
            "<'row'<'col-sm-5'i><'col-sm-7'p>>" +
            "<'row'<'col-sm-12 text-center mt-3'B>>",
        "buttons": ['copy', 'csv', 'excel', 'pdf', 'print']
    });

    $('#event_form').on('submit', function(e){
        e.preventDefault();
        const formData = $(this).serialize();
        $.post("event_action.php", formData, function(data){
            $('#event_form')[0].reset();
            $('#eventModal').modal('hide');
            $('#alert_action').html('<div class="alert alert-success">'+data+'</div>');
            table.ajax.reload();
            $('#action').val('Add');
            $('#id').val('');
        });
    });

    $(document).on('click', '.delete', function(){
        if(confirm("Delete this event?")) {
            $.post("event_action.php", { action: "delete", id: $(this).data('id') }, function(data){
                $('#alert_action').html('<div class="alert alert-danger">'+data+'</div>');
                table.ajax.reload();
            });
        }
    });

    $(document).on('click', '.change-status', function(){
        $.post("event_action.php", { action: "change_status", id: $(this).data('id') }, function(data){
            $('#alert_action').html('<div class="alert alert-info">'+data+'</div>');
            table.ajax.reload();
        });
    });

    $(document).on('click', '.cancel-entry', function(){
        if (confirm("Cancel this event?")) {
            $.post("event_action.php", { action: "cancel", id: $(this).data('id') }, function(data){
                $('#alert_action').html('<div class="alert alert-warning">'+data+'</div>');
                table.ajax.reload();
            });
        }
    });

    $(document).on('click', '.update-entry', function(){
        $.post("event_action.php", { action: "fetch_single", id: $(this).data('id') }, function(data){
            const d = JSON.parse(data);
            $('#id').val(d.id);
            $('#event_title').val(d.event_title);
            $('#event_location').val(d.event_location);
            $('#event_date').val(d.event_date);
            $('#event_host').val(d.event_host);
            $('#event_host_contact').val(d.event_host_contact);
            $('#event_participant_number').val(d.event_participant_number);
            $('#event_deal_amount').val(d.event_deal_amount);

            // Clear all checkboxes first
            $('input[name="contract_details[]"]').prop('checked', false);

            // Parse contract details JSON, check checkboxes
            const contractDetails = JSON.parse(d.event_deal_contract_details || '[]');
            contractDetails.forEach(function(key) {
                $('input[name="contract_details[]"][value="' + key + '"]').prop('checked', true);
            });

            $('#action').val('Update');
            $('#eventModal').modal('show');
        });
    });

});
</script>

<?php include('../../footer.php'); ?>
