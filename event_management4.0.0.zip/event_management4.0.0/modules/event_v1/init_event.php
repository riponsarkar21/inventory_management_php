<?php
// init_event.php
// event_management 3.7.6
// 10.08.2025



// Run this script once to initialize the `event` table

include('../../database_connection.php');

$query = "
CREATE TABLE `event` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `event_title` VARCHAR(255) NOT NULL,
  `event_location` VARCHAR(255) NOT NULL,
  `event_date` DATE NOT NULL,
  `event_host` VARCHAR(255) NOT NULL,
  `event_host_contact` VARCHAR(50) DEFAULT NULL,
  `event_participant_number` INT(11) DEFAULT NULL,
  `event_deal_amount` DECIMAL(10,2) DEFAULT NULL,
  `event_deal_contract_details` JSON DEFAULT NULL,
  `gift_id` INT(11) DEFAULT NULL,
  `user_id` INT(11) DEFAULT NULL,
  `status` ENUM('Active','Inactive','Cancelled') DEFAULT 'Active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `created_by` INT(11) DEFAULT NULL,
  `updated_at` DATETIME DEFAULT NULL,
  `updated_by` INT(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


";

if ($connect->query($query)) {
    echo "✅ 'event' table created successfully.";
} else {
    echo "❌ Error creating table: " . $connect->errorInfo()[2];
}
?>
