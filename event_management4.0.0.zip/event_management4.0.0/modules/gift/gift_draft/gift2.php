<?php
// modules/gift/gift.php

include('../../database_connection.php');
include('../../header.php');
?>

<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
<link rel="stylesheet" href="../../css/datepicker.css">

<span id="alert_action"></span>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading clearfix">
                <div class="pull-left">
                    <h3 class="panel-title">Gift / Cash Received List</h3>
                </div>
                <div class="pull-right">
                    <button type="button" id="add_button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#giftModal">Add Entry</button>
                </div>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table id="gift_data" class="table table-bordered table-striped w-100">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Guest Name</th>
                                <th>Phone</th>
                                <th>Type</th>
                                <th>Amount</th>
                                <th>Gift</th>
                                <th>Image</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="giftModal" class="modal fade">
    <div class="modal-dialog modal-lg">
        <form method="post" id="gift_form" enctype="multipart/form-data">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add Gift / Cash Entry</h4>
                </div>
                <div class="modal-body">
                    <!-- ... same modal form content ... -->
                </div>
                <div class="modal-footer">
                    <input type="submit" name="action" id="action" class="btn btn-info" value="Add" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap.min.js"></script>

<script>
$(document).ready(function(){
    const table = $('#gift_data').DataTable({
        "ajax": "../../modules/gift/gift_fetch.php",
        "scrollX": true,
        "columns": [
            { "data": "gift_id" },
            { "data": "guest_name" },
            { "data": "phone" },
            { "data": "gift_type" },
            { "data": "amount" },
            { "data": "gift_details" },
            {
                "data": "gift_image",
                "render": function(data) {
                    return data ? `<img src="${data}" height="50">` : '';
                }
            },
            { "data": "status" },
            {
                "data": null,
                "orderable": false,
                "render": function(row) {
                    return `
                        <button class="btn btn-info btn-xs change-status" data-id="${row.gift_id}">Status</button>
                        <button class="btn btn-primary btn-xs update-entry" data-id="${row.gift_id}">Update</button>
                        <button class="btn btn-default btn-xs generate-pdf" data-id="${row.gift_id}">PDF</button>
                        <button class="btn btn-warning btn-xs cancel-entry" data-id="${row.gift_id}">Cancel</button>
                        <button class="btn btn-danger btn-xs delete" data-id="${row.gift_id}">Delete</button>
                    `;
                }
            }
        ],
        "lengthMenu": [[5, 10, 25, 50], [5, 10, 25, 50]],
        "pageLength": 10,
        "dom": "<'row'<'col-sm-6'l><'col-sm-6'f>>" +
               "<'row'<'col-sm-12'tr>>" +
               "<'row'<'col-sm-5'i><'col-sm-7'p>>" +
               "<'row'<'col-sm-12 text-center mt-3'B>>",
        "buttons": ['copy', 'csv', 'excel', 'pdf', 'print']
    });

    function toggleSections() {
        const type = $('#gift_type').val();
        $('.conditional-section').hide();
        if (type === 'money') $('#money_section').show();
        else if (type === 'gift') $('#gift_section').show();
        else { $('#money_section, #gift_section').show(); }
    }

    $('#gift_type').change(toggleSections);
    toggleSections();

    $('#gift_form').on('submit', function(e){
        e.preventDefault();
        const formData = new FormData(this);
        $.ajax({
            url: "../../modules/gift/gift_action.php",
            method: "POST",
            data: formData,
            contentType: false,
            processData: false,
            success: function(data){
                $('#gift_form')[0].reset();
                $('#giftModal').modal('hide');
                $('#alert_action').html('<div class="alert alert-success">'+data+'</div>');
                table.ajax.reload();
                $('#action').val('Add');
                $('#gift_id').val('');
            }
        });
    });

    $(document).on('click', '.delete', function(){
        if(confirm("Are you sure you want to delete this entry?")) {
            const id = $(this).data('id');
            $.post("../../modules/gift/gift_action.php", { action: "delete", id: id }, function(data){
                $('#alert_action').html('<div class="alert alert-danger">'+data+'</div>');
                table.ajax.reload();
            });
        }
    });

    $(document).on('click', '.change-status', function(){
        const id = $(this).data('id');
        $.post("../../modules/gift/gift_action.php", { action: "change_status", id: id }, function(data){
            $('#alert_action').html('<div class="alert alert-info">'+data+'</div>');
            table.ajax.reload();
        });
    });

    $(document).on('click', '.cancel-entry', function(){
        const id = $(this).data('id');
        if (confirm("Are you sure you want to cancel this entry? This action will mark it as 'Cancelled'.")) {
            $.post("../../modules/gift/gift_action.php", { action: "cancel", id: id }, function(data){
                $('#alert_action').html('<div class="alert alert-warning">'+data+'</div>');
                table.ajax.reload();
            });
        }
    });

    $(document).on('click', '.generate-pdf', function(){
        const id = $(this).data('id');
        window.open("../../modules/gift/gift_pdf.php?id=" + id, '_blank');
    });

    $(document).on('click', '.update-entry', function(){
        const id = $(this).data('id');
        $.post("../../modules/gift/gift_action.php", { action: "fetch_single", id: id }, function(data){
            const d = JSON.parse(data);
            $('#gift_id').val(d.gift_id);
            $('#guest_name').val(d.guest_name);
            $('#phone').val(d.phone);
            $('#address').val(d.address);
            $('#relation').val(d.relation);
            $('#gift_type').val(d.gift_type).change();
            $('#amount').val(d.amount);
            $('#payment_method').val(d.payment_method);
            $('#gift_details').val(d.gift_details);
            $('#action').val('Update');
            $('#giftModal').modal('show');
        });
    });
});
</script>

<?php include('../../footer.php'); ?>