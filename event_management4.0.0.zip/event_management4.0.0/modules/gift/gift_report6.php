<?php
// 29.07.2025 v6: 
// 

// show column created by
// filter by user 
// column sorting problem solve
// show number of row
// set value extend to 1000 row
// image set into center

// 27.07.2025 v5: 
// v1: the image thumb show every row
// v2: image show only available with a goodlooking border
// v3: use checkbox to show columns
// v4: use master checkbox to select all column
// v5: Create all data download button


?>


<?php
include('../../database_connection.php');
include('../../header.php');

$query = "SELECT user_id, user_name FROM user_details WHERE user_type IN ('Gift User','Gift Admin')";
$stmt = $connect->prepare($query);
$stmt->execute();
$users = $stmt->fetchAll();
?>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">

<div class="container-fluid mt-4">
  <h3 class="mb-3">Gift Report</h3>
  <!-- Filter Panel -->
  <div class="row mb-3">
    <div class="col-md-2">
      <input type="date" id="from_date" class="form-control" placeholder="From Date">
    </div>
    <div class="col-md-2">
      <input type="date" id="to_date" class="form-control" placeholder="To Date">
    </div>
    <div class="col-md-1">
      <select id="gift_type" class="form-control">
        <option value="">All Types</option>
        <option value="money">Money</option>
        <option value="gift">Gift</option>
        <option value="both">Both</option>
      </select>
    </div>
    <div class="col-md-1">
      <select id="status" class="form-control">
        <option value="">All Status</option>
        <option value="received">Received</option>
        <option value="pending">Pending</option>
        <option value="cancelled">Cancelled</option>
      </select>
    </div>
    <div class="col-md-2">
      <select id="filter_user" class="form-control">
        <option value="">All Users</option>
        <?php foreach ($users as $u): ?>
          <option value="<?= $u['user_id'] ?>">
            <?= htmlspecialchars($u['user_name']) ?> (ID <?= $u['user_id'] ?>)
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3">
      <input type="text" id="search_text" class="form-control" placeholder="Guest Name or Phone">
    </div>
    <div class="col-md-1">
      <button class="btn btn-primary w-100" id="filter_btn">Filter</button>
    </div>
  </div>

  <!-- Column Selection & Download -->
  <div class="row mb-4 p-3 rounded shadow-sm" style="background-color:#f4f8ff;border:1px solid #d6e0f5;">
    <div class="col-md-8 mb-3 mb-md-0">
      <h6 class="fw-bold mb-2">🎛️ Select Columns to Show:</h6>
      <div class="d-flex flex-wrap align-items-center">
        <label class="form-check-label me-4">
          <input type="checkbox" id="toggle-all-columns" class="form-check-input me-1" checked>
          <strong>Select All</strong>
        </label>
        <?php
        $cols = ['Guest','Phone','Relation','Gift Type','Amount','Gift Details','Image','Status','Created At','Created By'];
        foreach ($cols as $i => $lbl):
        ?>
          <label class="form-check-label me-3">
            <input type="checkbox" class="form-check-input col-toggle" data-column="<?= $i+1 ?>" checked> <?= $lbl ?>
          </label>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="col-md-4 d-flex flex-column align-items-center justify-content-center">
      <h6 class="fw-bold mb-2">⬇️ Download Full Report:</h6>
      <a href="gift_report_download_xlsx.php?type=excel" target="_blank" class="btn btn-success btn-sm me-2 mb-2">📥 Excel</a>
      <a href="gift_report_download_pdf.php?type=pdf" target="_blank" class="btn btn-danger btn-sm mb-2">📄 PDF</a>
    </div>
  </div>

  <!-- Table -->
  <div class="panel-body">
    <div class="table-responsive">
      <table id="gift_report_table" class="table table-bordered table-striped nowrap" width="100%">
        <thead>
          <tr>
            <th>ID</th>
            <th>Guest</th>
            <th>Phone</th>
            <th>Relation</th>
            <th>Gift Type</th>
            <th>Amount</th>
            <th>Gift Details</th>
            <th>Image</th>
            <th>Status</th>
            <th>Created At</th>
            <th>Created By</th>
            <th>Actions</th>
          </tr>
        </thead>
      </table>
    </div>
  </div>
</div>

<!-- JS includes -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>

<script>
$(document).ready(function() {
  function load_data(from_date = '', to_date = '', gift_type = '', status = '', filter_user = '', search_text = '') {
    $('#gift_report_table').DataTable({
  destroy: true,
  processing: true,
  serverSide: true,
  order: [[0, 'desc']],
  ajax: {
    url: 'gift_report_fetch2.php',
    type: 'POST',
    data: { from_date, to_date, gift_type, status, filter_user, search_text }
  },
  lengthMenu: [[5, 10, 25, 50, 100, 1000], [5, 10, 25, 50, 100, 1000]],
  pageLength: 10,
  dom: 'Blfrtip', // <- ✅ updated here
  buttons: ['copy', 'excel', 'pdf', 'print'],
  columns: [
    { data: 'gift_id' },
    { data: 'guest_name' },
    { data: 'phone' },
    { data: 'relation' },
    { data: 'gift_type' },
    { data: 'amount' },
    { data: 'gift_details' },
    // {
    //   data: 'gift_image',
    //   render: d => d ? `<img src="../../${d}" width="40" class="img-thumbnail" style = "margin-left:10px;"/>` : ''
    // },
    {
        data: 'gift_image',
        className: 'text-center align-middle', // Optional, helps bootstrap-based centering
        render: d => d 
            ? `<div style="display:flex; justify-content:center; align-items:center; height:100%;">
                <img src="../../${d}" width="40" class="img-thumbnail"/>
            </div>`
            : ''
        },

    { data: 'status' },
    { data: 'created_at' },
    {
      data: null,
      render: (d, t, row) => row.user_name ? `${row.user_name} (ID ${row.user_id})` : '<span class="text-muted">Unknown</span>'
    },
    {
      data: 'gift_id',
      orderable: false, // ✅ disable sorting for this column
      render: id => `
        <a href="gift_ticket_pdf.php?id=${id}" class="btn btn-sm btn-secondary">PDF</a>
        <a href="gift_view.php?id=${id}" class="btn btn-sm btn-info">View</a>
        <a href="gift_edit.php?id=${id}" class="btn btn-sm btn-warning">Edit</a>`
    }
  ]
});
  }

  $('#toggle-all-columns').change(function(){
    const checked = this.checked;
    $('.col-toggle').prop('checked', checked).trigger('change');
  });

  $(document).on('change', '.col-toggle', function(){
    const col = $('#gift_report_table').DataTable().column($(this).data('column'));
    col.visible(this.checked);
    $('#toggle-all-columns').prop('checked', $('.col-toggle').length === $('.col-toggle:checked').length);
  });

  load_data();

  $('#filter_btn').click(function(){
    load_data(
      $('#from_date').val(),
      $('#to_date').val(),
      $('#gift_type').val(),
      $('#status').val(),
      $('#filter_user').val(),
      $('#search_text').val()
    );
  });
});
</script>
