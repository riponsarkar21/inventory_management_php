<?php
include('../../database_connection.php'); // ensures PDO $connect
header('Content-Type: application/json');

// DataTables params
$draw = intval($_POST['draw'] ?? 0);
$start = intval($_POST['start'] ?? 0);
$length = intval($_POST['length'] ?? 10);
$orderColIndex = $_POST['order'][0]['column'] ?? 0;
$orderColName = $_POST['columns'][$orderColIndex]['data'] ?? 'gift_id';
$orderDir = $_POST['order'][0]['dir'] ?? 'desc';

// Filters & search
$from_date = $_POST['from_date'] ?? '';
$to_date = $_POST['to_date'] ?? '';
$gift_type = $_POST['gift_type'] ?? '';
$status = $_POST['status'] ?? '';
$filter_user = $_POST['filter_user'] ?? '';
$search_text = $_POST['search_text'] ?? '';

$where = ' WHERE 1=1 ';
$params = [];

if ($from_date && $to_date) {
    $where .= " AND DATE(g.created_at) BETWEEN :from_date AND :to_date";
    $params[':from_date'] = $from_date;
    $params[':to_date'] = $to_date;
}
if ($gift_type) {
    $where .= " AND g.gift_type = :gift_type";
    $params[':gift_type'] = $gift_type;
}
if ($status) {
    $where .= " AND g.status = :status";
    $params[':status'] = $status;
}
if ($filter_user) {
    $where .= " AND g.user_id = :filter_user";
    $params[':filter_user'] = $filter_user;
}
if ($search_text) {
    $where .= " AND (g.guest_name LIKE :search_text OR g.phone LIKE :search_text)";
    $params[':search_text'] = '%' . $search_text . '%';
}

// Total counts
$totalStmt = $connect->prepare("SELECT COUNT(*) FROM gift");
$totalStmt->execute();
$totalRecords = $totalStmt->fetchColumn();

$filteredStmt = $connect->prepare("SELECT COUNT(*) FROM gift g $where");
$filteredStmt->execute($params);
$totalFiltered = $filteredStmt->fetchColumn();

// Get data with join user_details for user_name
$sql = "SELECT g.*, u.user_name
        FROM gift g
        LEFT JOIN user_details u ON g.user_id = u.user_id
        $where
        ORDER BY $orderColName $orderDir
        LIMIT :start, :length";

$stmt = $connect->prepare($sql);
foreach ($params as $k => $v) {
    $stmt->bindValue($k, $v);
}
$stmt->bindValue(':start', $start, PDO::PARAM_INT);
$stmt->bindValue(':length', $length, PDO::PARAM_INT);
$stmt->execute();

$data = [];
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $data[] = [
        'gift_id' => $row['gift_id'],
        'guest_name' => htmlspecialchars($row['guest_name']),
        'phone' => htmlspecialchars($row['phone']),
        'relation' => htmlspecialchars($row['relation']),
        'gift_type' => ucfirst($row['gift_type']),
        'amount' => $row['amount'],
        'gift_details' => htmlspecialchars($row['gift_details']),
        'gift_image' => $row['gift_image'],
        'status' => ucfirst($row['status']),
        'created_at' => date("d-M-Y h:i A", strtotime($row['created_at'])),
        'user_id' => $row['user_id'],
        'user_name' => $row['user_name'] ?? 'Unknown'
    ];
}

echo json_encode([
    "draw" => $draw,
    "iTotalRecords" => $totalRecords,
    "iTotalDisplayRecords" => $totalFiltered,
    "aaData" => $data
]);
