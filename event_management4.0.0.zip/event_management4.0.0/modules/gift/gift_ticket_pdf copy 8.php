<?php
// modules/gift/gift_ticket_pdf.php
// Final version: 25/07/2025 – Creates QR code using PHP QR library
// Final version: 25/07/2025 – Show more information,


ob_start(); // Start output buffering to prevent accidental output

require __DIR__ . '/../../dompdf/vendor/autoload.php';
require __DIR__ . '/../../database_connection.php';
require __DIR__ . '/test_function.php';
require __DIR__ . '/lib/phpqrcode/qrlib.php'; // ✅ Load the QR library

use Dompdf\Dompdf;
use Dompdf\Options;

session_start();

if (!isset($_GET['id']) || empty($_GET['id'])) {
    exit('Invalid Gift ID');
}

$id = intval($_GET['id']);
$stmt = $connect->prepare("SELECT * FROM gift WHERE gift_id = ?");
$stmt->execute([$id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    exit('No gift entry found');
}

$receiverName = isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name']) : 'Receiver';

// ✅ QR Code generation using PHP QR Code library
// $qrText = "Event: Annual Function\n";
// $qrText .= "Gift ID: {$row['gift_id']}\n";
// $qrText .= "Name: {$row['guest_name']}\n";
// $qrText .= "Phone: {$row['phone']}\n";
// // $qrText .= "Type: {$row['gift_type']}\n";
// $qrText .= "Gift Details: {$row['gift_details']}\n";
// $qrText .= "Amount: {$row['amount']} Taka\n";
// $qrText .= "View more: \nhttp://riponsarkartest1-001-site1.anytempurl.com/modules/gift/gift_ticket_pdf.php?id={$row['gift_id']}";

$qrText = "Event: Annual Function\n";
$qrText .= "Gift ID: {$row['gift_id']}\n";
$qrText .= "Name: {$row['guest_name']}\n";
$qrText .= "Phone: {$row['phone']}\n";
$qrText .= "Type: {$row['gift_type']}\n";

// Conditionally add Gift Details and/or Amount
if ($row['gift_type'] === 'gift') {
    $qrText .= "Gift Details: {$row['gift_details']}\n";
} elseif ($row['gift_type'] === 'money') {
    $qrText .= "Amount: {$row['amount']} Taka\n";
} elseif ($row['gift_type'] === 'both') {
    $qrText .= "Gift Details: {$row['gift_details']} & \nAmount: {$row['amount']} Taka\n";
}

$qrText .= "View more: \nhttp://riponsarkartest1-001-site1.anytempurl.com/modules/gift/gift_ticket_pdf.php?id={$row['gift_id']}";



ob_start();
QRcode::png($qrText, null, QR_ECLEVEL_L, 3); // Output to buffer
$imageData = ob_get_clean();
$qrBase64 = base64_encode($imageData);
$qrImageSrc = 'data:image/png;base64,' . $qrBase64;

// Dompdf setup
$options = new Options();
$options->set('isRemoteEnabled', true);
$options->set('defaultFont', 'DejaVu Sans');

$dompdf = new Dompdf($options);
$customPaper = [0, 0, 216, 365]; // 57mm x 130mm

// Prepare variables
$amount = floatval($row['amount']);
$giftType = strtolower($row['gift_type']);
$giftDetails = htmlspecialchars($row['gift_details'] ?? '');

$html = '
<style>
    body {
        font-family: DejaVu Sans, sans-serif;
        font-size: 10px;
        margin: -30px -15px -50px -30px;
        padding: 0;
    }
    .wrapper {
        width: 100%;
        padding: 6px;
        box-sizing: border-box;
        border: 1px dashed #000;
    }
    .header {
        text-align: center;
        font-weight: bold;
        font-size: 11px;
        margin-bottom: 4px;
    }
    .qr {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        margin: 6px auto;
        width: 120px;
        height: 110px;
        text-align: center;
    }
    .qr-img {
        width: 100px;
        height: 100px;
        justify-self: center;
    }
    .gift-verify {
        text-align: center;
        font-size: 8px;
        margin-top: -5px;
    }


    .section {
        margin: 3px 0;
        line-height: 1.4em;
    }
    .section-amount {
        margin: 3px 0;
        line-height: 1.4em;
        height: 60px;
    }
    .label {
        font-weight: regular;
    }
    .data {
        font-weight: bold;
    }
    .signature {
        text-align: right;
        margin-top: 15px;
    }
    .signature-username {
        margin-bottom:-14px;
    }
    .footer {
        text-align: center;
        font-size: 8.5px;
        margin-top: 8px;
    }
    .cut-line {
        margin-top: 10px;
        margin-left: 10px;
        text-align: center;
        font-size: 1em;
        position: relative;
    }
    .cut-line span {
        font-size: 10px;
    }
</style>

<div class="wrapper">
    <div class="header">
        HASAN Wedding CEREMONY<br>
        Bagerhat Sadar, Bagerhat
    </div>

    <div class="qr">
        <img src="' . $qrImageSrc . '" class="qr-img" >
        <div class="gift-verify">
            <a href="http://localhost/test3/modules/gift/gift_ticket_pdf.php?id=' . $row['gift_id'] . '">
                Online Gift Verification
            </a>
        </div>
    </div>


    <div class="section">
        <span class="label">Date:</span> <span class="data">' . date('d/m/Y', strtotime($row['created_at'])) . '</span><br>
        <span class="label">Time:</span> ' . date('h:i A', strtotime($row['created_at'])) . '<br>
        <span class="label">Gift ID:</span> <span class="data">' . htmlspecialchars($row['gift_id']) . '</span>
    </div>

    <div class="section">
        <span class="label">Name:</span> <span class="data">' . htmlspecialchars($row['guest_name']) . '</span><br>
        <span class="label">Address:</span> ' . htmlspecialchars($row['address']) . '<br>
        <span class="label">Relation:</span> ' . htmlspecialchars($row['relation']) . '
    </div>

    <div class="section-amount">';

if ($giftType === 'gift') {
    $html .= '
        <span class="label">Gift Details:</span> <span class="data">' . $giftDetails . '</span><br>';
} elseif ($giftType === 'money' && $amount > 0) {
    $html .= '
        <span class="label">Amount:</span> <span class="data">' . htmlspecialchars($amount) . '</span> Taka<br>
        <span class="label">In Words:</span> ' . convertToWords($amount) . '<br>';
} elseif ($giftType === 'both') {
    $html .= '
        <span class="label">Gift Details:</span> <span class="data">' . $giftDetails . '</span> &<br>';
    if ($amount > 0) {
        $html .= '
        <span class="label">Amount:</span> <span class="data">' . htmlspecialchars($amount) . '</span> Taka<br>
        <span class="label">In Words:</span> ' . convertToWords($amount) . '<br>';
    }
}

$html .= '</div>

    <div class="signature">
        <div class="signature-username">
            <strong>' . $receiverName . '</strong><br>
        </div>
        ____________________<br>
        Receiver Signature<br>
    </div>

    <div class="footer">
        <strong>Thank you for your kind gift.</strong><br>
        Printed by:<br>
        Ripon Sarkar Digital Service, 01928-078420
    </div>
</div>

<div class="cut-line"> 
    -✂--------------------- Tear Here ------------------------ 
</div>
';

$htmlOutput = ob_get_clean(); // Clear buffer and capture any output before PDF render

$dompdf->setPaper($customPaper);
$dompdf->loadHtml($html);
$dompdf->render();
$dompdf->stream("gift_ticket_{$id}.pdf", ["Attachment" => false]);
exit;
