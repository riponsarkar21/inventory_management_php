<?php
// modules/gift/gift_ticket_pdf.php

require __DIR__ . '/../../dompdf/vendor/autoload.php';
include(__DIR__ . '/../../database_connection.php');
require __DIR__ . '/test_function.php';

use Dompdf\Dompdf;
use Dompdf\Options;

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die('Invalid Gift ID');
}

$id = intval($_GET['id']);
$stmt = $connect->prepare("SELECT * FROM gift WHERE gift_id = ?");
$stmt->execute([$id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    die('No gift entry found');
}

// QR Code generation
$qrText = "Gift ID: {$row['gift_id']} | Name: {$row['guest_name']}";
$qrImagePath = 'temp_qr.png';
file_put_contents($qrImagePath, file_get_contents('https://api.qrserver.com/v1/create-qr-code/?data=' . urlencode($qrText) . '&size=100x100'));

// Dompdf Setup
$options = new Options();
$options->set('isRemoteEnabled', true);
$options->set('defaultFont', 'DejaVu Sans');

$dompdf = new Dompdf($options);
$customPaper = [0, 0, 216, 365]; // 57mm x 130mm


// Build HTML
$html = '
<style>
    body {
        font-family: DejaVu Sans, sans-serif;
        font-size: 10px;
        margin: -30px -15px -50px -30px;
        padding: 0;
    }
    .wrapper {
        width: 100%;
        padding: 6px;
        box-sizing: border-box;
        border: 1px dashed #000;
    }
    .header {
        text-align: center;
        font-weight: bold;
        font-size: 11px;
        margin-bottom: 4px;
    }
    .qr {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        margin: 6px auto;
        width: 90px;
        height: 110px;
    }
    .qr-img {
        width: 90px;
        height: 90px;
    }
    .gift_verify {
        text-align: center;
        font-size: 8px;
    }
    .section {
        margin: 3px 0;
        line-height: 1.4em;
    }
    .section-amount {
        margin: 3px 0;
        line-height: 1.4em;
        height: 60px;
    }
    .label {
        font-weight: regular;
    }
    .data {
        font-weight: bold;
    }
    .signature {
        text-align: right;
        margin-top: 15px;
    }
    .footer {
        text-align: center;
        font-size: 8.5px;
        margin-top: 8px;
    }
    .cut-line {
        margin-top: 10px;
        margin-left: 10px;
        text-align: center;
        font-size: 1em;
        position: relative;
    }
    .cut-line span {
        font-size: 10px;
    }
</style>

<div class="wrapper">
    <div class="header">
        HASAN Wedding CEREMONY<br>
        Bagerhat Sadar, Bagerhat
    </div>

    <div class="qr">
        <img src="' . $qrImagePath . '" class="qr-img" >
        <div class="gift_verify">Gift Verification</div>
    </div>

    <div class="section">
        <span class="label">Date:</span> <span class="data">' . date('d/m/Y', strtotime($row['created_at'])) . '</span><br>
        <span class="label">Time:</span> ' . date('h:i A', strtotime($row['created_at'])) . '<br>
        <span class="label">Gift ID:</span> <span class="data">' . htmlspecialchars($row['gift_id']) . '</span>
    </div>

    <div class="section">
        <span class="label">Name:</span> <span class="data">' . htmlspecialchars($row['guest_name']) . '</span><br>
        <span class="label">Address:</span> ' . htmlspecialchars($row['address']) . '<br>
        <span class="label">Relation:</span> ' . htmlspecialchars($row['relation']) . '
    </div>

    <div class="section-amount">
        <span class="label">Amount:</span> <span class="data">' . htmlspecialchars($row['amount']) . ' </span>Taka<br>
        <span class="label">In Words:</span> ' . convertToWords($row['amount']) . '
    </div>

    <div class="signature">
        ____________________<br>
        Receiver Signature
    </div>

    <div class="footer">
        <strong>Thank you for your kind gift.</strong><br>
        Printed by:<br>
        Ripon Sarkar Digital Service, 01928-078420
    </div>
</div>

<div class="cut-line"> 
    -✂--------------------- Tear Here ------------------------ 
</div>
';

$dompdf->setPaper($customPaper);
$dompdf->loadHtml($html);
$dompdf->render();
$dompdf->stream("gift_ticket_{$id}.pdf", ["Attachment" => false]);
exit;
