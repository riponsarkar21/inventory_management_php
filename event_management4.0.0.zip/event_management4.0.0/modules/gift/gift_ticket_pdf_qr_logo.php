<?php
// modules/gift/gift_ticket_pdf.php
// Final version: 25/07/2025 – Creates QR code using PHP QR library
// Final version: 25/07/2025 – Show more information,


ob_start(); // Start output buffering to prevent accidental output

require __DIR__ . '/../../dompdf/vendor/autoload.php';
require __DIR__ . '/../../database_connection.php';

// Fetch event data based on event_id parameter or default from settings
$event_id = isset($_GET['event_id']) ? intval($_GET['event_id']) : null;
$event_title = 'HASAN Wedding CEREMONY';
$event_location = 'Bagerhat Sadar, Bagerhat';

if ($event_id) {
    // Fetch specific event
    $stmt = $connect->prepare("SELECT event_title, event_location FROM event WHERE id = ?");
    $stmt->execute([$event_id]);
    $event = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($event) {
        $event_title = $event['event_title'];
        $event_location = $event['event_location'];
    }
} else {
    // Try to get default event from settings
    $stmt = $connect->prepare("SELECT setting_value FROM settings WHERE setting_key = 'default_event_id'");
    $stmt->execute();
    $default_event_id = $stmt->fetchColumn();
    
    if ($default_event_id) {
        $stmt = $connect->prepare("SELECT event_title, event_location FROM event WHERE id = ?");
        $stmt->execute([$default_event_id]);
        $event = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($event) {
            $event_title = $event['event_title'];
            $event_location = $event['event_location'];
        }
    }
}
require __DIR__ . '/test_function.php';
require __DIR__ . '/lib/phpqrcode/qrlib.php'; // ✅ Load the QR library

use Dompdf\Dompdf;
use Dompdf\Options;

session_start();

if (!isset($_GET['id']) || empty($_GET['id'])) {
    exit('Invalid Gift ID');
}

$id = intval($_GET['id']);
$stmt = $connect->prepare("SELECT * FROM gift WHERE gift_id = ?");
$stmt->execute([$id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    exit('No gift entry found');
}

$receiverName = isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name']) : 'Receiver';

// ✅ QR Code generation using PHP QR Code library
// $qrText = "Event: Annual Function\n";
// $qrText .= "Gift ID: {$row['gift_id']}\n";
// $qrText .= "Name: {$row['guest_name']}\n";
// $qrText .= "Phone: {$row['phone']}\n";
// // $qrText .= "Type: {$row['gift_type']}\n";
// $qrText .= "Gift Details: {$row['gift_details']}\n";
// $qrText .= "Amount: {$row['amount']} Taka\n";
// $qrText .= "View more: \nhttp://riponsarkartest1-001-site1.anytempurl.com/modules/gift/gift_ticket_pdf.php?id={$row['gift_id']}";

$qrText = "Event: " . $event_title . "\n";
$qrText .= "Gift ID: {$row['gift_id']}\n";
$qrText .= "Name: {$row['guest_name']}\n";
$qrText .= "Phone: {$row['phone']}\n";
$qrText .= "Type: {$row['gift_type']}\n";

// Conditionally add Gift Details and/or Amount
if ($row['gift_type'] === 'gift') {
    $qrText .= "Gift Details: {$row['gift_details']}\n";
} elseif ($row['gift_type'] === 'money') {
    $qrText .= "Amount: {$row['amount']} Taka\n";
} elseif ($row['gift_type'] === 'both') {
    $qrText .= "Gift Details: {$row['gift_details']} & \nAmount: {$row['amount']} Taka\n";
}

$qrText .= "View more: \nhttp://riponsarkartest1-001-site1.anytempurl.com/modules/gift/gift_ticket_pdf.php?id={$row['gift_id']}";



// ob_start();
// QRcode::png($qrText, null, QR_ECLEVEL_L, 3); // Output to buffer
// $imageData = ob_get_clean();
// $qrBase64 = base64_encode($imageData);
// $qrImageSrc = 'data:image/png;base64,' . $qrBase64;


// Generate QR code to a temp file
$tmpQRPath = __DIR__ . '/temp_qr.png';
QRcode::png($qrText, $tmpQRPath, QR_ECLEVEL_H, 6); // higher error correction & size

// Load the QR and logo images
$qrImage = imagecreatefrompng($tmpQRPath);
$logoPath = __DIR__ . '/images/logo_qr.png'; // your logo path
if (file_exists($logoPath)) {
    $logo = imagecreatefrompng($logoPath);

    // Get dimensions
    $qrWidth = imagesx($qrImage);
    $qrHeight = imagesy($qrImage);
    $logoWidth = imagesx($logo);
    $logoHeight = imagesy($logo);

    // Resize logo to 25% of QR code size
    $logoQRWidth = $qrWidth / 3.5;
    $scale = $logoWidth / $logoQRWidth;
    $logoQRHeight = $logoHeight / $scale;

    // Calculate placement
    $logoX = ($qrWidth - $logoQRWidth) / 2;
    $logoY = ($qrHeight - $logoQRHeight) / 2;

    // Create true color temp image & copy resized logo onto QR
    imagecopyresampled($qrImage, $logo, $logoX, $logoY, 0, 0, $logoQRWidth, $logoQRHeight, $logoWidth, $logoHeight);
}

// Output merged image to buffer
ob_start();
imagepng($qrImage);
$imageData = ob_get_clean();

// Clean up temp files and memory
imagedestroy($qrImage);
if (isset($logo)) {
    imagedestroy($logo);
}
if (file_exists($tmpQRPath)) {
    unlink($tmpQRPath);
}

// Convert to base64 for embedding in HTML
$qrBase64 = base64_encode($imageData);
$qrImageSrc = 'data:image/png;base64,' . $qrBase64;


// Dompdf setup
$options = new Options();
$options->set('isRemoteEnabled', true);
$options->set('defaultFont', 'DejaVu Sans');

$dompdf = new Dompdf($options);
$customPaper = [0, 0, 216, 400]; // 57mm x 130mm

// Prepare variables
$amount = floatval($row['amount']);
$giftType = strtolower($row['gift_type']);
$giftDetails = htmlspecialchars($row['gift_details'] ?? '');

// Convert UTC → Dhaka using proper DateTime objects
if (!empty($row['created_at'])) {
    $utc_time = new DateTime($row['created_at'], new DateTimeZone('UTC'));
    $utc_time->setTimezone(new DateTimeZone('Asia/Dhaka'));
    $created_date = $utc_time->format('d/m/Y');
    $created_time = $utc_time->format('h:i A');
} else {
    $created_date = '';
    $created_time = '';
}

$html = '
<style>
    body {
        font-family: DejaVu Sans, sans-serif;
        font-size: 10px;
        margin: -30px -15px -50px -30px;
        padding: 0;
    }
    .wrapper {
        width: 100%;
        padding: 6px;
        box-sizing: border-box;
        border: 1px dashed #000;
    }
    .header {
        text-align: center;
        font-weight: bold;
        font-size: 11px;
        margin-bottom: 4px;
    }
    .qr {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        margin: 6px auto;
        width: 170px;
        height: 160px;
        text-align: center;
    }
    .qr-img {
        width: 150px;
        height: 150px;
        justify-self: center;
    }
    .gift-verify {
        text-align: center;
        font-size: 8px;
        margin-top: -5px;
    }


    .section {
        margin: 3px 0;
        line-height: 1.4em;
    }
    .section-amount {
        margin: 3px 0;
        line-height: 1.4em;
        height: 60px;
    }
    .label {
        font-weight: regular;
    }
    .data {
        font-weight: bold;
    }
    .signature {
        text-align: right;
        margin-top: 15px;
    }
    .signature-username {
        margin-bottom:-14px;
    }
    .footer {
        text-align: center;
        font-size: 8.5px;
        margin-top: 8px;
    }
    .cut-line {
        margin-top: 10px;
        margin-left: 10px;
        text-align: center;
        font-size: 1em;
        position: relative;
    }
    .cut-line span {
        font-size: 10px;
    }
</style>

<div class="wrapper">
    <div class="header">
        ' . htmlspecialchars($event_title) . '<br>
        ' . htmlspecialchars($event_location) . '
    </div>

    <div class="qr">
        <img src="' . $qrImageSrc . '" class="qr-img" >
        <div class="gift-verify">
            <a href="http://localhost/test3/modules/gift/gift_ticket_pdf.php?id=' . $row['gift_id'] . '">
                Online Gift Verification
            </a>
        </div>
    </div>


    <div class="section">
        <span class="label">Date:</span> <span class="data">' . $created_date . '</span><br>
        <span class="label">Time:</span> ' . $created_time . '<br>
        <span class="label">Gift ID:</span> <span class="data">' . htmlspecialchars($row['gift_id']) . '</span>
    </div>

    <div class="section">
        <span class="label">Name:</span> <span class="data">' . htmlspecialchars($row['guest_name']) . '</span><br>
        <span class="label">Address:</span> ' . htmlspecialchars($row['address']) . '<br>
        <span class="label">Relation:</span> ' . htmlspecialchars($row['relation']) . '
    </div>

    <div class="section-amount">';

if ($giftType === 'gift') {
    $html .= '
        <span class="label">Gift Details:</span> <span class="data">' . $giftDetails . '</span><br>';
} elseif ($giftType === 'money' && $amount > 0) {
    $html .= '
        <span class="label">Amount:</span> <span class="data">' . htmlspecialchars($amount) . '</span> Taka<br>
        <span class="label">In Words:</span> ' . convertToWords($amount) . '<br>';
} elseif ($giftType === 'both') {
    $html .= '
        <span class="label">Gift Details:</span> <span class="data">' . $giftDetails . '</span> &<br>';
    if ($amount > 0) {
        $html .= '
        <span class="label">Amount:</span> <span class="data">' . htmlspecialchars($amount) . '</span> Taka<br>
        <span class="label">In Words:</span> ' . convertToWords($amount) . '<br>';
    }
}

$html .= '</div>

    <div class="signature">
        <div class="signature-username">
            <strong>' . $receiverName . '</strong><br>
        </div>
        ____________________<br>
        Receiver Signature<br>
    </div>

    <div class="footer">
        <strong>Thank you for your kind gift.</strong><br>
        Printed by:<br>
        Ripon Sarkar Digital Service, 01928-078420
    </div>
</div>

<div class="cut-line"> 
    -✂--------------------- Tear Here ------------------------ 
</div>
';

$htmlOutput = ob_get_clean(); // Clear buffer and capture any output before PDF render

$dompdf->setPaper($customPaper);
$dompdf->loadHtml($html);
$dompdf->render();
$dompdf->stream("gift_ticket_{$id}.pdf", ["Attachment" => false]);
exit;