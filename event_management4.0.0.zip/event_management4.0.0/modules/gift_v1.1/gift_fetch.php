<?php
// modules/gift/gift_fetch.php

include('../../database_connection.php');

$stmt = $connect->prepare("SELECT * FROM gift ORDER BY gift_id DESC");
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Convert UTC → Dhaka for display
date_default_timezone_set("Asia/Dhaka");

foreach ($rows as &$row) {
    $row['gift_image'] = !empty($row['gift_image']) ? $row['gift_image'] : '';
    $row['created_at_dhaka'] = !empty($row['created_at']) ? date("Y-m-d H:i:s", strtotime($row['created_at'])) : '';
    $row['updated_at_dhaka'] = !empty($row['updated_at']) ? date("Y-m-d H:i:s", strtotime($row['updated_at'])) : '';
}

echo json_encode(['data' => $rows]);
