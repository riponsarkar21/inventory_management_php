<?php
// modules/gift/gift_fetch.php

include('../../database_connection.php');

$stmt = $connect->prepare("SELECT * FROM gift ORDER BY gift_id DESC");
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Convert UTC → Dhaka for display
date_default_timezone_set("Asia/Dhaka");

foreach ($rows as &$row) {
    $row['gift_image'] = !empty($row['gift_image']) ? $row['gift_image'] : '';
    
    // Properly convert UTC to Dhaka time (+6 hours)
    if (!empty($row['created_at'])) {
        $utc_time = new DateTime($row['created_at'], new DateTimeZone('UTC'));
        $utc_time->setTimezone(new DateTimeZone('Asia/Dhaka'));
        $row['created_at_dhaka'] = $utc_time->format('Y-m-d H:i:s');
    } else {
        $row['created_at_dhaka'] = '';
    }
    
    if (!empty($row['updated_at'])) {
        $utc_time = new DateTime($row['updated_at'], new DateTimeZone('UTC'));
        $utc_time->setTimezone(new DateTimeZone('Asia/Dhaka'));
        $row['updated_at_dhaka'] = $utc_time->format('Y-m-d H:i:s');
    } else {
        $row['updated_at_dhaka'] = '';
    }
}

echo json_encode(['data' => $rows]);