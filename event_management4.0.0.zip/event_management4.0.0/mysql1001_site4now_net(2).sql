-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql1001.site4now.net
-- Generation Time: Aug 05, 2025 at 11:32 AM
-- Server version: 8.0.42
-- PHP Version: 8.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_abad89_invento`
--
CREATE DATABASE IF NOT EXISTS `db_abad89_invento` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `db_abad89_invento`;

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `brand_id` int NOT NULL,
  `category_id` int NOT NULL,
  `brand_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `brand_status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`brand_id`, `category_id`, `brand_name`, `brand_status`) VALUES
(1, 1, 'Finibus', 'active'),
(2, 1, 'Lorem', 'active'),
(3, 1, 'Ipsum', 'inactive'),
(4, 8, 'Dolor', 'active'),
(5, 8, 'Amet', 'active'),
(6, 6, 'Aliquam', 'active'),
(7, 6, 'Maximus', 'active'),
(8, 10, 'Venenatis', 'active'),
(9, 10, 'Ligula', 'active'),
(10, 3, 'Vitae', 'active'),
(11, 3, 'Auctor', 'active'),
(12, 5, 'Luctus', 'active'),
(13, 5, 'Justo', 'active'),
(14, 2, 'Phasellus', 'active'),
(15, 2, 'Viverra', 'active'),
(16, 4, 'Elementum', 'active'),
(17, 4, 'Odio', 'inactive'),
(18, 7, 'Tellus', 'active'),
(19, 7, 'Curabitur', 'active'),
(20, 9, 'Commodo', 'active'),
(21, 9, 'Nullam', 'active'),
(24, 11, 'XYZ', 'active'),
(25, 15, 'Bashundhara', 'active'),
(26, 15, 'Fresh', 'active'),
(27, 21, 'Sprite', 'active'),
(28, 21, 'Cocacola', 'active'),
(29, 22, 'Wheel', 'active'),
(30, 23, 'Bashmati', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `bug`
--

CREATE TABLE `bug` (
  `bug_id` int NOT NULL,
  `bug_title` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `bug_description` text COLLATE utf8mb4_general_ci,
  `screenshot_image` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` enum('Open','Solved','Cancelled') COLLATE utf8mb4_general_ci DEFAULT 'Open',
  `created_by` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `solved_by` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `solved_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bug`
--

INSERT INTO `bug` (`bug_id`, `bug_title`, `bug_description`, `screenshot_image`, `status`, `created_by`, `created_at`, `solved_by`, `solved_at`) VALUES
(1, 'Add withdraw Feature', 'Add withdraw Feature', '', 'Open', 'Test1', '2025-07-14 11:15:08', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int NOT NULL,
  `category_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `category_status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`, `category_status`) VALUES
(1, 'LED Bulb', 'active'),
(2, 'LED Lights', 'active'),
(3, 'LED Down Lights', 'active'),
(4, 'LED Panel Light', 'active'),
(5, 'LED Lamp', 'active'),
(6, 'LED Concealed Light', 'active'),
(7, 'LED Spot Light', 'active'),
(8, 'LED Ceiling Light', 'active'),
(9, 'LED Tube Light', 'inactive'),
(10, 'LED Driver', 'active'),
(11, 'Led Floods Light', 'active'),
(13, 'LED Outdoor Lighting', 'active'),
(14, 'LED Indoor Lights', 'active'),
(15, 'Vegetable Oil', 'active'),
(17, 'xxx', 'inactive'),
(18, 'yyy', 'active'),
(20, 'zzz', 'active'),
(21, 'Cold Drinks', 'active'),
(22, 'Detergent', 'active'),
(23, 'Rice', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `collection`
--

CREATE TABLE `collection` (
  `collection_id` int NOT NULL,
  `inventory_order_id` int NOT NULL,
  `user_id` int NOT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `collection_date` date NOT NULL,
  `collected_amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `remarks` text COLLATE utf8mb4_general_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `collection_amount` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `collection`
--

INSERT INTO `collection` (`collection_id`, `inventory_order_id`, `user_id`, `customer_name`, `collection_date`, `collected_amount`, `payment_method`, `remarks`, `created_at`, `collection_amount`) VALUES
(2, 32, 1, 'Ripon', '2025-06-04', 2.00, 'Cash', NULL, '2025-06-09 09:26:58', NULL),
(3, 31, 1, 'Ripon', '2025-06-10', 200.00, 'Cash', NULL, '2025-06-09 10:18:06', NULL),
(4, 30, 11, 'Mukta', '2025-06-10', 20.00, 'Cash', NULL, '2025-06-09 10:26:38', NULL),
(5, 29, 11, 'Pranto', '2025-06-10', 30.00, 'Mobile', NULL, '2025-06-09 10:27:12', NULL),
(6, 30, 12, 'Mukta', '2025-06-04', 250.00, 'Others', NULL, '2025-06-09 10:33:47', NULL),
(7, 32, 1, 'Mukta', '2025-06-13', 200.00, 'Bank', NULL, '2025-06-12 18:25:13', NULL),
(8, 30, 1, 'mehedi', '2025-06-13', 500.00, 'Mobile', NULL, '2025-06-12 18:26:18', NULL),
(9, 30, 11, 'Mukta', '2025-06-19', 100.00, 'Cash', NULL, '2025-06-20 14:17:09', NULL),
(10, 30, 11, 'Pranto', '2025-06-19', 555.00, 'Others', NULL, '2025-06-20 14:18:09', NULL),
(11, 32, 11, 'Mukta', '2025-06-10', 1000.00, 'Bank', NULL, '2025-06-20 15:00:04', NULL),
(12, 29, 11, 'Pranto', '2025-06-09', 10.00, 'Mobile', NULL, '2025-06-20 16:06:12', NULL),
(14, 32, 1, 'A', '2025-06-26', 1.00, 'Others', NULL, '2025-06-25 21:32:33', NULL),
(15, 34, 15, 'A', '2025-06-26', 10.00, 'Bank', NULL, '2025-06-26 08:03:48', NULL),
(16, 35, 1, 'Mr. Rajkumar', '2025-07-01', 63.00, 'Cash', NULL, '2025-07-01 02:22:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int NOT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `id` int NOT NULL,
  `event_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `event_location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `event_date` date NOT NULL,
  `event_host` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `event_host_contact` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `event_participant_number` int DEFAULT '0',
  `event_deal_amount` decimal(12,2) DEFAULT '0.00',
  `event_deal_contract_details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `status` enum('Active','Inactive','Cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id`, `event_title`, `event_location`, `event_date`, `event_host`, `event_host_contact`, `event_participant_number`, `event_deal_amount`, `event_deal_contract_details`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Rajashree Birthday Ceremony', 'Jessore', '2025-07-15', 'Ripon Sarkar', '01928078420', 500, 5000.00, 'Test', 'Active', '2025-07-25 17:52:50', '2025-07-25 17:53:12'),
(2, 'Mehedi Wedding Ceremony', 'Bagerhat', '2025-07-26', 'Mehedi', '01928078430', 1000, 10000.00, 'Guest Name', 'Active', '2025-07-26 09:01:27', '2025-07-26 09:01:43');

-- --------------------------------------------------------

--
-- Table structure for table `gift`
--

CREATE TABLE `gift` (
  `gift_id` int NOT NULL,
  `created_by` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `guest_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `relation` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `gift_type` enum('money','gift','both') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'money',
  `amount` decimal(10,2) DEFAULT NULL,
  `payment_method` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `gift_details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `gift_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `gift`
--

INSERT INTO `gift` (`gift_id`, `created_by`, `user_id`, `guest_name`, `phone`, `address`, `relation`, `gift_type`, `amount`, `payment_method`, `gift_details`, `gift_image`, `created_at`, `status`) VALUES
(1, NULL, 1, 'Ripon Sarkar', '01928078420', 'Jessore', 'Father', 'both', 100.00, 'Cash', 'Dress', 'uploads/gift/ripon-jessore-1751263683.jfif', '2025-06-27 09:23:57', 'Active'),
(2, NULL, 13, 'Akhi', '01821686365', 'CTG', 'Mother', 'both', 100.00, 'Bkash', 'Toys', 'uploads/gift/akhi-ctg-1751263697.jfif', '2025-06-27 10:38:23', 'Active'),
(3, NULL, 16, 'Akhi', '01821686365', 'CTG', 'Mother', 'both', 100.00, 'Bkash', 'Toys', 'uploads/gift/akhi-ctg-1751263712.jfif', '2025-06-27 10:38:33', 'Active'),
(4, NULL, 4, 'Akhi', '01821686365', 'CTG', 'Mother', 'both', 100.00, 'Bkash', 'Toys', '', '2025-06-27 10:38:36', 'Active'),
(5, NULL, 16, 'Guest1', '01234567890', 'Aaaaa', 'Brother', 'both', 100.00, 'Cash', 'Giftbox', 'uploads/gift/guest1-aaaaa-1751263725.jfif', '2025-06-28 01:52:46', 'Active'),
(6, NULL, 4, 'Guest2', '01234567891', 'Bbbbb', 'Sister', 'money', 100.00, 'Nagad', '', '', '2025-06-28 01:54:47', 'Active'),
(7, NULL, 16, 'Guest3', '01234567893', 'Ccccc', 'Friend', 'gift', NULL, 'Cash', 'Giftbox', '', '2025-06-28 02:17:58', 'Inactive'),
(8, NULL, 4, 'Guest4', '01234567894', 'Ddddd', 'Friend', 'money', 100.00, 'Others', '', '', '2025-06-28 02:18:58', 'Active'),
(9, NULL, 4, 'Rajashree', '01928078420', 'Jessore', 'Vagni', 'both', 100.00, 'Cash', 'Sharee', '', '2025-06-28 15:01:45', 'Active'),
(10, NULL, 12, 'Guest4', '01234567894', 'Asasas', 'Friend', 'gift', NULL, 'Cash', 'Giftbox', '', '2025-06-29 04:14:21', 'Active'),
(11, NULL, 13, 'Guest5', '01234567895', 'Asfsfg', 'Friend', 'both', 100.00, 'Bank', 'Giftbox', '', '2025-06-29 04:33:29', 'Active'),
(12, NULL, 10, 'Borna', '01928078421', 'Barishal', 'Aunty', 'gift', NULL, 'Cash', 'Sharee', '', '2025-06-30 06:00:28', 'Active'),
(13, 0, 1, 'Subir Izaradar', '0123456123456', 'Mongla', 'Friend', 'both', 100.00, 'Bkash', 'Toys', '', '2025-07-13 12:18:56', 'Active'),
(14, NULL, 1, 'Milon Mahmud', '01234561254', 'Mongla', 'Friend', 'money', 100.00, 'Bank', '', '', '2025-07-13 12:28:46', 'Active'),
(15, 0, 1, 'Sumonto Debnath', '01456236547', 'Birampur', 'Friend', 'money', 100.00, 'Nagad', '', '', '2025-07-13 13:04:42', 'Active'),
(16, 0, 1, 'Shamol Kumar Sharma', '01234523698', 'Birampur', 'Teacher', 'both', 100.00, 'Others', 'Dhooti', '', '2025-07-13 13:06:07', 'Active'),
(17, 15, 15, 'Ananda Chowdhury', '01722331181', 'Hazrahati', 'Uncle', 'money', 111111.00, 'Cash', 'Toys', '', '2025-07-14 12:23:56', 'Active'),
(18, 15, 15, 'Swapna Chowdhury', '01722331181', 'Hazrahati', 'Uncle', 'gift', NULL, 'Bkash', 'Toys', 'uploads/gift/swapna-hazrahati-1753235486.jpeg', '2025-07-14 12:52:26', 'Active'),
(19, 15, 15, 'shahin', '01911679706', 'Mongla', '', 'money', 2000.00, 'Cash', '', '', '2025-07-14 13:44:22', 'Cancelled'),
(20, 15, 15, 'jk', '', 'mongla', '', 'money', -10.00, 'Bkash', '', '', '2025-07-14 13:47:16', 'Active'),
(21, 4, 4, 'Shahidul', '01926315544', 'Mongla', '', 'money', 1111111.00, 'Cash', '', '', '2025-07-14 13:57:11', 'Active'),
(22, 15, 15, 'Ripon Sarkar', '01928078420', 'Birampur, Jessore', 'Father', 'both', 11111111.11, 'Cash', 'Giftbox', 'uploads/gift/ripon-birampur-1753368986.jpeg', '2025-07-24 14:54:56', 'Active'),
(23, 15, 15, 'Arijit chowdhury', '06423567', 'Ctg', 'Brother', 'gift', NULL, 'Cash', 'Giftbox', '', '2025-07-25 05:57:20', 'Active'),
(24, 15, 15, 'Saad', '01911679706', 'Mongla', '', 'money', 3000.00, 'Cash', '', '', '2025-07-31 15:22:25', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `gift_backup`
--

CREATE TABLE `gift_backup` (
  `gift_id` int NOT NULL DEFAULT '0',
  `guest_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `relation` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `gift_type` enum('money','gift','both') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'money',
  `amount` decimal(10,2) DEFAULT NULL,
  `payment_method` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `gift_details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `gift_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gift_backup`
--

INSERT INTO `gift_backup` (`gift_id`, `guest_name`, `phone`, `address`, `relation`, `gift_type`, `amount`, `payment_method`, `gift_details`, `gift_image`, `created_at`, `status`) VALUES
(1, 'Ripon Sarkar', '01928078420', 'Jessore', 'Father', 'both', 1000.00, 'Cash', 'Dress', 'uploads/gift/ripon-jessore-1751263683.jfif', '2025-06-27 09:23:57', 'Active'),
(2, 'Akhi', '01821686365', 'CTG', 'Mother', 'both', 500.00, 'Bkash', 'Toys', 'uploads/gift/akhi-ctg-1751263697.jfif', '2025-06-27 10:38:23', 'Active'),
(3, 'Akhi', '01821686365', 'CTG', 'Mother', 'both', 500.00, 'Bkash', 'Toys', 'uploads/gift/akhi-ctg-1751263712.jfif', '2025-06-27 10:38:33', 'Inactive'),
(4, 'Akhi', '01821686365', 'CTG', 'Mother', 'both', 500.00, 'Bkash', 'Toys', '', '2025-06-27 10:38:36', 'Inactive'),
(5, 'Guest1', '01234567890', 'Aaaaa', 'Brother', 'both', 100.00, 'Cash', 'Giftbox', 'uploads/gift/guest1-aaaaa-1751263725.jfif', '2025-06-28 01:52:46', 'Active'),
(6, 'Guest2', '01234567891', 'Bbbbb', 'Sister', 'money', 100.00, 'Nagad', '', '', '2025-06-28 01:54:47', 'Active'),
(7, 'Guest3', '01234567893', 'Ccccc', 'Friend', 'gift', NULL, 'Cash', 'Giftbox', '', '2025-06-28 02:17:58', 'Inactive'),
(8, 'Guest4', '01234567894', 'Ddddd', 'Friend', 'money', 200.00, 'Others', '', '', '2025-06-28 02:18:58', 'Active'),
(9, 'Rajashree', '01928078420', 'Jessore', 'Vagni', 'both', 1000.00, 'Cash', 'Sharee', '', '2025-06-28 15:01:45', 'Active'),
(10, 'Guest4', '01234567894', 'Asasas', 'Friend', 'gift', NULL, 'Cash', 'Giftbox', '', '2025-06-29 04:14:21', 'Active'),
(11, 'Guest5', '01234567895', 'Asfsfg', 'Friend', 'both', 200.00, 'Bank', 'Giftbox', '', '2025-06-29 04:33:29', 'Active'),
(12, 'Borna', '01928078421', 'Barishal', 'Aunty', 'gift', NULL, 'Cash', 'Sharee', '', '2025-06-30 06:00:28', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_order`
--

CREATE TABLE `inventory_order` (
  `inventory_order_id` int NOT NULL,
  `user_id` int NOT NULL,
  `customer_id` int DEFAULT NULL,
  `inventory_order_total` double(10,2) NOT NULL,
  `inventory_order_date` date NOT NULL,
  `inventory_order_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `inventory_order_address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `payment_status` enum('cash','credit') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `inventory_order_status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `inventory_order_created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventory_order`
--

INSERT INTO `inventory_order` (`inventory_order_id`, `user_id`, `customer_id`, `inventory_order_total`, `inventory_order_date`, `inventory_order_name`, `inventory_order_address`, `payment_status`, `inventory_order_status`, `inventory_order_created_date`) VALUES
(1, 7, NULL, 4939.20, '2017-11-08', 'David Harper', '3188 Straford Park\r\nHarold, KY 41635', 'credit', 'active', '2017-11-08'),
(2, 7, NULL, 1310.40, '2017-11-08', 'Trevor Webster', '4275 Indiana Avenue\r\nHonolulu, HI 96816', 'cash', 'active', '2017-11-08'),
(3, 6, NULL, 265.65, '2017-11-08', 'Russell Barrett', '4687 Powder House Road\r\nJupiter, FL 33478', 'cash', 'active', '2017-11-08'),
(4, 6, NULL, 1546.80, '2017-11-08', 'Doloris Turner', '3057 Collins Avenue\r\nWesterville, OH 43081', 'credit', 'active', '2017-11-08'),
(5, 5, NULL, 1409.00, '2017-11-08', 'Georgette Blevins', '863 Simpson Avenue\r\nSteelton, PA 17113', 'cash', 'active', '2017-11-08'),
(6, 5, NULL, 558.90, '2017-11-08', 'Nancy Brook', '3460 Viking Drive\r\nBarnesville, OH 43713', 'credit', 'inactive', '2017-11-08'),
(7, 4, NULL, 1286.25, '2017-11-08', 'Joseph Smith', '190 Metz Lane\r\nCharlestown, MA 02129', 'cash', 'active', '2017-11-08'),
(8, 4, NULL, 1520.00, '2017-11-08', 'Maria Lafleur', '3878 Elkview Drive\r\nPort St Lucie, FL 33452', 'credit', 'active', '2017-11-08'),
(9, 4, NULL, 1604.00, '2017-11-08', 'David Smith', '4757 Little Acres Lane\r\nLoraine, IL 62349', 'cash', 'active', '2017-11-08'),
(10, 3, NULL, 1724.80, '2017-11-08', 'Michelle Hayes', '1140 C Street\r\nWorcester, MA 01609', 'cash', 'active', '2017-11-08'),
(11, 3, NULL, 1859.40, '2017-11-08', 'Brenna Hamilton', '2845 Davis Avenue\r\nPetaluma, CA 94952', 'cash', 'active', '2017-11-08'),
(12, 3, NULL, 2038.40, '2017-11-08', 'Robbie McKenzie', '3016 Horizon Circle\r\nEatonville, WA 98328', 'credit', 'active', '2017-11-08'),
(13, 2, NULL, 573.00, '2017-11-08', 'Jonathan Allen', '2426 Evergreen Lane\r\nAlhambra, CA 91801', 'cash', 'active', '2017-11-08'),
(14, 2, NULL, 1196.35, '2017-11-08', 'Mildred Paige', '3167 Oakway Lane\r\nReseda, CA 91335', 'cash', 'active', '2017-11-08'),
(15, 2, NULL, 1960.00, '2017-11-08', 'Elva Lott', '4032 Aaron Smith Drive\r\nHarrisburg, PA 17111', 'credit', 'active', '2017-11-08'),
(16, 2, NULL, 2700.00, '2017-11-08', 'Eric Johnson', '616 Devils Hill Road\r\nJackson, MS 39213', 'cash', 'active', '2017-11-08'),
(17, 1, NULL, 5615.20, '2017-11-09', 'Doris Oliver', '2992 Sycamore Fork Road Hopkins, MN 55343', 'cash', 'active', '2017-11-09'),
(26, 1, NULL, 2278.50, '2017-11-27', 'Janet Richardsons', '4799 Ryder Avenue Everett, WA 98210', 'credit', 'inactive', '2017-11-27'),
(27, 1, NULL, 336000.00, '2025-06-09', 'Mukta Sarkar', 'Jessore', 'cash', 'active', '2025-06-07'),
(28, 1, NULL, 189.00, '2025-06-07', 'Mukta', 'Jessore', 'cash', 'active', '2025-06-07'),
(29, 11, NULL, 22.00, '2025-06-08', 'Pranto Sarkar', 'Jessore Khulna', 'credit', 'active', '2025-06-08'),
(30, 13, NULL, 735.00, '2025-06-08', 'Rajashree', 'CTG', 'cash', 'active', '2025-06-08'),
(31, 11, NULL, 504.00, '2025-05-25', 'Pranto', 'Khulna', 'cash', 'active', '2025-06-08'),
(32, 11, NULL, 1102.50, '2025-05-05', 'Ripon', 'CTG', 'cash', 'active', '2025-06-08'),
(33, 11, NULL, 220.00, '2025-06-10', 'Mukta Sarkar', 'Jessore', 'credit', 'active', '2025-06-20'),
(34, 15, NULL, 1146.50, '2025-06-25', 'Mr. Ripon', 'Jessore', 'cash', 'active', '2025-06-26'),
(35, 1, NULL, 63.00, '2025-06-30', 'Mr. Rajkumar', 'Jessore', 'cash', 'active', '2025-07-01');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_order_product`
--

CREATE TABLE `inventory_order_product` (
  `inventory_order_product_id` int NOT NULL,
  `inventory_order_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL,
  `price` double(10,2) NOT NULL,
  `tax` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventory_order_product`
--

INSERT INTO `inventory_order_product` (`inventory_order_product_id`, `inventory_order_id`, `product_id`, `quantity`, `price`, `tax`) VALUES
(3, 1, 1, 10, 141.00, 12.00),
(4, 1, 3, 4, 800.00, 5.00),
(5, 2, 2, 3, 350.00, 12.00),
(6, 2, 17, 2, 60.00, 12.00),
(7, 3, 15, 1, 125.00, 5.00),
(8, 3, 17, 2, 60.00, 12.00),
(12, 4, 18, 4, 90.00, 12.00),
(13, 4, 20, 3, 100.00, 18.00),
(14, 4, 1, 5, 141.00, 12.00),
(15, 5, 4, 2, 550.00, 12.00),
(16, 5, 10, 1, 150.00, 18.00),
(17, 6, 8, 5, 15.00, 18.00),
(18, 6, 7, 2, 210.00, 12.00),
(19, 7, 16, 7, 175.00, 5.00),
(23, 8, 19, 5, 120.00, 18.00),
(24, 8, 11, 5, 85.00, 12.00),
(25, 8, 12, 5, 60.00, 12.00),
(26, 9, 13, 3, 200.00, 18.00),
(27, 9, 9, 2, 400.00, 12.00),
(28, 10, 9, 3, 400.00, 12.00),
(29, 10, 11, 4, 85.00, 12.00),
(30, 11, 6, 6, 250.00, 15.00),
(31, 11, 12, 2, 60.00, 12.00),
(32, 12, 2, 4, 350.00, 12.00),
(33, 12, 7, 2, 210.00, 12.00),
(34, 13, 18, 3, 90.00, 12.00),
(35, 13, 7, 1, 210.00, 12.00),
(36, 13, 8, 2, 15.00, 18.00),
(37, 14, 6, 2, 250.00, 15.00),
(38, 14, 13, 1, 200.00, 18.00),
(39, 14, 16, 1, 175.00, 5.00),
(40, 14, 17, 3, 60.00, 12.00),
(41, 15, 2, 5, 350.00, 12.00),
(42, 16, 4, 4, 550.00, 12.00),
(43, 16, 13, 1, 200.00, 18.00),
(46, 17, 21, 2, 500.00, 18.00),
(47, 17, 3, 5, 800.00, 5.00),
(48, 17, 7, 1, 210.00, 12.00),
(49, 0, 23, 5, 30.00, 12.00),
(50, 0, 12, 5, 60.00, 12.00),
(51, 0, 16, 5, 175.00, 5.00),
(52, 0, 6, 5, 250.00, 15.00),
(53, 0, 16, 5, 175.00, 5.00),
(54, 0, 7, 5, 210.00, 12.00),
(55, 0, 7, 5, 210.00, 12.00),
(56, 0, 7, 5, 210.00, 12.00),
(57, 25, 14, 5, 250.00, 18.00),
(58, 25, 11, 5, 85.00, 12.00),
(79, 26, 16, 6, 175.00, 5.00),
(80, 26, 7, 5, 210.00, 12.00),
(81, 27, 23, 10000, 30.00, 12.00),
(82, 28, 25, 1, 180.00, 5.00),
(83, 29, 28, 1, 20.00, 10.00),
(84, 30, 27, 2, 350.00, 5.00),
(85, 31, 18, 5, 90.00, 12.00),
(86, 32, 27, 3, 350.00, 5.00),
(88, 33, 28, 10, 20.00, 10.00),
(89, 34, 28, 2, 20.00, 10.00),
(90, 34, 27, 3, 350.00, 5.00),
(91, 35, 30, 1, 120.00, 5.00);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int NOT NULL,
  `category_id` int NOT NULL,
  `brand_id` int NOT NULL,
  `product_name` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `product_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `product_quantity` int NOT NULL,
  `product_unit` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `product_base_price` double(10,2) NOT NULL,
  `product_tax` decimal(4,2) NOT NULL,
  `product_minimum_order` double(10,2) NOT NULL,
  `product_enter_by` int NOT NULL,
  `product_status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `product_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `category_id`, `brand_id`, `product_name`, `product_description`, `product_quantity`, `product_unit`, `product_base_price`, `product_tax`, `product_minimum_order`, `product_enter_by`, `product_status`, `product_date`) VALUES
(1, 1, 1, '4W LED Bulb', 'Base Type	B22, E27\r\nBulb Material	Aluminium\r\nItem Width	5 (cm)\r\nItem Height	10 (cm)\r\nItem Weight	0.07 (kg)', 100, 'Nos', 141.00, 12.00, 0.00, 1, 'active', '2017-11-08'),
(2, 1, 3, '17W B22 LED Bulb', 'Item Height	14.2 (cm)\r\nColor Temperature (Kelvin)	6500\r\nItem Weight	0.19 (kg)\r\nBulb Material	Aluminium\r\nBase Color	Aluminium\r\nVoltage	240\r\nUsages	Household, Commercial, Kitchen', 150, 'Nos', 350.00, 12.00, 0.00, 1, 'active', '2017-11-08'),
(3, 8, 5, '18W LED Ceiling Light', 'Round Ceiling Light 18w', 75, 'Nos', 800.00, 5.00, 0.00, 1, 'inactive', '2017-11-08'),
(4, 8, 4, 'Round LED Ceiling Light', 'Relying on our expertise in this domain, we are into offering Round LED Ceiling Light.	', 50, 'Nos', 550.00, 12.00, 0.00, 1, 'active', '2017-11-08'),
(5, 6, 6, '7W LED Concealed Light', 'Dimension \'3\" \'\r\n50000 hours burning life\r\ncost effective\r\nhigh quality led', 85, 'Nos', 240.00, 15.00, 0.00, 1, 'active', '2017-11-08'),
(6, 6, 7, '9w LED Concealed Light', 'dimension \'3\" \'\r\n50000 hours burning life\r\ncost effective\r\nhigh quality led', 65, 'Nos', 250.00, 15.00, 0.00, 1, 'active', '2017-11-08'),
(7, 10, 9, '24W Street Light Led Driver', 'Dc Voltage	36v\r\nRated Current	600ma\r\nRated Power	22w', 120, 'Nos', 210.00, 12.00, 0.00, 1, 'active', '2017-11-08'),
(8, 10, 8, 'BP1601 ICs', 'Backed by immense industry-experience & latest designing techniques, we are engaged in providing BP1601 ICs.', 200, 'Nos', 15.00, 18.00, 0.00, 1, 'active', '2017-11-08'),
(9, 3, 11, '5W LED Square Downlight', 'Wattage: 5 Watt\r\nInput Voltage: 150V to 265V, 50/60Hz\r\nLumens: 500 lumen (approx)\r\nPower Factor: 0.90pf', 50, 'Nos', 400.00, 12.00, 0.00, 1, 'active', '2017-11-08'),
(10, 3, 10, '10W LED Square Downlight', 'Wattage: 10 Watt\r\nInput Voltage: 150V to 265V, 50/60Hz\r\nLumens: 1000 lumen (approx)\r\nPower Factor: 0.90pf', 40, 'Nos', 150.00, 18.00, 0.00, 1, 'active', '2017-11-08'),
(11, 5, 13, ' 9w Deluxe LED Lamp', 'Lighting Color	Cool Daylight\r\nBase Type	B22', 100, 'Nos', 85.00, 12.00, 0.00, 1, 'active', '2017-11-08'),
(12, 5, 12, '5w LED Lamp', 'Lighting Color	Cool Daylight\r\nBody Material	Aluminum\r\nBase Type	B22', 75, 'Nos', 60.00, 12.00, 0.00, 1, 'active', '2017-11-08'),
(13, 2, 14, '15W Big LED Bay Light', 'Wattage: 15 Watt\r\nInput Voltage: 100V - 265V, 50/60Hz\r\nLumens: 1500 lumen (approx)\r\nPower Factor: 0.90pf', 60, 'Nos', 200.00, 18.00, 0.00, 1, 'active', '2017-11-08'),
(14, 2, 15, '15W Small LED Bay Light', 'Wattage: 15 Watt\r\nInput Voltage: 100V -265V, 50/60Hz\r\nLumens: 1500 lumen (approx)\r\nPower Factor: 0.90pf', 55, 'Nos', 250.00, 18.00, 0.00, 1, 'active', '2017-11-08'),
(15, 4, 16, '12W LED Panel Light', 'Body Material	Aluminum\r\nLighting Type	LED\r\nApplications	Hotel, House, etc', 85, 'Nos', 125.00, 5.00, 0.00, 1, 'active', '2017-11-08'),
(16, 4, 17, '15W LED Panel Light', 'IP Rating	IP40\r\nBody Material	Aluminum\r\nLighting Type	LED', 40, 'Nos', 175.00, 5.00, 0.00, 1, 'active', '2017-11-08'),
(17, 7, 19, '3W Round LED Spotlight', 'Lighting Color	Cool White\r\nBody Material	Aluminum\r\nCertification	ISO\r\nInput Voltage(V)	12 V\r\nIP Rating	IP33, IP40, IP44', 100, 'Nos', 60.00, 12.00, 0.00, 1, 'active', '2017-11-08'),
(18, 7, 18, '3W Square LED Spotlight', 'Lighting Color	Cool White\r\nBody Material	Aluminum\r\nInput Voltage(V)	12 V\r\nIP Rating	IP33, IP40', 85, 'Nos', 90.00, 12.00, 0.00, 1, 'active', '2017-11-08'),
(19, 9, 20, '18W LED Tube Light', 'Tube Base Type	T5\r\nIP Rating	IP66', 180, 'Nos', 120.00, 18.00, 0.00, 1, 'active', '2017-11-08'),
(20, 9, 21, '10W Ready Tube Light', 'Body Material	Aluminum, Ceramic\r\nPower	10W', 200, 'Nos', 100.00, 18.00, 0.00, 1, 'active', '2017-11-08'),
(21, 11, 22, '90W LED Flood Lights', 'Lighting Color	Cool White, Pure White, Warm White\r\nBody Material	Ceramic, Chrome, Iron\r\nIP Rating	IP33, IP40, IP44, IP55, IP66', 20, 'Nos', 500.00, 18.00, 0.00, 1, 'active', '2017-11-09'),
(23, 1, 3, '15 Watt LED Bulb', '15 Watt LED Bulb', 2000, 'Nos', 30.00, 12.00, 0.00, 1, 'active', '2017-11-21'),
(24, 1, 2, '15 Watt LED Bulb Screw Type', '15 Watt LED Bulb Screw Type', 500, 'Nos', 25.00, 10.00, 0.00, 1, 'active', '2025-06-07'),
(25, 15, 25, 'Soyabean Oil 1 Ltr Bottle', 'Soyabean Oil 1 Ltr', 100, 'Bottles', 180.00, 5.00, 0.00, 1, 'active', '2025-06-07'),
(26, 15, 26, 'Soyabean Oil 1 Ltr Bottle', 'Soyabean Oil 1 Ltr ', 5000, 'Bottles', 175.00, 5.00, 0.00, 1, 'active', '2025-06-07'),
(27, 15, 25, 'Soyabean Oil 2 Ltr Bottle', 'Soyabean Oil 2 Ltr', 600, 'Bottles', 350.00, 5.00, 0.00, 1, 'active', '2025-06-08'),
(28, 21, 27, 'Sprite 1 Ltr', 'Sprite 1 Ltr', 100, 'Bottles', 20.00, 10.00, 0.00, 1, 'active', '2025-06-08'),
(29, 22, 29, 'Wheel Powder 1 KG Packet', 'Wheel Powder 1 KG Packet', 20, 'Packet', 100.00, 2.00, 1.00, 1, 'active', '2025-07-01'),
(30, 23, 30, 'Pran Super Bashmati Rice 1 KG Packet', 'Pran Super Bashmati Rice 1 KG Packet', 50, 'Packet', 120.00, 5.00, 1.00, 1, 'active', '2025-07-01');

-- --------------------------------------------------------

--
-- Table structure for table `to_do_update`
--

CREATE TABLE `to_do_update` (
  `id` int NOT NULL,
  `bug_id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `bug_description` text COLLATE utf8mb4_general_ci NOT NULL,
  `created_by` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `solved_by` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `solved_at` datetime DEFAULT NULL,
  `status` enum('Open','Solved') COLLATE utf8mb4_general_ci DEFAULT 'Open'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `user_id` int NOT NULL,
  `user_email` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_password` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_status` enum('Active','Inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `user_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `user_address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `user_reference` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `user_education` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `user_experience` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `user_training` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `dashboard_version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'gift_dashboard.php'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`user_id`, `user_email`, `user_password`, `user_name`, `user_type`, `user_status`, `user_image`, `user_phone`, `user_address`, `user_reference`, `user_education`, `user_experience`, `user_training`, `dashboard_version`) VALUES
(1, 'riponsarkar21@gmail.com', '$2y$10$RIAyHQbqiR4AUpvubjJQl.7m4v3zfobM1u9Ge33OuddIshFrz.Ppi', 'Ripon Sarkar', 'Super Master', 'Active', NULL, '', 'Jessore', 'CEO', 'BSc Engineering', '', '', 'gift_dashboard1.php'),
(4, 'test1@test.com', '$2y$10$pT1jxAOJvd./pduFxSkiYO95ix1RBNIH93mbkC5.VqyTmURT7ch0G', 'Test1', 'Gift User', 'Active', NULL, NULL, 'Test1 Street', NULL, NULL, NULL, NULL, 'gift_dashboard9.php'),
(10, 'peter_parker@gmail.com', '$2y$10$GoQvEZNTWEibo0FPK7h57eA5UsNkXfIdex1deGsW/CFIY8zqxyu2S', 'Mark Parker', 'User', 'Active', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'gift_dashboard1.php'),
(11, 'sumonmiya@test.com', '$2y$10$Cccdb9YqNKLMyuGh5PBaOObekELQkwD2wRQ16ioqv2RtfnE8YbmCa', 'Sumon Miya', 'User', 'Active', NULL, '', 'Sumon Miya Street', '', '', '', '', 'gift_dashboard1.php'),
(12, 'test2@test.com', '$2y$10$yUWQzMTvEB9RdhnT3pDfG.MXzlM2Hhcq5.jJbAPrjl4PcyXwsKEqu', 'Test2', 'Inventory Admin', 'Active', NULL, NULL, '', NULL, NULL, NULL, NULL, 'gift_dashboard1.php'),
(13, 'test3@test.com', '$2y$10$IIeIfiQPOvWhrlggZfJb0O.bNg4a2m.W9GWMcweHdFl3Ubt4HYOkO', 'Test3', 'Inventory User', 'Inactive', NULL, NULL, '', NULL, NULL, NULL, NULL, 'gift_dashboard1.php'),
(14, 'test4@test.com', '$2y$10$6tRJ/rzGxXN/oAuvGSRoReT2kEvyP/4Np25sMiaArVX/85YpIFUhO', 'Test4', 'User', 'Active', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'gift_dashboard1.php'),
(15, 'mehedi@test.com', '$2y$10$sdSSySAIKFtNo23AWIMba.ci6isblJqAL7Iz079NZkz64Z4C503e6', 'Mehedi', 'Gift Admin', 'Active', NULL, NULL, 'Bagerhat', NULL, NULL, NULL, NULL, 'gift_dashboard9.php'),
(16, 'rajashree@test.com', '$2y$10$e/mBMTgHuZowbAU9zgJtcONhfIrSlaYhgMlQDKbNF7dEhfID5L2K2', 'rajashree', 'Master', 'Active', 'uploads/user/rajashree-jessore-1751274095.jpg', NULL, 'Jessore', NULL, NULL, NULL, NULL, 'gift_dashboard1.php');

-- --------------------------------------------------------

--
-- Table structure for table `withdraw`
--

CREATE TABLE `withdraw` (
  `withdraw_id` int NOT NULL,
  `person_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'active',
  `user_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `withdraw`
--

INSERT INTO `withdraw` (`withdraw_id`, `person_name`, `phone`, `amount`, `payment_method`, `note`, `status`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Ripon Sarkar', '0123546464', 100.00, 'Cash', 'test', 'active', 1, '2025-07-19 10:46:53', '2025-07-19 18:18:11'),
(2, 'Ripon Sarkar', '0123546464', 100.00, 'Cash', 'Test', 'active', 15, '2025-07-19 11:36:28', '2025-07-19 18:07:44'),
(3, 'kassdk', '01911679706', 600.00, 'Cash', '', 'active', 1, '2025-07-21 13:02:57', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `bug`
--
ALTER TABLE `bug`
  ADD PRIMARY KEY (`bug_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `collection`
--
ALTER TABLE `collection`
  ADD PRIMARY KEY (`collection_id`),
  ADD KEY `inventory_order_id` (`inventory_order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gift`
--
ALTER TABLE `gift`
  ADD PRIMARY KEY (`gift_id`),
  ADD KEY `fk_user_id` (`user_id`);

--
-- Indexes for table `inventory_order`
--
ALTER TABLE `inventory_order`
  ADD PRIMARY KEY (`inventory_order_id`),
  ADD KEY `fk_inventory_order_customer` (`customer_id`);

--
-- Indexes for table `inventory_order_product`
--
ALTER TABLE `inventory_order_product`
  ADD PRIMARY KEY (`inventory_order_product_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `to_do_update`
--
ALTER TABLE `to_do_update`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `withdraw`
--
ALTER TABLE `withdraw`
  ADD PRIMARY KEY (`withdraw_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `brand_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `bug`
--
ALTER TABLE `bug`
  MODIFY `bug_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `collection`
--
ALTER TABLE `collection`
  MODIFY `collection_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `gift`
--
ALTER TABLE `gift`
  MODIFY `gift_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `inventory_order`
--
ALTER TABLE `inventory_order`
  MODIFY `inventory_order_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `inventory_order_product`
--
ALTER TABLE `inventory_order_product`
  MODIFY `inventory_order_product_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `to_do_update`
--
ALTER TABLE `to_do_update`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `withdraw`
--
ALTER TABLE `withdraw`
  MODIFY `withdraw_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `collection`
--
ALTER TABLE `collection`
  ADD CONSTRAINT `collection_ibfk_1` FOREIGN KEY (`inventory_order_id`) REFERENCES `inventory_order` (`inventory_order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `collection_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user_details` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `gift`
--
ALTER TABLE `gift`
  ADD CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `user_details` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `inventory_order`
--
ALTER TABLE `inventory_order`
  ADD CONSTRAINT `fk_inventory_order_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
