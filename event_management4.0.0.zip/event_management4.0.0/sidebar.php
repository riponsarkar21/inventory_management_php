<?php
// sidebar.php
// Contains the sidebar navigation for the application

// Make sure we have access to session variables
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get current page for active link detection
$current_page = $_SERVER['REQUEST_URI'];
?>

<div class="sidebar">
    <div id="sidebar-toggle" onclick="toggleSidebar()">☰</div>

    <?php if (!in_array($_SESSION['type'], ['Gift Admin', 'Gift User'])) { ?>
    <a href="<?= BASE_URL ?>index.php" class="<?= strpos($current_page, '/index.php') !== false ? 'active' : '' ?>">🏠 <span class="label">Home</span></a>
    <hr style="border-color: #555;">
    <?php } ?>

   <!-- ------------------------- template for show ----------------------------  -->
    <?php if (in_array($_SESSION['type'], ['Super Master'])) { ?>

    <?php } ?>

   <!-- ------------------------- template for not show ----------------------------  -->

    <?php if (!in_array($_SESSION['type'], ['Super Master'])) { ?>

    <?php } ?>

   <!-- ------------------------- demo / ongoing ----------------------------  -->

    <?php if (in_array($_SESSION['type'], ['Super Master'])) { ?>

    <a href="<?= BASE_URL ?>modules/event/event.php" class="<?= strpos($current_page, '/event/event.php') !== false ? 'active' : '' ?>" title = "Event">🎃 <span class="label">Event</span></a>
    <a href="<?= BASE_URL ?>modules/gift_settings/gift_settings.php" class="<?= strpos($current_page, '/gift_settings/gift_settings.php') !== false ? 'active' : '' ?>" title = "Gift Settings">☀️ <span class="label">Gift Settings</span></a>
    <?php } ?>
    
    <hr style="border-color: #555;">

   <!-- ------------------------- demo / ongoing ----------------------------  -->

    <?php if (in_array($_SESSION['type'], ['Super Master', 'Master', 'Inventory Admin'])) { ?>
        <a href="<?= BASE_URL ?>user.php" class="<?= strpos($current_page, '/user.php') !== false ? 'active' : '' ?>">👤 <span class="label">User</span></a>
    <?php } ?>

    <?php if (in_array($_SESSION['type'], ['Super Master', 'Master'])) { ?>
        <a href="<?= BASE_URL ?>category.php" class="<?= strpos($current_page, '/category.php') !== false ? 'active' : '' ?>">📂 <span class="label">Category</span></a>
        <a href="<?= BASE_URL ?>modules/brand/brand.php" class="<?= strpos($current_page, '/brand/brand.php') !== false ? 'active' : '' ?>">🏷 <span class="label">Brand</span></a>
        <a href="<?= BASE_URL ?>product.php" class="<?= strpos($current_page, '/product.php') !== false ? 'active' : '' ?>">📦 <span class="label">Product</span></a>
        <a href="<?= BASE_URL ?>customer.php" class="<?= strpos($current_page, '/customer.php') !== false ? 'active' : '' ?>">🧑 <span class="label">Customer</span></a>
    <?php } ?>

    <?php if (in_array($_SESSION['type'], ['Super Master', 'Master', 'Inventory Master', 'Inventory User'])) { ?>
        <a href="   <?= BASE_URL ?>user.php" class="<?= strpos($current_page, '/user.php') !== false ? 'active' : '' ?>">👤 <span class="label">User</span></a>
        <a href="<?= BASE_URL ?>order.php" class="<?= strpos($current_page, '/order.php') !== false ? 'active' : '' ?>">📝 <span class="label">Order</span></a>
        <a href="<?= BASE_URL ?>collection.php" class="<?= strpos($current_page, '/collection.php') !== false ? 'active' : '' ?>">💰 <span class="label">Collection</span></a>
        <a href="<?= BASE_URL ?>report.php" class="<?= strpos($current_page, '/report.php') !== false ? 'active' : '' ?>">📊 <span class="label">Report</span></a>
        <a href="<?= BASE_URL ?>customized_report.php" class="<?= strpos($current_page, '/customized_report.php') !== false ? 'active' : '' ?>">📋 <span class="label">Custom Report</span></a>
        <hr style="border-color: #555;">
    
    <?php } ?>

    <!-- ------------------ Gift ------------------------  -->

    <?php if (in_array($_SESSION['type'], ['Super Master', 'Master', 'Gift Admin'])) { ?>
        <a href="<?= BASE_URL ?>user.php" class="<?= strpos($current_page, '/user.php') !== false ? 'active' : '' ?>" title="User">👤 <span class="label">User</span></a>
    <?php } ?>    
    
    <?php if (in_array($_SESSION['type'], ['Super Master', 'Master', 'Gift Admin', 'Gift User'])) { ?>
        <a href="<?= BASE_URL ?>gift_dashboard.php" class="<?= strpos($current_page, '/gift_dashboard.php') !== false ? 'active' : '' ?>" title="Gift Dashboard">🏠 <span class="label">Gift Dash</span></a>
        <a href="<?= BASE_URL ?>modules/gift/gift.php" class="<?= strpos($current_page, '/gift/gift.php') !== false ? 'active' : '' ?>" title="Gift">🎁 <span class="label">Gift</span></a>                                               
        <a href="<?= BASE_URL ?>modules/withdraw/withdraw.php" class="<?= strpos($current_page, '/withdraw/withdraw.php') !== false ? 'active' : '' ?>" title="Withdraw">💸 <span class="label">Wtihdraw</span></a>
        <a href="<?= BASE_URL ?>modules/gift/gift_report.php" class="<?= strpos($current_page, '/gift/gift_report.php') !== false ? 'active' : '' ?>" title="Gift Report">📊 <span class="label">Report</span></a>

        <hr style="border-color: #555;">

    <?php } ?>

    <!-- ------------------------------------------  -->
    
    <?php if (in_array($_SESSION['type'], ['Super Master', 'Master'])) { ?>
        <a href="<?= BASE_URL ?>modules/version/version.php" class="<?= strpos($current_page, '/version/version.php') !== false ? 'active' : '' ?>">🔖 <span class="label">Version</span></a>
        <a href="<?= BASE_URL ?>modules/todo/todo.php" class="<?= strpos($current_page, '/todo/todo.php') !== false ? 'active' : '' ?>">📌 <span class="label">Todo</span></a>
        <a href="<?= BASE_URL ?>modules/bug/bug.php" class="<?= strpos($current_page, '/bug/bug.php') !== false ? 'active' : '' ?>">🐞 <span class="label">Bug</span></a>
    <?php } ?>

    <?php if (in_array($_SESSION['type'], ['Super Master', 'Master'])) { ?>
        <a href="#" onclick="toggleTheme()">🌓 <span class="label">Toggle Theme</span></a>
        <hr style="border-color: #555;">
    <?php } ?>

    <?php
    $role_emojis = [
        'Super Master'     => '🧠',
        'Master'           => '🧑‍💼',
        'Admin'            => '🛡️',
        'User'             => '👤',
        'Gift Admin'       => '🎁🛡️',
        'Gift User'        => '🎁👤',
        'Salesman'         => '💼',
        'Cashier'          => '💰',
        'Supervisor'       => '🧐',
        'Inventory Admin'  => '📦🛡️',
        'Inventory User'   => '📦👤'
    ];

    $emoji = $role_emojis[$_SESSION['user_type']] ?? '👤';
    ?>

    <a href="<?= BASE_URL ?>profile.php" 
    class="<?= strpos($current_page, '/profile.php') !== false ? 'active' : '' ?>" 
    title="<?= htmlspecialchars($_SESSION['user_type']) ?>">
        <?= $emoji ?> 
        <span class="label">
            <?= $_SESSION['user_name'] ?><br />
            <span style="display: block; text-align: center;">
                <?= $_SESSION['user_type'] ?>
            </span>
        </span>
    </a>

    <a href="#" data-toggle="modal" data-target="#logoutModal" title="Log Out">🚪 <span class="label">Logout</span></a>
</div>