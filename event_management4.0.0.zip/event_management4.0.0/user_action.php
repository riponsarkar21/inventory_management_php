<?php
// user_action.php

include('database_connection.php');

if (!file_exists('uploads/user')) {
    mkdir('uploads/user', 0777, true); // Create directory if not exists
}

if (isset($_POST['btn_action'])) {
    if ($_POST['btn_action'] == 'Add') {
        $image_path = null;

       $image_path = null;

       if (!empty($_FILES['user_image']['name'])) {
         $extension = pathinfo($_FILES['user_image']['name'], PATHINFO_EXTENSION);
         $timestamp = time();
         $sanitized_name = preg_replace('/[^a-zA-Z0-9]/', '_', $_POST["user_name"]);
         $sanitized_address = preg_replace('/[^a-zA-Z0-9]/', '_', $_POST["user_address"] ?? 'noaddress');
         $new_name = strtolower($sanitized_name . '-' . $sanitized_address . '-' . $timestamp . '.' . $extension);
         $destination = 'uploads/user/' . $new_name;
         move_uploaded_file($_FILES['user_image']['tmp_name'], $destination);
         $image_path = $destination;
     }


        $query = "
        INSERT INTO user_details (
            user_email, user_password, user_name, user_type, user_status, user_image
        ) VALUES (
            :user_email, :user_password, :user_name, :user_type, :user_status, :user_image
        )";

        $statement = $connect->prepare($query);
        $statement->execute([
            ':user_email'     => $_POST["user_email"],
            ':user_password'  => password_hash($_POST["user_password"], PASSWORD_DEFAULT),
            ':user_name'      => $_POST["user_name"],
            ':user_type'      => $_POST["user_type"],
            ':user_status'    => 'active',
            ':user_image'     => $image_path
        ]);
        echo 'New User Added';
    }

    if ($_POST['btn_action'] == 'fetch_single') {
        $query = "SELECT * FROM user_details WHERE user_id = :user_id";
        $statement = $connect->prepare($query);
        $statement->execute([':user_id' => $_POST["user_id"]]);
        $result = $statement->fetch(PDO::FETCH_ASSOC);
        echo json_encode($result);
    }

    if ($_POST['btn_action'] == 'Edit') {
        $image_path = $_POST['hidden_user_image'] ?? null;

        // Handle image upload if new one is provided
    $image_path = $_POST['hidden_user_image'] ?? null;

     if (!empty($_FILES['user_image']['name'])) {
        $extension = pathinfo($_FILES['user_image']['name'], PATHINFO_EXTENSION);
        $timestamp = time();
        $sanitized_name = preg_replace('/[^a-zA-Z0-9]/', '_', $_POST["user_name"]);
        $sanitized_address = preg_replace('/[^a-zA-Z0-9]/', '_', $_POST["user_address"] ?? 'noaddress');
        $new_name = strtolower($sanitized_name . '-' . $sanitized_address . '-' . $timestamp . '.' . $extension);
        $destination = 'uploads/user/' . $new_name;
        move_uploaded_file($_FILES['user_image']['tmp_name'], $destination);
       $image_path = $destination;
    }


        $params = [
            ':user_name'     => $_POST["user_name"],
            ':user_email'    => $_POST["user_email"],
            ':user_type'     => $_POST["user_type"],
            ':user_address'  => $_POST["user_address"] ?? '',
            ':user_image'    => $image_path,
            ':user_id'       => $_POST["user_id"]
        ];

        if ($_POST['user_password'] != '') {
            $params[':user_password'] = password_hash($_POST["user_password"], PASSWORD_DEFAULT);
            $query = "
                UPDATE user_details 
                SET user_name = :user_name, 
                    user_email = :user_email,
                    user_password = :user_password,
                    user_type = :user_type,
                    user_address = :user_address,
                    user_image = :user_image 
                WHERE user_id = :user_id";
        } else {
            $query = "
                UPDATE user_details 
                SET user_name = :user_name, 
                    user_email = :user_email,
                    user_type = :user_type,
                    user_address = :user_address,
                    user_image = :user_image 
                WHERE user_id = :user_id";
        }

        $statement = $connect->prepare($query);
        $statement->execute($params);
        echo 'User Details Edited';
    }

    if ($_POST['btn_action'] == 'status') {
        $status = ($_POST['status'] == 'Active') ? 'Inactive' : 'Active';
        $query = "UPDATE user_details SET user_status = :user_status WHERE user_id = :user_id";
        $statement = $connect->prepare($query);
        $statement->execute([
            ':user_status' => $status,
            ':user_id'     => $_POST["user_id"]
        ]);
        echo 'User Status changed to ' . $status;
    }

    if ($_POST['btn_action'] == 'delete') {
        $query = "DELETE FROM user_details WHERE user_id = :user_id";
        $statement = $connect->prepare($query);
        $statement->execute([':user_id' => $_POST["user_id"]]);
        if ($statement->rowCount() > 0) {
            echo 'User deleted';
        } else {
            echo 'User deletion failed';
        }
    }
}
?>
