<?php
// user_orders.php


include('database_connection.php');
include('function.php');
include('header.php');

if(!isset($_SESSION["type"])) {
    header("location:login.php");
}

if(isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Fetch user name
    $user_query = $connect->prepare("SELECT user_name FROM user_details WHERE user_id = ?");
    $user_query->execute([$user_id]);
    $user = $user_query->fetch();


?>


<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="row">
                     
                    <div class="col-md-10">
                        <!-- <h3 class="panel-title">Brand List</h3> -->
                        <?php                     
                            echo '<h3 class="panel-title">Orders created by: <strong>' . htmlspecialchars($user['user_name']) . '</strong></h3>';
                        ?>
                    </div>
                    <!-- <div class="col-md-2 text-right"> -->
                        <!-- <button type="button" name="add" id="add_button" class="btn btn-success btn-xs">Add</button> -->
                    <!-- </div> -->
                </div>
            </div>

            <div class="panel-body">


                <?php


                    if($user) {
                        // echo "<h2>Orders created by: <strong>" . htmlspecialchars($user['user_name']) . "</strong></h2><br>";

                        $query = "
                        SELECT * FROM inventory_order 
                        WHERE user_id = ? 
                        ORDER BY inventory_order_date DESC
                        ";
                        $statement = $connect->prepare($query);
                        $statement->execute([$user_id]);
                        $orders = $statement->fetchAll();

                        if($orders) {
                            // echo '<table class="table table-bordered">';
                            echo '<table id="orderTable" class="table table-bordered table-striped">';

                            echo '<thead><tr><th>Order ID</th><th>Date</th><th>Customer Name</th><th>Total</th><th>Payment Status</th><th>Invoice</th></tr></thead><tbody>';
                            foreach($orders as $order) {
                                echo '<tr>
                                        <td>' . htmlspecialchars($order['inventory_order_id']) . '</td>
                                        <td>' . htmlspecialchars($order['inventory_order_date']) . '</td>
                                        <td>' . htmlspecialchars($order['inventory_order_name']) . '</td>
                                        <td>$' . htmlspecialchars($order['inventory_order_total']) . '</td>
                                        <td>' . (($order['payment_status'] == 'cash') 
                                                ? '<span class="label label-primary">Cash</span>' 
                                                : '<span class="label label-warning">Credit</span>') . '</td>
                                        <td><a href="view_order.php?pdf=1&order_id=' . htmlspecialchars($order['inventory_order_id']) . '" class="btn btn-info btn-xs">View Details</a></td>

                                    </tr>';
                            }
                            echo '</tbody></table>';
                        } else {
                            echo "<p>No orders found for this user.</p>";
                        }
                    } else {
                        echo "<p>User not found.</p>";
                    }
                } else {
                    echo "<p>No user selected.</p>";
                }

                ?>
            </div>
            

        </div>
    </div>
</div>




<script>
    $(document).ready(function() {
    $('#orderTable').DataTable({
        "columnDefs": [
            { "orderable": false, "targets": 5 }
        ],
        "lengthMenu": [ [5, 10, 25, 50, 100, 1000], [5, 10, 25, 50, 100, 1000] ],
        "pageLength": 5,

        // Custom layout (DOM positioning)
        "dom":
            "<'row'<'col-sm-6'l><'col-sm-6'f>>" +       // Top: length + filter
            "<'row'<'col-sm-12'tr>>" +                  // Table
            "<'row'<'col-sm-5'i><'col-sm-7'p>>" +       // Info + pagination
            "<'row'<'col-sm-12 text-center mt-2'B>>",   // Buttons below

        "buttons": [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    });
});

</script>



<?php

    include('footer.php');
?>
