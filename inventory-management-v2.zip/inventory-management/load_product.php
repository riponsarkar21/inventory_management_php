<?php

//load_product.php

?>