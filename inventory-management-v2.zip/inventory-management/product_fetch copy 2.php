<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

include('database_connection.php');
include('function.php');

// Map DataTables column index to database columns
$columns = array(
    0 => 'product.product_id',
    1 => 'category.category_name',
    2 => 'brand.brand_name',
    3 => 'product.product_name',
    4 => 'product.product_quantity', // Sorting may not reflect calculated quantity
    5 => 'user_details.user_name',
    6 => 'product.product_status'
);

// Base query with joins
$query = "
    SELECT * FROM product 
    INNER JOIN brand ON brand.brand_id = product.brand_id
    INNER JOIN category ON category.category_id = product.category_id 
    INNER JOIN user_details ON user_details.user_id = product.product_enter_by
";

// Filtering (search)
$conditions = [];
if (!empty($_POST["search"]["value"])) {
    $search = $_POST["search"]["value"];
    $conditions[] = "
        brand.brand_name LIKE '%$search%' 
        OR category.category_name LIKE '%$search%' 
        OR product.product_name LIKE '%$search%' 
        OR product.product_quantity LIKE '%$search%' 
        OR user_details.user_name LIKE '%$search%' 
        OR product.product_id LIKE '%$search%'
    ";
}

if (!empty($conditions)) {
    $query .= " WHERE " . implode(' AND ', $conditions);
}

// Sorting
if (isset($_POST['order'])) {
    $order_column_index = $_POST['order'][0]['column'];
    $order_direction = $_POST['order'][0]['dir'];
    if (isset($columns[$order_column_index])) {
        $query .= ' ORDER BY ' . $columns[$order_column_index] . ' ' . $order_direction . ' ';
    } else {
        $query .= ' ORDER BY product.product_id DESC ';
    }
} else {
    $query .= ' ORDER BY product.product_id DESC ';
}

// Pagination
if ($_POST['length'] != -1) {
    $query .= ' LIMIT ' . intval($_POST['start']) . ', ' . intval($_POST['length']);
}

// Execute query
$statement = $connect->prepare($query);
$statement->execute();
$result = $statement->fetchAll();

// Prepare data
$data = array();
foreach ($result as $row) {
    $status = ($row['product_status'] == 'active') ?
        '<span class="label label-success">Active</span>' :
        '<span class="label label-danger">Inactive</span>';

    $sub_array = array();
    $sub_array[] = $row['product_id'];
    $sub_array[] = $row['category_name'];
    $sub_array[] = $row['brand_name'];
    $sub_array[] = $row['product_name'];
    $sub_array[] = available_product_quantity($connect, $row["product_id"]) . ' ' . $row["product_unit"];
    $sub_array[] = $row['user_name'];
    $sub_array[] = $status;
    $sub_array[] = '<button type="button" name="update" id="' . $row["product_id"] . '" class="btn btn-warning btn-xs update">Update</button>';
    $sub_array[] = '<button type="button" name="status" id="' . $row["product_id"] . '" class="btn btn-primary btn-xs status" data-status="' . $row["product_status"] . '">Change status</button>';
    $sub_array[] = '<button type="button" name="delete" id="' . $row["product_id"] . '" class="btn btn-danger btn-xs delete" data-status="' . $row["product_name"] . '">Delete</button>';
    $data[] = $sub_array;
}

// Get total records (without filtering)
function get_total_all_records($connect) {
    $statement = $connect->prepare('SELECT * FROM product');
    $statement->execute();
    return $statement->rowCount();
}

// Output JSON
$output = array(
    "draw" => intval($_POST["draw"] ?? 0),
    "recordsTotal" => count($result),
    "recordsFiltered" => get_total_all_records($connect),
    "data" => $data
);

echo json_encode($output);
