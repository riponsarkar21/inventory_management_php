<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

include('database_connection.php');
include('function.php');

// Define the query base
$query = "
    SELECT 
        product.*, 
        brand.brand_name, 
        category.category_name, 
        user_details.user_name,
        product.product_quantity
    FROM product
    INNER JOIN brand ON brand.brand_id = product.brand_id
    INNER JOIN category ON category.category_id = product.category_id 
    INNER JOIN user_details ON user_details.user_id = product.product_enter_by
";

// Apply filters based on search value if available
if (isset($_POST["search"]["value"]) && !empty($_POST["search"]["value"])) {
    $search = $_POST["search"]["value"];
    $query .= "
        WHERE brand.brand_name LIKE '%$search%' 
        OR category.category_name LIKE '%$search%' 
        OR product.product_name LIKE '%$search%' 
        OR product.product_quantity LIKE '%$search%' 
        OR user_details.user_name LIKE '%$search%' 
        OR product.product_id LIKE '%$search%' 
    ";
}

// Apply ordering based on DataTables request
if (isset($_POST['order'])) {
    $order_column = $_POST['order']['0']['column']; // Get the column index for ordering
    $order_dir = $_POST['order']['0']['dir']; // Get the ordering direction (asc/desc)

    // Map DataTables column index to actual SQL columns
    $columns = [
        0 => 'product.product_id',       // ID
        1 => 'category.category_name',   // Category
        2 => 'brand.brand_name',         // Brand
        3 => 'product.product_name',     // Product Name
        4 => 'product.product_quantity', // Quantity
        5 => 'user_details.user_name',   // Enter By
        6 => 'product.product_status'    // Status
    ];

    $query .= 'ORDER BY ' . $columns[$order_column] . ' ' . $order_dir . ' ';
} else {
    $query .= 'ORDER BY product.product_id DESC ';
}

// Apply pagination if needed (DataTables sends start and length for pagination)
if ($_POST['length'] != -1) {
    $query .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}

// Prepare and execute the SQL query
$statement = $connect->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
$data = array();

// Process the fetched data and prepare the response
foreach ($result as $row) {
    $status = ($row['product_status'] == 'active') ? 
        '<span class="label label-success">Active</span>' :
        '<span class="label label-danger">Inactive</span>';

    // Prepare row data for DataTables
    $sub_array = array();
    $sub_array[] = $row['product_id']; // Product ID
    $sub_array[] = $row['category_name']; // Category Name
    $sub_array[] = $row['brand_name']; // Brand Name
    $sub_array[] = $row['product_name']; // Product Name
    $sub_array[] = $row['product_quantity'] . ' ' . $row["product_unit"]; // Available Quantity with Unit
    $sub_array[] = $row['user_name']; // Entered By
    $sub_array[] = $status; // Product Status
    $sub_array[] = '<button type="button" name="update" id="'.$row["product_id"].'" class="btn btn-warning btn-xs update">Update</button>';
    $sub_array[] = '<button type="button" name="status" id="'.$row["product_id"].'" class="btn btn-primary btn-xs status" data-status="'.$row["product_status"].'">Change status</button>';
    $sub_array[] = '<button type="button" name="delete" id="'.$row["product_id"].'" class="btn btn-danger btn-xs delete" data-status="'.$row["product_name"].'">Delete</button>';
    $data[] = $sub_array;
}

// Function to get total records from the product table
function get_total_all_records($connect) {
    $statement = $connect->prepare('SELECT * FROM product');
    $statement->execute();
    return $statement->rowCount();
}

// Prepare output data for DataTables response
$output = array(
    "draw" => isset($_POST["draw"]) ? intval($_POST["draw"]) : 0,
    "recordsTotal" => get_total_all_records($connect),
    "recordsFiltered" => count($result),
    "data" => $data
);


// Return the data as JSON
echo json_encode($output);
