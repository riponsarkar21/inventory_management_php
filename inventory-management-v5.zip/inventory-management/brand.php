<?php
// brand.php

include('database_connection.php');
include('function.php');

// Redirect if not logged in or not master
if (!isset($_SESSION['type']) || $_SESSION['type'] !== 'master') {
    header('location:' . (isset($_SESSION['type']) ? 'index.php' : 'login.php'));
    exit;
}

include('header.php');
?>

<span id="alert_action"></span>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-md-10">
                        <h3 class="panel-title">Brand List</h3>
                    </div>
                    <div class="col-md-2 text-right">
                        <button type="button" name="add" id="add_button" class="btn btn-success btn-xs">Add</button>
                    </div>
                </div>
            </div>
            <div class="panel-body">
                <table id="brand_data" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Category</th>
                            <th>Brand Name</th>
                            <th>Status</th>
                            <th>Edit</th>
                            <th>Visibility</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Brand Modal -->
<div id="brandModal" class="modal fade">
    <div class="modal-dialog">
        <form method="post" id="brand_form">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-plus"></i> Add Brand</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <select name="category_id" id="category_id" class="form-control" required>
                            <option value="">Select Category</option>
                            <?php echo fill_category_list($connect); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Enter Brand Name</label>
                        <input type="text" name="brand_name" id="brand_name" class="form-control" required />
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="brand_id" id="brand_id" />
                    <input type="hidden" name="btn_action" id="btn_action" />
                    <input type="submit" name="action" id="action" class="btn btn-info" value="Add" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- JavaScript -->
<script>
$(document).ready(function() {

    const brandTable = $('#brand_data').DataTable({
        "processing": true,
        "serverSide": true,
        "order": [],
        "ajax": {
            url: "brand_fetch.php",
            type: "POST"
        },
        "columnDefs": [
            { "targets": [4, 5, 6], "orderable": false }
        ],
        "pageLength": 10
    });

    $('#add_button').click(function() {
        $('#brand_form')[0].reset();
        $('#brandModal').modal('show');
        $('.modal-title').html("<i class='fa fa-plus'></i> Add Brand");
        $('#action').val('Add');
        $('#btn_action').val('Add');
    });

    $('#brand_form').on('submit', function(event) {
        event.preventDefault();
        $('#action').prop('disabled', true);
        $.ajax({
            url: "brand_action.php",
            method: "POST",
            data: $(this).serialize(),
            success: function(data) {
                $('#brand_form')[0].reset();
                $('#brandModal').modal('hide');
                $('#alert_action').html('<div class="alert alert-success">' + data + '</div>').fadeIn().delay(2000).fadeOut();
                $('#action').prop('disabled', false);
                brandTable.ajax.reload();
            }
        });
    });

    $(document).on('click', '.update', function() {
        const brand_id = $(this).attr("id");
        $.post('brand_action.php', { brand_id: brand_id, btn_action: 'fetch_single' }, function(data) {
            $('#brandModal').modal('show');
            $('#category_id').val(data.category_id);
            $('#brand_name').val(data.brand_name);
            $('.modal-title').html("<i class='fa fa-pencil-square-o'></i> Edit Brand");
            $('#brand_id').val(brand_id);
            $('#action').val('Edit');
            $('#btn_action').val('Edit');
        }, 'json');
    });

    $(document).on('click', '.status', function() {
        const brand_id = $(this).attr("id");
        const status = $(this).data("status");
        if (confirm("Are you sure you want to change status?")) {
            $.post("brand_action.php", { brand_id: brand_id, status: status, btn_action: 'status' }, function(data) {
                $('#alert_action').html('<div class="alert alert-info">' + data + '</div>').fadeIn().delay(2000).fadeOut();
                brandTable.ajax.reload();
            });
        }
    });

    $(document).on('click', '.delete', function() {
        const brand_id = $(this).attr("id");
        const brand_name = $(this).data("status");
        if (confirm("Are you sure you want to delete brand?")) {
            $.post("brand_action.php", { brand_id: brand_id, status: brand_name, btn_action: 'delete' }, function(data) {
                $('#alert_action').html('<div class="alert alert-info">' + data + '</div>').fadeIn().delay(2000).fadeOut();
                brandTable.ajax.reload();
            });
        }
    });

});
</script>

<?php include('footer.php'); ?>
