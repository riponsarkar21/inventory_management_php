<?php
include('database_connection.php');
include('header.php');

// Fetch all customers
$query = "SELECT * FROM customers ORDER BY customer_id DESC";
$statement = $connect->prepare($query);
$statement->execute();
$customers = $statement->fetchAll();
?>

<div class="panel panel-default">
    <div class="panel-heading">Customer List</div>
    <div class="panel-body">
        <a href="customer_add.php" class="btn btn-success">Add Customer</a>
        <table class="table table-bordered" id="customer_data">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Profile</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($customers as $row): ?>
                    <tr>
                        <td><?= $row["customer_name"] ?></td>
                        <td><?= $row["phone"] ?></td>
                        <td><?= $row["email"] ?></td>
                        <td><?= $row["address"] ?></td>
                        <td><a href="customer_profile.php?id=<?= $row["customer_id"] ?>" class="btn btn-info btn-sm">View</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
$(document).ready(function(){
    $('#customer_data').DataTable();
});
</script>

<?php include('footer.php'); ?>
