<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

include('database_connection.php');
include('function.php');

// Clone the base query (before LIMIT)
$base_query = "
    SELECT 
        product.*, 
        brand.brand_name, 
        category.category_name, 
        user_details.user_name,
        product.product_quantity
    FROM product
    INNER JOIN brand ON brand.brand_id = product.brand_id
    INNER JOIN category ON category.category_id = product.category_id 
    INNER JOIN user_details ON user_details.user_id = product.product_enter_by
";

// Apply filters if any
$filter = '';
if (isset($_POST["search"]["value"]) && !empty($_POST["search"]["value"])) {
    $search = $_POST["search"]["value"];
    $filter = "
        WHERE brand.brand_name LIKE '%$search%' 
        OR category.category_name LIKE '%$search%' 
        OR product.product_name LIKE '%$search%' 
        OR product.product_quantity LIKE '%$search%' 
        OR user_details.user_name LIKE '%$search%' 
        OR product.product_id LIKE '%$search%'
    ";
}

$query = $base_query . $filter;

// Apply ordering
if (isset($_POST['order'])) {
    $columns = [
        0 => 'product.product_id',
        1 => 'category.category_name',
        2 => 'brand.brand_name',
        3 => 'product.product_name',
        4 => 'product.product_quantity',
        5 => 'user_details.user_name',
        6 => 'product.product_status'
    ];
    $order_column = $_POST['order']['0']['column'];
    $order_dir = $_POST['order']['0']['dir'];
    $query .= ' ORDER BY ' . $columns[$order_column] . ' ' . $order_dir . ' ';
} else {
    $query .= ' ORDER BY product.product_id DESC ';
}

// For recordsFiltered: count total rows after filtering (without LIMIT)
$filtered_statement = $connect->prepare($query);
$filtered_statement->execute();
$filtered_rows = $filtered_statement->rowCount();

// Add pagination (LIMIT)
if ($_POST['length'] != -1) {
    $query .= ' LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}

// Fetch paginated data
$statement = $connect->prepare($query);
$statement->execute();
$result = $statement->fetchAll();

$data = array();
foreach ($result as $row) {
    $status = ($row['product_status'] == 'active') ? 
        '<span class="label label-success">Active</span>' :
        '<span class="label label-danger">Inactive</span>';

    $sub_array = array();
    $sub_array[] = $row['product_id'];
    $sub_array[] = $row['category_name'];
    $sub_array[] = $row['brand_name'];
    $sub_array[] = $row['product_name'];
    $sub_array[] = $row['product_quantity'] . ' ' . $row["product_unit"];
    $sub_array[] = $row['user_name'];
    $sub_array[] = $status;
    $sub_array[] = '<button type="button" name="update" id="'.$row["product_id"].'" class="btn btn-warning btn-xs update">Update</button>';
    $sub_array[] = '<button type="button" name="status" id="'.$row["product_id"].'" class="btn btn-primary btn-xs status" data-status="'.$row["product_status"].'">Change status</button>';
    $sub_array[] = '<button type="button" name="delete" id="'.$row["product_id"].'" class="btn btn-danger btn-xs delete" data-status="'.$row["product_name"].'">Delete</button>';
    $data[] = $sub_array;
}

function get_total_all_records($connect) {
    $statement = $connect->prepare('SELECT * FROM product');
    $statement->execute();
    return $statement->rowCount();
}

$output = array(
    "draw" => isset($_POST["draw"]) ? intval($_POST["draw"]) : 0,
    "recordsTotal" => get_total_all_records($connect),
    "recordsFiltered" => $filtered_rows,
    "data" => $data
);

echo json_encode($output);