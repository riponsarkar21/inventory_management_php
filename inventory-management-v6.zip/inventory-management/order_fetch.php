<?php
// order_fetch.php

include('database_connection.php');
include('function.php');

$query = '';
$output = array();

// Base SELECT query
$query .= "SELECT * FROM inventory_order WHERE ";

// Filter data based on user type
if ($_SESSION['type'] == 'user') {
    $query .= 'user_id = "' . $_SESSION["user_id"] . '" AND ';
}

// Handle search filtering
if (isset($_POST["search"]["value"])) {
    $query .= '(inventory_order_id LIKE "%' . $_POST["search"]["value"] . '%" ';
    $query .= 'OR inventory_order_name LIKE "%' . $_POST["search"]["value"] . '%" ';
    $query .= 'OR inventory_order_total LIKE "%' . $_POST["search"]["value"] . '%" ';
    $query .= 'OR inventory_order_status LIKE "%' . $_POST["search"]["value"] . '%" ';
    $query .= 'OR inventory_order_date LIKE "%' . $_POST["search"]["value"] . '%") ';
}

// Define columns mapping based on table order
$columns = array(
    0 => 'inventory_order_id',
    1 => 'inventory_order_name',
    2 => 'inventory_order_total',
    3 => 'payment_status',
    4 => 'inventory_order_status',
    5 => 'inventory_order_date',
    6 => 'user_id' // This index is only relevant if user is master
);

// Handle sorting
if (isset($_POST["order"])) {
    $column_index = $_POST['order']['0']['column'];
    $sort_column = isset($columns[$column_index]) ? $columns[$column_index] : 'inventory_order_id';
    $query .= 'ORDER BY ' . $sort_column . ' ' . $_POST['order']['0']['dir'] . ' ';
} else {
    $query .= 'ORDER BY inventory_order_id DESC ';
}

// Handle pagination
if ($_POST["length"] != -1) {
    $query .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}

// Prepare and execute SQL query
$statement = $connect->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
$data = array();
$filtered_rows = $statement->rowCount();

foreach ($result as $row) {
    // Format payment status
    $payment_status = ($row['payment_status'] == 'cash') 
        ? '<span class="label label-primary">Cash</span>' 
        : '<span class="label label-warning">Credit</span>';

    // Format inventory status
    $status = ($row['inventory_order_status'] == 'active') 
        ? '<span class="label label-success">Active</span>' 
        : '<span class="label label-danger">Inactive</span>';

    // Build sub array
    $sub_array = array();
    $sub_array[] = $row['inventory_order_id'];
    $sub_array[] = $row['inventory_order_name'];
    $sub_array[] = $row['inventory_order_total'];
    $sub_array[] = $payment_status;
    $sub_array[] = $status;
    $sub_array[] = $row['inventory_order_date'];

    // Add user name if master
    if ($_SESSION['type'] == 'master') {
        $sub_array[] = get_user_name($connect, $row['user_id']);
    }

    // Action buttons
    $sub_array[] = '<button type="button" name="status" id="' . $row["inventory_order_id"] . '" class="btn btn-primary btn-xs status" data-status="' . $row["inventory_order_status"] . '">Change Status</button>';
    $sub_array[] = '<a href="view_order.php?pdf=1&order_id=' . $row["inventory_order_id"] . '" class="btn btn-info btn-xs">View PDF</a>';
    $sub_array[] = '<button type="button" name="update" id="' . $row["inventory_order_id"] . '" class="btn btn-warning btn-xs update">Update</button>';
    $sub_array[] = '<button type="button" name="delete" id="' . $row["inventory_order_id"] . '" class="btn btn-danger btn-xs delete" data-status="' . $row["inventory_order_name"] . '">Delete</button>';

    $data[] = $sub_array;
}

// Helper function to get total records (for pagination)
function get_total_all_records($connect)
{
    $statement = $connect->prepare("SELECT * FROM inventory_order");
    $statement->execute();
    return $statement->rowCount();
}

// Final JSON response
$output = array(
    "draw"              => intval($_POST["draw"]),
    "recordsTotal"      => $filtered_rows,
    "recordsFiltered"   => get_total_all_records($connect),
    "data"              => $data
);

// Return data as JSON
echo json_encode($output);
?>
