<?php
// user.php
include('database_connection.php');

// session_start();

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


if (!isset($_SESSION["type"]) || $_SESSION["type"] !== 'master') {
    header("location:login.php");
    exit();
}

include('header.php');
?>

<span id="alert_action"></span>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading clearfix">
                <div class="pull-left">
                    <h3 class="panel-title">User List</h3>
                </div>
                <div class="pull-right">
                    <button type="button" id="add_button" data-toggle="modal" data-target="#userModal" class="btn btn-success btn-xs">Add</button>
                </div>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table id="user_data" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Email</th>
                                <th>Name</th>
                                <th>Status</th>
                                <th>Edit</th>
                                <th>Visibility</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal for Add/Edit User -->
<div id="userModal" class="modal fade">
    <div class="modal-dialog">
        <form method="post" id="user_form">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><i class="fa fa-plus"></i> Add User</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>User Name</label>
                        <input type="text" name="user_name" id="user_name" class="form-control" required />
                    </div>
                    <div class="form-group">
                        <label>User Email</label>
                        <input type="email" name="user_email" id="user_email" class="form-control" required />
                    </div>
                    <div class="form-group">
                        <label>User Password</label>
                        <input type="password" name="user_password" id="user_password" class="form-control" required />
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="user_id" id="user_id" />
                    <input type="hidden" name="btn_action" id="btn_action" />
                    <input type="submit" name="action" id="action" class="btn btn-info" value="Add" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
$(document).ready(function(){

    const userdataTable = $('#user_data').DataTable({
        "processing": true,
        "serverSide": true,
        "ajax": {
            url: "user_fetch.php",
            type: "POST"
        },
        "columnDefs": [
            {
                "targets": [4,5,6],
                "orderable": false
            }
        ],
        "pageLength": 10
    });

    $('#add_button').click(function(){
        $('#user_form')[0].reset();
        $('.modal-title').html("<i class='fa fa-plus'></i> Add User");
        $('#action').val("Add");
        $('#btn_action').val("Add");
        $('#user_password').attr('required', true);
    });

    $('#user_form').on('submit', function(event){
        event.preventDefault();
        $('#action').prop('disabled', true);
        const form_data = $(this).serialize();
        $.post("user_action.php", form_data, function(data){
            $('#user_form')[0].reset();
            $('#userModal').modal('hide');
            $('#alert_action').html('<div class="alert alert-success">'+data+'</div>');
            $('#action').prop('disabled', false);
            userdataTable.ajax.reload();
        });
    });

    $(document).on('click', '.update', function(){
        const user_id = $(this).attr("id");
        $.post("user_action.php", { user_id: user_id, btn_action: "fetch_single" }, function(data){
            $('#userModal').modal('show');
            $('#user_name').val(data.user_name);
            $('#user_email').val(data.user_email);
            $('.modal-title').html("<i class='fa fa-pencil-square-o'></i> Edit User");
            $('#user_id').val(user_id);
            $('#action').val('Edit');
            $('#btn_action').val('Edit');
            $('#user_password').attr('required', false);
        }, 'json');
    });

    $(document).on('click', '.status', function(){
        if (!confirm("Are you sure you want to change status?")) return;
        const user_id = $(this).attr("id");
        const status = $(this).data('status');
        $.post("user_action.php", { user_id, status, btn_action: "status" }, function(data){
            $('#alert_action').html('<div class="alert alert-info">'+data+'</div>');
            userdataTable.ajax.reload();
        });
    });

    $(document).on('click', '.delete', function(){
        if (!confirm("Are you sure you want to delete this user?")) return;
        const user_id = $(this).attr("id");
        const status = $(this).data('delete');
        $.post("user_action.php", { user_id, status, btn_action: "delete" }, function(data){
            $('#alert_action').html('<div class="alert alert-info">'+data+'</div>');
            userdataTable.ajax.reload();
        });
    });

});
</script>

<?php include('footer.php'); ?>
