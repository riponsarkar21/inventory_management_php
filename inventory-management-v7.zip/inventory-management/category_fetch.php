<?php
//category_fetch.php

// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Set header to return JSON response
header('Content-Type: application/json');

// Include database connection
include('database_connection.php');

// Base query
$query = "SELECT * FROM category";
$where = '';
$params = [];

// Search filter
if (!empty($_POST['search']['value'])) {
    $where = " WHERE category_name LIKE :search OR category_status LIKE :search";
    $params[':search'] = '%' . $_POST['search']['value'] . '%';
}

$query .= $where;

// Sorting
$columns = ['category_id', 'category_name', 'category_status'];
$orderColumn = isset($_POST['order'][0]['column']) ? (int)$_POST['order'][0]['column'] : 0;
$orderDir = isset($_POST['order'][0]['dir']) && in_array($_POST['order'][0]['dir'], ['asc', 'desc']) ? $_POST['order'][0]['dir'] : 'desc';
$query .= " ORDER BY {$columns[$orderColumn]} $orderDir";

// Pagination
$start = isset($_POST['start']) ? (int)$_POST['start'] : 0;
$length = isset($_POST['length']) ? (int)$_POST['length'] : 10;
if ($length != -1) {
    $query .= " LIMIT $start, $length";
}

// Fetch filtered records
$statement = $connect->prepare($query);
$statement->execute($params);
$result = $statement->fetchAll();

// Prepare formatted data
$data = [];
foreach ($result as $row) {
    $status_label = $row['category_status'] === 'active'
        ? '<span class="label label-success">Active</span>'
        : '<span class="label label-danger">Inactive</span>';

    $data[] = [
        $row['category_id'],
        htmlspecialchars($row['category_name']),
        $status_label,
        '<button type="button" name="update" id="' . $row["category_id"] . '" class="btn btn-warning btn-xs update">Update</button>',
        '<button type="button" name="status" id="' . $row["category_id"] . '" class="btn btn-primary btn-xs status" data-status="' . $row["category_status"] . '">Change status</button>',
        '<button type="button" name="delete" id="' . $row["category_id"] . '" class="btn btn-danger btn-xs delete" data-status="' . $row["category_name"] . '">Delete</button>'
    ];
}

// Total record count function
function get_total_all_records($connect) {
    $stmt = $connect->prepare("SELECT COUNT(*) FROM category");
    $stmt->execute();
    return $stmt->fetchColumn();
}

// Get filtered count
$filter_query = "SELECT COUNT(*) FROM category" . $where;
$filter_stmt = $connect->prepare($filter_query);
$filter_stmt->execute($params);
$recordsFiltered = $filter_stmt->fetchColumn();

// Output JSON
echo json_encode([
    "draw" => intval($_POST["draw"]),
    "recordsTotal" => get_total_all_records($connect),
    "recordsFiltered" => $recordsFiltered,
    "data" => $data
]);
?>
